#!/usr/bin/env python3
"""
Phase 2: 16-Equation Receptor-to-Condensate Kinetic-Thermodynamic Framework (RC-KTF)
====================================================================================
Mechanistic modeling, analytical & solver self-verification, multi-cohort calibration
and out-of-sample cross-validation (GSE276143, GTEx v8, Garcia-Cabau 2025, Dörrbaum 2018),
prior/posterior predictive checks, Saltelli-Sobol & PRCC global sensitivity analyses,
single/pairwise/combined arm ablations & threshold epistasis, bistability/separatrix mapping,
and prospective iPSC power calculations.

Outputs (all programmatically generated, zero NaNs):
  - results/tables/model_parameters_calibrated.csv
  - results/tables/antipsychotic_drug_predictions.csv
  - results/tables/mechanistic_ablation_synergy.csv
  - results/tables/gse276143_cv_predictions.csv
  - results/tables/gtex_brain13_loocv.csv
  - results/tables/prior_vs_posterior_predictive.csv
  - results/tables/sobol_prcc_sensitivity.csv
  - results/tables/proteostasis_timecourse_regimes.csv
  - results/tables/bifurcation_phase_grid.csv
  - results/tables/ipsc_experimental_power.csv
  - results/metrics_registry.json  (preserves bioinformatics_phase1, adds modeling_phase2)
  - results/verification_report.json
"""

from __future__ import annotations

import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq, curve_fit, minimize
from scipy.stats import chi, norm, qmc, spearmanr, t as student_t

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_PROCESSED = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results"
TABLES_DIR = RESULTS_DIR / "tables"
TABLES_DIR.mkdir(parents=True, exist_ok=True)

SEED = 42
L_INTRON4_NT = 1917.0  # NC_000005.10 verified CPEB4 Intron 4 length (nt)

# ---------------------------------------------------------------------------
# AGNP 2018 (Hiemke et al. 2018, PMID 28910830) + PET D2 occupancy calibration
# (Kapur et al. 2000, PMID 10739409; Uchida et al. 2011; Wong et al. 2013)
# ---------------------------------------------------------------------------
PK_TABLE: dict[str, dict[str, Any]] = {
    "HALOPERIDOL": {
        "c_ther_range_ng_ml": "1-10", "c_mid_ng_ml": 5.5, "mw_g_mol": 375.86,
        "fu_plasma": 0.09, "kp_uu_eff": 3.00, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "65-80%",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Kapur et al. 2000 (PMID:10739409)",
    },
    "FLUPHENAZINE": {
        "c_ther_range_ng_ml": "1-10", "c_mid_ng_ml": 5.5, "mw_g_mol": 437.94,
        "fu_plasma": 0.02, "kp_uu_eff": 16.00, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "65-80%",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); lipophilic CNS accumulation",
    },
    "CHLORPROMAZINE": {
        "c_ther_range_ng_ml": "30-300", "c_mid_ng_ml": 165.0, "mw_g_mol": 318.86,
        "fu_plasma": 0.03, "kp_uu_eff": 0.80, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "65-80%",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Kapur et al. 2000",
    },
    "RISPERIDONE": {
        "c_ther_range_ng_ml": "20-60 (active moiety)", "c_mid_ng_ml": 40.0, "mw_g_mol": 410.49,
        "fu_plasma": 0.11, "kp_uu_eff": 0.90, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "65-80%",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Kapur et al. 1999",
    },
    "PALIPERIDONE": {
        "c_ther_range_ng_ml": "20-60", "c_mid_ng_ml": 40.0, "mw_g_mol": 426.49,
        "fu_plasma": 0.26, "kp_uu_eff": 0.20, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "65-80% (P-gp attenuated brain entry)",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Uchida et al. 2011",
    },
    "OLANZAPINE": {
        "c_ther_range_ng_ml": "20-80", "c_mid_ng_ml": 50.0, "mw_g_mol": 312.44,
        "fu_plasma": 0.07, "kp_uu_eff": 3.50, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "60-75%",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Kapur et al. 1999",
    },
    "CLOZAPINE": {
        "c_ther_range_ng_ml": "350-600", "c_mid_ng_ml": 475.0, "mw_g_mol": 326.83,
        "fu_plasma": 0.04, "kp_uu_eff": 1.25, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "35-55% (transient D2 dissociation)",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Kapur et al. 2000 (PMID:10739409)",
    },
    "QUETIAPINE": {
        "c_ther_range_ng_ml": "100-500", "c_mid_ng_ml": 300.0, "mw_g_mol": 383.51,
        "fu_plasma": 0.17, "kp_uu_eff": 1.20, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "25-45% (trough D2)",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Kapur et al. 2000",
    },
    "ARIPIPRAZOLE": {
        "c_ther_range_ng_ml": "100-350", "c_mid_ng_ml": 225.0, "mw_g_mol": 448.39,
        "fu_plasma": 0.01, "kp_uu_eff": 2.00, "alpha_d2": 0.25, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "80-90% total D2 (partial agonist alpha_D2=0.25)",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Yokoi et al. 2002",
    },
    "ZIPRASIDONE": {
        "c_ther_range_ng_ml": "50-200", "c_mid_ng_ml": 125.0, "mw_g_mol": 412.94,
        "fu_plasma": 0.01, "kp_uu_eff": 2.00, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "60-75%",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Mamo et al. 2004",
    },
    "AMISULPRIDE": {
        "c_ther_range_ng_ml": "100-300", "c_mid_ng_ml": 200.0, "mw_g_mol": 369.48,
        "fu_plasma": 0.80, "kp_uu_eff": 0.05, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "65-80% (low BBB passive permeability Kp,uu~0.05)",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Vernaleken et al. 2004",
    },
    "LURASIDONE": {
        "c_ther_range_ng_ml": "15-40", "c_mid_ng_ml": 27.5, "mw_g_mol": 492.70,
        "fu_plasma": 0.01, "kp_uu_eff": 7.00, "alpha_d2": 0.00, "alpha_5ht2a": 0.00,
        "pet_d2_ref_range": "60-75%",
        "pk_ref": "Hiemke et al. 2018 (PMID:28910830); Wong et al. 2013",
    },
}


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------
def assert_no_nans(df: pd.DataFrame, name: str) -> None:
    """Validate that numeric columns contain zero NaNs or Infs."""
    num_cols = df.select_dtypes(include=[np.number]).columns
    if len(num_cols) > 0:
        arr = df[num_cols].to_numpy()
        if np.isnan(arr).any() or np.isinf(arr).any():
            raise ValueError(f"NaN or Inf detected in table {name}")


def sanitize_json(obj: Any) -> Any:
    """Recursively convert numpy types and verify finite JSON numbers."""
    if isinstance(obj, dict):
        return {str(k): sanitize_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [sanitize_json(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating, float)):
        val = float(obj)
        if math.isnan(val) or math.isinf(val):
            return None
        return val
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, np.ndarray):
        return sanitize_json(obj.tolist())
    return obj


# ---------------------------------------------------------------------------
# Core RC-KTF Equations (1) - (16)
# ---------------------------------------------------------------------------
# Equation Alignment Map:
#   Eq. (1)  : Clinical free brain concentration C_free,brain [nM] & D2R/5-HT2A occupancies [dimless]
#   Eq. (2)  : Arm 1 cAMP/PKA signaling ODE dA_PKA/dt [norm_unit/d]
#   Eq. (3)  : Arm 1 DARPP-32/PP1/CaMKII SRRM4 phosphorylation fraction f_phos [dimless]
#   Eq. (4)  : Arm 2 activity-dependent SRRM4 proteostasis ODE dS_tot/dt [norm_unit/d]
#   Eq. (5)  : Arm 3 5-HT2A-HDAC2 chromatin acetylation ODE dH_ac/dt & Pol II speed v_PolII [nt/s]
#   Eq. (6)  : Effective spliceosome recruitment drive S_eff [norm_unit]
#   Eq. (7)  : Co-transcriptional 3'ss recognition rate k_on(S_eff) [s^-1] & kinetic window tau_win [s]
#   Eq. (8)  : Co-transcriptional CPEB4 microexon 4 inclusion probability Psi_4 [fraction]
#   Eq. (9)  : Condensate heterotypic me4-HClust masking root C_H_free [uM]
#   Eq. (10) : De novo homotypic HClust liquid-to-solid nucleation rate k_gel [d^-1]
#   Eq. (11) : Secondary fibrillar seeding coefficient k_seed [d^-1 norm_conc^-1]
#   Eq. (12) : Soluble/liquid CPEB4(+me4) pool ODE dL_+/dt [norm_conc/d]
#   Eq. (13) : Soluble/liquid CPEB4(Delta4) pool ODE dL_Delta/dt [norm_conc/d]
#   Eq. (14) : Solid gelated aggregate pool ODE dS/dt [norm_conc/d]
#   Eq. (15) : Secondary seeding reproduction ratio R_seed [dimless] & solid fraction f_S [fraction]
#   Eq. (16) : Observable FRAP mobile fraction M_f [fraction] & target translation T_SCZ [norm_unit]
def default_params() -> dict[str, float]:
    """Return baseline mechanistic parameter dictionary across Eqs. (1)-(16)."""
    delta_l = math.log(2.0) / 2.0   # Dörrbaum et al. 2018 RBP t_1/2 = 2.0 d -> 0.34657 d^-1
    delta_s = math.log(2.0) / 10.0  # Slow autophagic aggregate clearance t_1/2 = 10.0 d -> 0.06931 d^-1
    return {
        # Co-transcriptional splicing kernel (Eqs. 5-8, calibrated to GSE276143 + GTEx v8)
        "L_intron4": L_INTRON4_NT,
        "v_PolII_HEK": 45.0,
        "v_min": 22.0,
        "v_max": 70.0,
        "K_H": 1.0,
        "k_4_0": 8.0e-5,
        "k_4_max": 0.043923202433563874,
        "K_50": 0.7929533888819087,
        "n_H": 1.5025051548041015,
        "k_skip": 0.028416607473438903,
        "s_scale_gtex": 0.2649,
        "K_tr_srrm4": 2.2815,
        "alpha_R": 1.1652,
        "alpha_S": 0.3449,
        "K_P_ptbp1": 22.5221,
        "m_neu": 2.4028,
        # Regional receptor-reserve MM constants (GTEx TPM units)
        "K_D2_reg": 4.0,
        "K_5HT_reg": 3.0,
        "K_D32_reg": 400.0,
        "K_CaMK_reg": 300.0,
        # Arm 1: cAMP/PKA - DARPP-32 - PP1 - CaMKII (Eqs. 2-3)
        "gamma_PKA": 24.0,     # d^-1 (~1 h signaling turnover)
        "k_PKA_0": 4.80,       # 0.20 * 24.0 d^-1 -> A_PKA_basal = 0.20
        "k_D2": 43.20,         # 1.80 * 24.0 d^-1
        "k0_kin": 0.45,
        "beta_PKA": 1.15,
        "beta_CaMK": 1.90,
        "k_PP1": 0.55,
        "kappa_D32": 3.20,
        "camk_scz_floor": 0.50,
        "camk_scz_gain": 0.45,
        # Arm 2: Activity-dependent SRRM4 proteostasis & PTBP1 relief (Eqs. 4, 6)
        "gamma_S0": 1.0,       # d^-1
        "beta_E": 0.2607,      # calibrated to exact SCZ PFC BA9 Psi4 = 0.5500
        "w_D2": 0.45,
        "w_5HT": 0.72,
        "ptbp_scz_mult": 1.28,
        "ptbp_relief_D2": 0.14,
        "ptbp_relief_5HT": 0.22,
        # Arm 3: 5-HT2A-HDAC2 chromatin slowing (Eq. 5; Kurita 2012, GSE174407)
        "k_HDAC_0": 0.40,      # d^-1 (~1.7 d half-time chromatin remodeling)
        "k_HAT": 0.40,
        "lambda_H": 2.60,
        "lambda_H_D2": 0.12,
        # Condensate mass-action & nucleation (Eqs. 9-11; Garcia-Cabau et al. 2025)
        "C_cond_uM": 30.0,
        "pKa_HClust": 7.15,
        "pH_cytosol": 7.20,
        "K_het_uM": 0.50,
        "C_agg_star_uM": 7.35,
        "m_coop": 10.0,
        "k_gel_max": 0.08,     # d^-1
        "k_seed_0": 0.68,      # d^-1 norm_conc^-1 (normalized via C_H_free(1))
        "K_S": 1.38,           # norm_conc (secondary nucleation saturation scale)
        # Proteostasis turnover & readouts (Eqs. 12-16; Dörrbaum et al. 2018)
        "L0_ss": 1.0,
        "delta_L": delta_l,
        "sigma": delta_l * 1.0,
        "delta_S": delta_s,
        "k_dis": 0.0,
        "M_f_liq": 0.85,
        "M_f_sol": 0.10,
        "T_max": 1.0,
        "K_T": 0.40,
        "eta_T": 0.15,
    }


def eq1_occupancy(drug_name: str, drd2_ki_nm: float, htr2a_ki_nm: float) -> dict[str, float]:
    """Compute Eq. (1) clinical free brain concentration & receptor occupancies."""
    pk = PK_TABLE[drug_name]
    c_free_nm = (pk["c_mid_ng_ml"] * 1000.0 / pk["mw_g_mol"]) * pk["fu_plasma"] * pk["kp_uu_eff"]
    theta_d2 = c_free_nm / (c_free_nm + drd2_ki_nm)
    theta_5ht2a = c_free_nm / (c_free_nm + htr2a_ki_nm)
    dtheta_d2 = (1.0 - pk["alpha_d2"]) * theta_d2
    dtheta_5ht2a = (1.0 - pk["alpha_5ht2a"]) * theta_5ht2a
    return {
        "c_free_brain_nm": c_free_nm,
        "theta_d2": theta_d2,
        "dtheta_d2_eff": dtheta_d2,
        "theta_5ht2a": theta_5ht2a,
        "dtheta_5ht2a_eff": dtheta_5ht2a,
    }


def eq7_8_psi4(
    S_eff: np.ndarray | float,
    v_pol: np.ndarray | float,
    p: dict[str, float],
) -> np.ndarray | float:
    """Compute Eq. (7)-(8) co-transcriptional microexon inclusion probability Psi_4."""
    s_pos = np.maximum(S_eff, 0.0)
    k_on = p["k_4_0"] + p["k_4_max"] * (s_pos ** p["n_H"]) / (p["K_50"] ** p["n_H"] + s_pos ** p["n_H"] + 1e-30)
    tau_win = p["L_intron4"] / v_pol
    return 1.0 - (p["k_skip"] / (k_on + p["k_skip"])) * np.exp(-k_on * tau_win)


def eq8_analytical_elasticities(S_eff: float, v_pol: float, p: dict[str, float]) -> tuple[float, float]:
    """Exact closed-form logarithmic elasticities d ln Psi_4 / d ln S_eff and -d ln Psi_4 / d ln v_PolII."""
    nH = p["n_H"]
    K50 = p["K_50"]
    k40 = p["k_4_0"]
    k4m = p["k_4_max"]
    ks = p["k_skip"]
    tau_win = p["L_intron4"] / v_pol

    s_nh = S_eff ** nH
    k_nh = K50 ** nH
    k_on = k40 + k4m * s_nh / (k_nh + s_nh)
    q = (ks / (k_on + ks)) * math.exp(-k_on * tau_win)
    psi4 = 1.0 - q

    dpsi_dkon = q * (1.0 / (k_on + ks) + tau_win)
    dkon_dlns = nH * (k_on - k40) * k_nh / (k_nh + s_nh)
    e_seff = (1.0 / psi4) * dpsi_dkon * dkon_dlns
    neg_e_vpol = (q / psi4) * k_on * tau_win
    return e_seff, neg_e_vpol


def eq9_c_h_free(
    chi_L: np.ndarray | float,
    p: dict[str, float],
    P_pep_uM: float = 0.0,
    pH: float | None = None,
    C_cond_uM: float | None = None,
) -> np.ndarray | float:
    """Compute Eq. (9) exact mass-action free deprotonated HClust concentration (uM)."""
    c_tot = p["C_cond_uM"] if C_cond_uM is None else C_cond_uM
    ph_val = p["pH_cytosol"] if pH is None else pH
    f_h = 1.0 / (1.0 + 10.0 ** (p["pKa_HClust"] - ph_val))
    k_het = p["K_het_uM"]
    b = chi_L * c_tot - P_pep_uM - k_het
    return 0.5 * f_h * (b + np.sqrt(b * b + 4.0 * k_het * c_tot))


def eq10_11_rates(
    chi_L: np.ndarray | float,
    p: dict[str, float],
    P_pep_uM: float = 0.0,
    pH: float | None = None,
) -> tuple[np.ndarray | float, np.ndarray | float]:
    """Compute Eq. (10) nucleation rate k_gel and Eq. (11) fibrillar seeding coefficient k_seed."""
    ch = eq9_c_h_free(chi_L, p, P_pep_uM=P_pep_uM, pH=pH)
    ch_ref = eq9_c_h_free(1.0, p, P_pep_uM=0.0, pH=p["pH_cytosol"])
    m = p["m_coop"]
    c_star = p["C_agg_star_uM"]
    k_gel = p["k_gel_max"] * (ch ** m) / (c_star ** m + ch ** m)
    k_seed = p["k_seed_0"] * (ch / ch_ref)
    return k_gel, k_seed


def regional_context(
    row: pd.Series,
    ref_medians: dict[str, float],
    p: dict[str, float],
    dth_d2: float = 0.0,
    dth_5ht: float = 0.0,
    scz: bool = True,
    arm_flags: tuple[bool, bool, bool, bool] = (True, True, True, True),
) -> dict[str, float]:
    """Compute regional receptor densities & effective forcing rates for Eqs. (2)-(6)."""
    arm1, arm2, arm3, arm_ptbp = arm_flags
    r_d2 = float(row["DRD2"]) / (p["K_D2_reg"] + float(row["DRD2"]))
    r_5ht = float(row["HTR2A"]) / (p["K_5HT_reg"] + float(row["HTR2A"]))
    r_d32 = float(row["PPP1R1B"]) / (p["K_D32_reg"] + float(row["PPP1R1B"]))
    r_camk = float(row["CAMK2A"]) / (p["K_CaMK_reg"] + float(row["CAMK2A"]))

    s_tot_base = p["m_neu"] * p["s_scale_gtex"] * float(row["SRRM4"]) / (p["K_tr_srrm4"] + float(row["SRRM4"]))
    sigma_s = p["gamma_S0"] * s_tot_base
    hdac_rel = float(row["HDAC2"]) / ref_medians["HDAC2"]
    h_ac_base = 1.0 / hdac_rel

    if not scz:
        dth_d2_1 = dth_5ht_1 = dth_d2_2 = dth_5ht_2 = dth_d2_3 = dth_5ht_3 = 0.0
        a_camk = r_camk * 1.0
        ptbp_mult = 1.0
        e_exc = 0.0
    else:
        dth_d2_1 = dth_d2 if arm1 else 0.0
        dth_5ht_1 = dth_5ht if arm1 else 0.0
        dth_d2_2 = dth_d2 if arm2 else 0.0
        dth_5ht_2 = dth_5ht if arm2 else 0.0
        dth_d2_3 = dth_d2 if arm3 else 0.0
        dth_5ht_3 = dth_5ht if arm3 else 0.0
        dth_d2_p = dth_d2 if arm_ptbp else 0.0
        dth_5ht_p = dth_5ht if arm_ptbp else 0.0

        e_exc = max(0.0, 1.0 - (p["w_D2"] * r_d2 * dth_d2_2 + p["w_5HT"] * r_5ht * dth_5ht_2))
        camk_norm = p["camk_scz_floor"] + p["camk_scz_gain"] * (0.35 * r_d2 * dth_d2_1 + 0.65 * r_5ht * dth_5ht_1)
        a_camk = r_camk * camk_norm
        ptbp_mult = p["ptbp_scz_mult"] * (1.0 - (p["ptbp_relief_D2"] * r_d2 * dth_d2_p + p["ptbp_relief_5HT"] * r_5ht * dth_5ht_p))

    k_hdac_reg = p["k_HDAC_0"] * hdac_rel * (1.0 + p["lambda_H"] * r_5ht * dth_5ht_3 + p["lambda_H_D2"] * r_d2 * dth_d2_3)
    k_hat_reg = p["k_HDAC_0"]
    gamma_s_eff = p["gamma_S0"] * (1.0 + p["beta_E"] * e_exc)
    cof_rnps_srsf = ((float(row["RNPS1"]) / ref_medians["RNPS1"]) ** p["alpha_R"]) * (
        (float(row["SRSF11"]) / ref_medians["SRSF11"]) ** p["alpha_S"]
    )
    ptbp_denom = 1.0 + (ptbp_mult * float(row["PTBP1"])) / p["K_P_ptbp1"]

    return {
        "r_d2": r_d2, "r_5ht": r_5ht, "r_d32": r_d32, "r_camk": r_camk,
        "dth_d2_1": dth_d2_1, "sigma_s": sigma_s, "gamma_s_eff": gamma_s_eff,
        "k_hat_reg": k_hat_reg, "k_hdac_reg": k_hdac_reg, "h_ac_base": h_ac_base,
        "a_camk": a_camk, "cof_rnps_srsf": cof_rnps_srsf, "ptbp_denom": ptbp_denom,
        "e_exc": e_exc, "ptbp_mult": ptbp_mult, "hdac_rel": hdac_rel,
    }


def ctx_psi4_from_states(a_pka: float, s_tot: float, h_ac: float, ctx: dict[str, float], p: dict[str, float]) -> dict[str, float]:
    """Evaluate Eq. (3) f_phos, Eq. (6) S_eff, Eq. (5) v_PolII, Eq. (7) tau_win, and Eq. (8) Psi_4."""
    k_kin = p["k0_kin"] + p["beta_PKA"] * a_pka + p["beta_CaMK"] * ctx["a_camk"]
    k_pp1_eff = p["k_PP1"] / (1.0 + p["kappa_D32"] * ctx["r_d32"] * a_pka)
    f_phos = k_kin / (k_kin + k_pp1_eff)
    s_eff = f_phos * s_tot * ctx["cof_rnps_srsf"] / ctx["ptbp_denom"]
    v_pol = p["v_min"] + (p["v_max"] - p["v_min"]) * h_ac / (p["K_H"] + h_ac)
    psi4 = float(eq7_8_psi4(s_eff, v_pol, p))
    return {"f_phos": f_phos, "S_eff": s_eff, "v_pol": v_pol, "tau_win": p["L_intron4"] / v_pol, "Psi4": psi4}


def steady_upstream(ctx: dict[str, float], p: dict[str, float]) -> dict[str, float]:
    """Compute steady-state upstream variables (A_PKA*, S_tot*, H_ac*) and resulting Psi_4*."""
    a_pka_ss = (p["k_PKA_0"] + p["k_D2"] * ctx["r_d2"] * ctx["dth_d2_1"]) / p["gamma_PKA"]
    s_tot_ss = ctx["sigma_s"] / ctx["gamma_s_eff"]
    h_ac_ss = ctx["k_hat_reg"] / ctx["k_hdac_reg"]
    out = ctx_psi4_from_states(a_pka_ss, s_tot_ss, h_ac_ss, ctx, p)
    out.update({"A_PKA_ss": a_pka_ss, "S_tot_ss": s_tot_ss, "H_ac_ss": h_ac_ss})
    return out


def rc_ktf_ode_rhs(
    t: float,
    y: np.ndarray,
    ctx: dict[str, float],
    p: dict[str, float],
    P_pep_uM: float = 0.0,
    mult_dS: float = 1.0,
    k_dis: float | None = None,
) -> np.ndarray:
    """Autonomous 6-ODE RC-KTF RHS for Eqs. (2),(4),(5),(12)-(14): y = [A_PKA, S_tot, H_ac, L_+, L_Delta, S]."""
    del t  # strictly autonomous
    a_pka, s_tot, h_ac, l_p, l_d, s_agg = y
    k_dis_val = p["k_dis"] if k_dis is None else k_dis
    dS_eff = p["delta_S"] * mult_dS

    da_pka = p["k_PKA_0"] + p["k_D2"] * ctx["r_d2"] * ctx["dth_d2_1"] - p["gamma_PKA"] * a_pka
    ds_tot = ctx["sigma_s"] - ctx["gamma_s_eff"] * s_tot
    dh_ac = ctx["k_hat_reg"] - ctx["k_hdac_reg"] * h_ac

    sp = ctx_psi4_from_states(a_pka, s_tot, h_ac, ctx, p)
    psi4 = sp["Psi4"]

    l_tot = max(l_p + l_d, 1e-12)
    chi_l = l_d / l_tot
    k_gel, k_seed = eq10_11_rates(chi_l, p, P_pep_uM=P_pep_uM)
    flux = float(k_gel) + float(k_seed) * (s_agg * s_agg) / (p["K_S"] + s_agg)

    dl_p = p["sigma"] * psi4 - p["delta_L"] * l_p - flux * l_p + k_dis_val * s_agg
    dl_d = p["sigma"] * (1.0 - psi4) - p["delta_L"] * l_d - flux * l_d
    ds_agg = flux * l_tot - (dS_eff + k_dis_val) * s_agg
    return np.array([da_pka, ds_tot, dh_ac, dl_p, dl_d, ds_agg], dtype=float)


def rc_ktf_analytical_jacobian(
    y: np.ndarray,
    ctx: dict[str, float],
    p: dict[str, float],
    P_pep_uM: float = 0.0,
    mult_dS: float = 1.0,
    k_dis: float | None = None,
) -> np.ndarray:
    """Exact analytical 6x6 Jacobian dF/dy of Eqs. (2)-(14)."""
    a_pka, s_tot, h_ac, l_p, l_d, s_agg = y
    k_dis_val = p["k_dis"] if k_dis is None else k_dis
    dS_eff = p["delta_S"] * mult_dS

    J = np.zeros((6, 6), dtype=float)
    # Upper 3 decoupled linear ODEs
    J[0, 0] = -p["gamma_PKA"]
    J[1, 1] = -ctx["gamma_s_eff"]
    J[2, 2] = -ctx["k_hdac_reg"]

    # Upstream partial derivatives dPsi_4 / d(A_PKA, S_tot, H_ac)
    k_kin = p["k0_kin"] + p["beta_PKA"] * a_pka + p["beta_CaMK"] * ctx["a_camk"]
    inv_term = 1.0 + p["kappa_D32"] * ctx["r_d32"] * a_pka
    k_pp1_eff = p["k_PP1"] / inv_term
    denom_fp = k_kin + k_pp1_eff
    f_phos = k_kin / denom_fp

    dkkin_da = p["beta_PKA"]
    dkpp1_da = -p["k_PP1"] * p["kappa_D32"] * ctx["r_d32"] / (inv_term * inv_term)
    dfp_da = (dkkin_da * k_pp1_eff - k_kin * dkpp1_da) / (denom_fp * denom_fp)

    cof = ctx["cof_rnps_srsf"] / ctx["ptbp_denom"]
    s_eff = f_phos * s_tot * cof
    dSeff_da = dfp_da * s_tot * cof
    dSeff_ds = f_phos * cof

    v_pol = p["v_min"] + (p["v_max"] - p["v_min"]) * h_ac / (p["K_H"] + h_ac)
    dv_dh = (p["v_max"] - p["v_min"]) * p["K_H"] / ((p["K_H"] + h_ac) ** 2)
    tau_win = p["L_intron4"] / v_pol
    dtau_dh = -(p["L_intron4"] / (v_pol * v_pol)) * dv_dh

    nH = p["n_H"]
    K50 = p["K_50"]
    s_nh = s_eff ** nH
    k_nh = K50 ** nH
    k_on = p["k_4_0"] + p["k_4_max"] * s_nh / (k_nh + s_nh)
    q = (p["k_skip"] / (k_on + p["k_skip"])) * math.exp(-k_on * tau_win)
    dpsi_dkon = q * (1.0 / (k_on + p["k_skip"]) + tau_win)
    dkon_dseff = p["k_4_max"] * nH * (s_eff ** (nH - 1.0)) * k_nh / ((k_nh + s_nh) ** 2)

    dpsi_da = dpsi_dkon * dkon_dseff * dSeff_da
    dpsi_ds = dpsi_dkon * dkon_dseff * dSeff_ds
    dpsi_dh = q * k_on * dtau_dh

    J[3, 0] = p["sigma"] * dpsi_da
    J[3, 1] = p["sigma"] * dpsi_ds
    J[3, 2] = p["sigma"] * dpsi_dh
    J[4, 0] = -p["sigma"] * dpsi_da
    J[4, 1] = -p["sigma"] * dpsi_ds
    J[4, 2] = -p["sigma"] * dpsi_dh

    # Lower 3 condensate proteostasis couplings (L_plus, L_delta, S)
    l_tot = l_p + l_d
    chi_l = l_d / l_tot
    dchi_dlp = -l_d / (l_tot * l_tot)
    dchi_dld = l_p / (l_tot * l_tot)

    c_tot = p["C_cond_uM"]
    f_h = 1.0 / (1.0 + 10.0 ** (p["pKa_HClust"] - p["pH_cytosol"]))
    b = chi_l * c_tot - P_pep_uM - p["K_het_uM"]
    rad = math.sqrt(b * b + 4.0 * p["K_het_uM"] * c_tot)
    ch = 0.5 * f_h * (b + rad)
    dch_dchi = 0.5 * f_h * c_tot * (1.0 + b / rad)

    ch_ref = float(eq9_c_h_free(1.0, p, P_pep_uM=0.0))
    m = p["m_coop"]
    c_star = p["C_agg_star_uM"]
    k_gel = p["k_gel_max"] * (ch ** m) / (c_star ** m + ch ** m)
    dkgel_dch = p["k_gel_max"] * m * (ch ** (m - 1.0)) * (c_star ** m) / ((c_star ** m + ch ** m) ** 2)
    k_seed = p["k_seed_0"] * ch / ch_ref
    dkseed_dch = p["k_seed_0"] / ch_ref

    s_fac = (s_agg * s_agg) / (p["K_S"] + s_agg)
    dsfac_dS = (2.0 * s_agg * (p["K_S"] + s_agg) - s_agg * s_agg) / ((p["K_S"] + s_agg) ** 2)

    flux = k_gel + k_seed * s_fac
    dflux_dch = dkgel_dch + dkseed_dch * s_fac
    dflux_dlp = dflux_dch * dch_dchi * dchi_dlp
    dflux_dld = dflux_dch * dch_dchi * dchi_dld
    dflux_dS = k_seed * dsfac_dS

    J[3, 3] = -p["delta_L"] - flux - l_p * dflux_dlp
    J[3, 4] = -l_p * dflux_dld
    J[3, 5] = -l_p * dflux_dS + k_dis_val

    J[4, 3] = -l_d * dflux_dlp
    J[4, 4] = -p["delta_L"] - flux - l_d * dflux_dld
    J[4, 5] = -l_d * dflux_dS

    J[5, 3] = flux + l_tot * dflux_dlp
    J[5, 4] = flux + l_tot * dflux_dld
    J[5, 5] = l_tot * dflux_dS - (dS_eff + k_dis_val)
    return J


def init_proteostasis_state(f_s0: float, psi4_0: float, p: dict[str, float]) -> tuple[float, float, float]:
    """Initialize mass-balanced (L_+, L_Delta, S) along turnover invariant delta_L*L + delta_S*S = sigma."""
    ratio = f_s0 / (1.0 - f_s0)
    l_init = p["sigma"] / (p["delta_L"] + p["delta_S"] * ratio)
    s_init = l_init * ratio
    return psi4_0 * l_init, (1.0 - psi4_0) * l_init, s_init


def eq16_readouts(l_p: float, l_d: float, s_agg: float, p: dict[str, float]) -> dict[str, float]:
    """Compute Eq. (15) solid fraction f_S and Eq. (16) FRAP mobile fraction M_f & target translation T_SCZ."""
    l_tot = l_p + l_d
    tot = l_tot + s_agg
    f_s = s_agg / tot
    m_f = (l_tot * p["M_f_liq"] + s_agg * p["M_f_sol"]) / tot
    eff_pool = l_p + p["eta_T"] * l_d
    t_scz = p["T_max"] * eff_pool / (p["K_T"] + eff_pool)
    return {"L_tot": l_tot, "S": s_agg, "total_mass": tot, "f_S": f_s, "M_f": m_f, "T_SCZ": t_scz}


def find_proteostasis_steady_states(
    psi4: float,
    p: dict[str, float],
    P_pep_uM: float = 0.0,
    mult_dS: float = 1.0,
    k_dis: float | None = None,
) -> list[dict[str, float]]:
    """Find all equilibrium roots (Liquid_SS, Saddle_Separatrix, Gelated_SS) of Eqs. (12)-(14) & Eq. (15) R_seed."""
    k_dis_val = p["k_dis"] if k_dis is None else k_dis
    dS_eff = p["delta_S"] * mult_dS
    # Note: for k_dis > 0, chi_L^* solves steady-state ratio rather than chi = 1 - psi4;
    # Here we solve the exact steady-state system in terms of S along exact mass-balance line!
    # At k_dis == 0, chi_L^* == 1 - psi4 exactly; at k_dis > 0, L_+(S), L_Delta(S) follow linear Eqs (12)-(13).
    s_max = (p["sigma"] / dS_eff) * 0.999999

    def rhs_s(s_val: float) -> float:
        l_tot = (p["sigma"] - dS_eff * s_val) / p["delta_L"]
        if l_tot <= 1e-15:
            return -1e9
        if k_dis_val == 0.0:
            chi = 1.0 - psi4
            kg, ks = eq10_11_rates(chi, p, P_pep_uM=P_pep_uM)
            return (float(kg) + float(ks) * (s_val * s_val) / (p["K_S"] + s_val)) * l_tot - dS_eff * s_val
        # Fixed point for chi when k_dis > 0: L_d = sigma*(1-psi4)/(delta_L + flux)
        # Since flux * L_tot = (dS_eff + k_dis_val)*S, flux = (dS_eff + k_dis_val)*S / L_tot!
        flux = (dS_eff + k_dis_val) * s_val / l_tot
        l_d = p["sigma"] * (1.0 - psi4) / (p["delta_L"] + flux)
        chi = min(max(l_d / l_tot, 0.0), 1.0)
        kg, ks = eq10_11_rates(chi, p, P_pep_uM=P_pep_uM)
        return (float(kg) + float(ks) * (s_val * s_val) / (p["K_S"] + s_val)) * l_tot - (dS_eff + k_dis_val) * s_val

    grid = np.concatenate(([0.0], np.logspace(-16, math.log10(s_max), 2500)))
    vals = np.array([rhs_s(float(s)) for s in grid])
    roots: list[float] = []
    for i in range(len(grid) - 1):
        if vals[i] == 0.0:
            roots.append(float(grid[i]))
        elif vals[i] * vals[i + 1] < 0.0:
            r = brentq(rhs_s, float(grid[i]), float(grid[i + 1]), xtol=1e-13)
            if not roots or abs(r - roots[-1]) > 1e-10:
                roots.append(float(r))

    out = []
    for r in roots:
        l_tot = (p["sigma"] - dS_eff * r) / p["delta_L"]
        flux = (dS_eff + k_dis_val) * r / max(l_tot, 1e-15)
        l_d = p["sigma"] * (1.0 - psi4) / (p["delta_L"] + flux)
        l_p = l_tot - l_d
        chi = l_d / l_tot
        _, k_seed_val = eq10_11_rates(chi, p, P_pep_uM=P_pep_uM)
        r_seed = float(k_seed_val) * l_tot / (dS_eff + k_dis_val)
        rd = eq16_readouts(l_p, l_d, r, p)
        out.append({
            "S_ss": r, "L_plus_ss": l_p, "L_delta_ss": l_d, "L_tot_ss": l_tot,
            "chi_L_ss": chi, "f_S_ss": rd["f_S"], "M_f_ss": rd["M_f"], "R_seed": r_seed,
        })
    return out


# ---------------------------------------------------------------------------
# Phase 1 data calibration & out-of-sample CV (GSE276143 & GTEx v8)
# ---------------------------------------------------------------------------
def fit_and_cv_gse276143(gse_df: pd.DataFrame, p: dict[str, float]) -> tuple[dict[str, Any], pd.DataFrame]:
    """Fit Eq. (7)-(8) on GSE276143 WT dose data, run 6-fold LORO CV and 2,000 bootstraps."""
    s_map = {0: 0.0, 1: 0.10, 2: 1.0, 3: 5.0}
    s_vals = gse_df["srrm4_tier_order"].map(s_map).to_numpy(dtype=float)
    y_vals = gse_df["psi_frac"].to_numpy(dtype=float)
    reps = gse_df["replicate"].to_numpy()
    v_hek = p["v_PolII_HEK"]
    k40 = p["k_4_0"]

    def model_fn(s: np.ndarray, K50: float, nH: float, k4m: float, kskip: float) -> np.ndarray:
        kon = k40 + k4m * (s ** nH) / (K50 ** nH + s ** nH + 1e-30)
        return 1.0 - (kskip / (kon + kskip)) * np.exp(-kon * L_INTRON4_NT / v_hek)

    p0 = [0.75, 1.50, 0.044, 0.028]
    bounds = ([0.05, 0.50, 1e-4, 1e-4], [10.0, 5.0, 1.0, 1.0])
    popt, _ = curve_fit(model_fn, s_vals, y_vals, p0=p0, bounds=bounds, maxfev=10000)
    y_in = model_fn(s_vals, *popt)

    # 6-fold Leave-One-Replicate-Out cross-validation
    cv_preds = np.zeros_like(y_vals)
    unique_reps = np.unique(reps)
    for rep in unique_reps:
        tr = reps != rep
        te = reps == rep
        pop_cv, _ = curve_fit(model_fn, s_vals[tr], y_vals[tr], p0=popt, bounds=bounds, maxfev=10000)
        cv_preds[te] = model_fn(s_vals[te], *pop_cv)

    ss_tot = float(np.sum((y_vals - y_vals.mean()) ** 2))
    r2_in = 1.0 - float(np.sum((y_vals - y_in) ** 2)) / ss_tot
    r2_cv = 1.0 - float(np.sum((y_vals - cv_preds) ** 2)) / ss_tot
    rmse_cv = float(np.sqrt(np.mean((y_vals - cv_preds) ** 2)))
    mae_cv = float(np.mean(np.abs(y_vals - cv_preds)))

    # 2,000 stratified replicate-cluster + residual bootstraps
    rng = np.random.default_rng(SEED)
    n_boot = 2000
    boot_params = np.zeros((n_boot, 4))
    tiers = gse_df["srrm4_tier_order"].to_numpy()
    unique_tiers = np.unique(tiers)
    tier_idx = [np.where(tiers == t)[0] for t in unique_tiers]

    for b in range(n_boot):
        idx = np.concatenate([rng.choice(ti, size=len(ti), replace=True) for ti in tier_idx])
        try:
            pb, _ = curve_fit(model_fn, s_vals[idx], y_vals[idx], p0=popt, bounds=bounds, maxfev=5000)
            boot_params[b] = pb
        except RuntimeError:
            boot_params[b] = popt

    param_names = ["K_50", "n_H", "k_4_max", "k_skip"]
    boot_ci = {
        nm: [float(np.percentile(boot_params[:, i], 2.5)), float(np.percentile(boot_params[:, i], 97.5))]
        for i, nm in enumerate(param_names)
    }

    p["K_50"], p["n_H"], p["k_4_max"], p["k_skip"] = [float(x) for x in popt]

    out_df = gse_df[["replicate", "condition", "srrm4_tier_order", "psi_frac"]].copy()
    out_df["S_eff_tier"] = s_vals
    out_df["psi_pred_insample"] = y_in
    out_df["psi_pred_loro_cv"] = cv_preds
    out_df["residual_cv"] = y_vals - cv_preds
    assert_no_nans(out_df, "gse276143_cv_predictions")

    summary = {
        "n_obs": len(y_vals),
        "n_replicates": len(unique_reps),
        "r2_insample": r2_in,
        "r2_loro_cv": r2_cv,
        "rmse_loro_cv": rmse_cv,
        "mae_loro_cv": mae_cv,
        "fitted_params": dict(zip(param_names, [float(x) for x in popt])),
        "bootstrap_95ci": boot_ci,
        "boot_draws": boot_params,
    }
    return summary, out_df


def fit_and_cv_gtex_brain13(gtex_df: pd.DataFrame, p: dict[str, float]) -> tuple[dict[str, Any], pd.DataFrame]:
    """Transfer GSE276143 splicing kernel to GTEx v8 13 brain regions and run LOOCV."""
    rnps0 = float(gtex_df["RNPS1"].median())
    srsf0 = float(gtex_df["SRSF11"].median())
    hdac0 = float(gtex_df["HDAC2"].median())

    srrm4_all = gtex_df["SRRM4"].to_numpy(dtype=float)
    rnps_rel_all = gtex_df["RNPS1"].to_numpy(dtype=float) / rnps0
    srsf_rel_all = gtex_df["SRSF11"].to_numpy(dtype=float) / srsf0
    ptbp_all = gtex_df["PTBP1"].to_numpy(dtype=float)
    h_ac_all = hdac0 / gtex_df["HDAC2"].to_numpy(dtype=float)
    v_pol_all = p["v_min"] + (p["v_max"] - p["v_min"]) * h_ac_all / (p["K_H"] + h_ac_all)
    tau_all = p["L_intron4"] / v_pol_all
    y_obs = gtex_df["PSI4"].to_numpy(dtype=float)
    k40 = p["k_4_0"]
    k4m = p["k_4_max"]
    k50_nh = p["K_50"] ** p["n_H"]
    n_h = p["n_H"]
    kskip = p["k_skip"]

    def predict_idx(idx: np.ndarray, theta: np.ndarray) -> np.ndarray:
        s_sc, k_tr, a_r, a_s, k_p = theta
        sr = srrm4_all[idx]
        s_tot = s_sc * sr / (k_tr + sr)
        s_eff = (
            s_tot
            * (rnps_rel_all[idx] ** a_r)
            * (srsf_rel_all[idx] ** a_s)
            / (1.0 + ptbp_all[idx] / k_p)
        )
        s_nh = s_eff ** n_h
        k_on = k40 + k4m * s_nh / (k50_nh + s_nh + 1e-30)
        return 1.0 - (kskip / (k_on + kskip)) * np.exp(-k_on * tau_all[idx])

    theta0 = np.array([0.26, 2.2, 1.15, 0.35, 22.0])
    bounds = [(0.05, 2.0), (0.2, 15.0), (0.0, 3.0), (0.0, 2.0), (5.0, 80.0)]

    def fit_idx(idx: np.ndarray, init: np.ndarray) -> np.ndarray:
        y_sub = y_obs[idx]
        res = minimize(
            lambda th: float(np.sum((predict_idx(idx, th) - y_sub) ** 2)),
            init, method="L-BFGS-B", bounds=bounds,
        )
        return res.x

    all_idx = np.arange(len(gtex_df))
    theta_full = fit_idx(all_idx, theta0)
    y_in = predict_idx(all_idx, theta_full)

    # Leave-One-Brain-Region-Out CV
    y_loocv = np.zeros_like(y_obs)
    loocv_thetas = np.zeros((len(gtex_df), 5))
    for i in range(len(gtex_df)):
        tr_idx = np.delete(all_idx, i)
        te_idx = np.array([i])
        th_i = fit_idx(tr_idx, theta_full)
        loocv_thetas[i] = th_i
        y_loocv[i] = predict_idx(te_idx, th_i)[0]

    ss_tot = float(np.sum((y_obs - y_obs.mean()) ** 2))
    r2_in = 1.0 - float(np.sum((y_obs - y_in) ** 2)) / ss_tot
    r2_cv = 1.0 - float(np.sum((y_obs - y_loocv) ** 2)) / ss_tot
    rmse_cv = float(np.sqrt(np.mean((y_obs - y_loocv) ** 2)))
    mae_cv = float(np.mean(np.abs(y_obs - y_loocv)))
    rho_cv = float(spearmanr(y_obs, y_loocv).statistic)

    # Bootstrap GTEx region transfer parameters (2,000 resamples)
    rng = np.random.default_rng(SEED)
    n_boot = 2000
    n_reg = len(gtex_df)
    boot_th = np.zeros((n_boot, 5))
    for b in range(n_boot):
        idx = rng.integers(0, n_reg, size=n_reg)
        boot_th[b] = fit_idx(idx, theta_full)

    p_names = ["s_scale_gtex", "K_tr_srrm4", "alpha_R", "alpha_S", "K_P_ptbp1"]
    p["s_scale_gtex"], p["K_tr_srrm4"], p["alpha_R"], p["alpha_S"], p["K_P_ptbp1"] = [float(x) for x in theta_full]
    boot_ci = {
        nm: [float(np.percentile(boot_th[:, i], 2.5)), float(np.percentile(boot_th[:, i], 97.5))]
        for i, nm in enumerate(p_names)
    }

    out_df = gtex_df[["tissueSiteDetailAbbr", "tissueSiteDetail", "PSI4", "SRRM4", "RNPS1", "SRSF11", "PTBP1", "HDAC2"]].copy()
    out_df["psi_pred_insample"] = y_in
    out_df["psi_pred_loocv"] = y_loocv
    out_df["residual_loocv"] = y_obs - y_loocv
    assert_no_nans(out_df, "gtex_brain13_loocv")

    summary = {
        "n_regions": len(gtex_df),
        "r2_insample": r2_in,
        "r2_loocv": r2_cv,
        "rmse_loocv": rmse_cv,
        "mae_loocv": mae_cv,
        "spearman_rho_loocv": rho_cv,
        "fitted_params": dict(zip(p_names, [float(x) for x in theta_full])),
        "bootstrap_95ci": boot_ci,
    }
    return summary, out_df


def calibrate_neuronal_scz_anchors(
    ba9_row: pd.Series, ref_medians: dict[str, float], p: dict[str, float]
) -> dict[str, float]:
    """Calibrate neuronal enrichment m_neu (Healthy BA9 -> Psi4=0.7000) and beta_E (SCZ BA9 -> Psi4=0.5500)."""
    def healthy_res(m: float) -> float:
        p_tmp = dict(p, m_neu=m)
        ctx = regional_context(ba9_row, ref_medians, p_tmp, scz=False)
        return steady_upstream(ctx, p_tmp)["Psi4"] - 0.7000

    p["m_neu"] = float(brentq(healthy_res, 0.5, 8.0, xtol=1e-12))

    def scz_res(b: float) -> float:
        p_tmp = dict(p, beta_E=b)
        ctx = regional_context(ba9_row, ref_medians, p_tmp, scz=True)
        return steady_upstream(ctx, p_tmp)["Psi4"] - 0.5500

    p["beta_E"] = float(brentq(scz_res, 0.01, 2.0, xtol=1e-12))
    return {"m_neu": p["m_neu"], "beta_E": p["beta_E"]}


# ---------------------------------------------------------------------------
# Section 1 Self-Verification Suite
# ---------------------------------------------------------------------------
def run_analytical_and_solver_tests(
    ba9_row: pd.Series, ref_medians: dict[str, float], p: dict[str, float], chembl_df: pd.DataFrame
) -> dict[str, Any]:
    """Verify mass-action conservation, closed-form elasticities, Jacobian eigenvalues, tolerance invariance, mass balance."""
    # 1. Eq. (9) mass-action conservation residuals across chi, pH, P_pep
    max_eq9_res_1 = 0.0
    max_eq9_res_2 = 0.0
    for chi in [0.0, 0.15, 0.30, 0.45, 0.75, 1.0]:
        for pep in [0.0, 15.0, 30.0]:
            for ph in [6.9, 7.12, 7.20, 7.50]:
                f_h = 1.0 / (1.0 + 10.0 ** (p["pKa_HClust"] - ph))
                c_tot = p["C_cond_uM"]
                k_het = p["K_het_uM"]
                c_h_free = float(eq9_c_h_free(chi, p, P_pep_uM=pep, pH=ph))
                h_free_tot = c_h_free / f_h
                m_tot = (1.0 - chi) * c_tot + pep
                hm = c_tot - h_free_tot
                m_free = m_tot - hm
                res1 = abs(h_free_tot * m_free / k_het - hm)
                res2 = abs(c_h_free * (1.0 + m_tot / (k_het + h_free_tot)) - f_h * c_tot)
                max_eq9_res_1 = max(max_eq9_res_1, res1)
                max_eq9_res_2 = max(max_eq9_res_2, res2)

    # 2. Eq. (8) analytical vs finite-difference elasticities
    max_elast_err = 0.0
    eps = 1e-6
    for s_val in [0.2, 0.5, 0.8, 1.5, 3.0]:
        for v_val in [28.0, 45.0, 62.0]:
            e_s_an, neg_e_v_an = eq8_analytical_elasticities(s_val, v_val, p)
            e_s_fd = (
                math.log(float(eq7_8_psi4(s_val * math.exp(eps), v_val, p)))
                - math.log(float(eq7_8_psi4(s_val * math.exp(-eps), v_val, p)))
            ) / (2.0 * eps)
            neg_e_v_fd = -(
                math.log(float(eq7_8_psi4(s_val, v_val * math.exp(eps), p)))
                - math.log(float(eq7_8_psi4(s_val, v_val * math.exp(-eps), p)))
            ) / (2.0 * eps)
            max_elast_err = max(max_elast_err, abs(e_s_an - e_s_fd), abs(neg_e_v_an - neg_e_v_fd))

    # 3. Analytical vs numerical 6x6 Jacobian & bistability eigenvalue verification under RISPERIDONE (BA9)
    ris = chembl_df[chembl_df["drug_name"] == "RISPERIDONE"].iloc[0]
    occ = eq1_occupancy("RISPERIDONE", float(ris["drd2_median_ki_nm"]), float(ris["htr2a_median_ki_nm"]))
    ctx = regional_context(ba9_row, ref_medians, p, dth_d2=occ["dtheta_d2_eff"], dth_5ht=occ["dtheta_5ht2a_eff"], scz=True)
    up = steady_upstream(ctx, p)
    roots = find_proteostasis_steady_states(up["Psi4"], p)
    assert len(roots) == 3, f"Expected 3 bistable steady states under RISPERIDONE BA9, found {len(roots)}"

    max_jac_err = 0.0
    ss_eigs: list[dict[str, Any]] = []
    labels = ["Liquid_SS", "Saddle_Separatrix", "Gelated_SS"]
    h_fd = 1e-7
    for lbl, r in zip(labels, roots):
        y_ss = np.array([up["A_PKA_ss"], up["S_tot_ss"], up["H_ac_ss"], r["L_plus_ss"], r["L_delta_ss"], r["S_ss"]])
        rhs_norm = float(np.linalg.norm(rc_ktf_ode_rhs(0.0, y_ss, ctx, p)))
        J_an = rc_ktf_analytical_jacobian(y_ss, ctx, p)
        J_num = np.zeros((6, 6))
        for j in range(6):
            dy = np.zeros(6)
            dy[j] = h_fd
            J_num[:, j] = (rc_ktf_ode_rhs(0.0, y_ss + dy, ctx, p) - rc_ktf_ode_rhs(0.0, y_ss - dy, ctx, p)) / (2.0 * h_fd)
        jac_err = float(np.max(np.abs(J_an - J_num)))
        max_jac_err = max(max_jac_err, jac_err)
        eigs = np.linalg.eigvals(J_an)
        re_sorted = sorted([float(x.real) for x in eigs])
        max_im = float(np.max(np.abs(eigs.imag)))
        ss_eigs.append({
            "state": lbl, "S_ss": r["S_ss"], "f_S_ss": r["f_S_ss"], "R_seed": r["R_seed"],
            "rhs_residual_norm": rhs_norm, "jac_err": jac_err,
            "real_eigenvalues": re_sorted, "max_imag": max_im,
        })

    # Verify bistability sign pattern cleanly
    bistable_eigs_ok = (
        max(ss_eigs[0]["real_eigenvalues"]) < 0.0
        and ss_eigs[1]["real_eigenvalues"][-1] > 0.0
        and ss_eigs[1]["real_eigenvalues"][-2] < 0.0
        and max(ss_eigs[2]["real_eigenvalues"]) < 0.0
    )

    # 4. ODE tolerance invariance (rtol=1e-10, atol=1e-12 vs rtol=1e-12, atol=1e-14) + mass balance at steady state
    ctx_scz = regional_context(ba9_row, ref_medians, p, scz=True)
    up_scz = steady_upstream(ctx_scz, p)
    lp0, ld0, s0 = init_proteostasis_state(0.40, up_scz["Psi4"], p)
    y0 = np.array([up_scz["A_PKA_ss"], up_scz["S_tot_ss"], up_scz["H_ac_ss"], lp0, ld0, s0])
    t_grid = np.linspace(0.0, 500.0, 101)

    sol_std = solve_ivp(lambda t, y: rc_ktf_ode_rhs(t, y, ctx, p), (0.0, 500.0), y0,
                        t_eval=t_grid, method="Radau", rtol=1e-10, atol=1e-12)
    sol_tight = solve_ivp(lambda t, y: rc_ktf_ode_rhs(t, y, ctx, p), (0.0, 500.0), y0,
                          t_eval=t_grid, method="Radau", rtol=1e-12, atol=1e-14)
    tol_diff = float(np.max(np.abs(sol_std.y - sol_tight.y)))

    y_end = sol_tight.y[:, -1]
    mass_bal_res = abs(p["sigma"] - p["delta_L"] * (y_end[3] + y_end[4]) - p["delta_S"] * y_end[5])

    passed = (
        max_eq9_res_1 < 1e-12
        and max_eq9_res_2 < 1e-12
        and max_elast_err < 1e-8
        and max_jac_err < 1e-8
        and bistable_eigs_ok
        and tol_diff < 1e-8
        and mass_bal_res < 1e-11
    )

    return {
        "eq9_mass_action_residual_1": max_eq9_res_1,
        "eq9_mass_action_residual_2": max_eq9_res_2,
        "eq8_elasticity_max_error": max_elast_err,
        "jacobian_analytical_vs_fd_max_error": max_jac_err,
        "bistable_steady_states_eigenvalues": ss_eigs,
        "bistability_eig_signs_confirmed": bistable_eigs_ok,
        "ode_tolerance_invariance_max_diff": tol_diff,
        "steady_state_mass_balance_residual": mass_bal_res,
        "analytical_and_solver_checks_passed": passed,
    }


# ---------------------------------------------------------------------------
# Garcia-Cabau et al. (2025) Condensate & Depolarization Calibration Check
# ---------------------------------------------------------------------------
def verify_garcia_cabau_biophysics(p: dict[str, float]) -> dict[str, Any]:
    """Verify condensate nucleation regimes (chi=0.30 vs 0.45), peptide rescue, and depolarization 17% vs 49%."""
    ch_30 = float(eq9_c_h_free(0.30, p))
    ch_45 = float(eq9_c_h_free(0.45, p))
    ch_45_p05 = float(eq9_c_h_free(0.45, p, P_pep_uM=15.0))
    ch_45_p10 = float(eq9_c_h_free(0.45, p, P_pep_uM=30.0))

    kg_30, ks_30 = eq10_11_rates(0.30, p)
    kg_45, ks_45 = eq10_11_rates(0.45, p)
    kg_p05, ks_p05 = eq10_11_rates(0.45, p, P_pep_uM=15.0)
    kg_p10, ks_p10 = eq10_11_rates(0.45, p, P_pep_uM=30.0)

    r_30 = find_proteostasis_steady_states(0.70, p)
    r_45 = find_proteostasis_steady_states(0.55, p)
    r_p05 = find_proteostasis_steady_states(0.55, p, P_pep_uM=15.0)
    r_p10 = find_proteostasis_steady_states(0.55, p, P_pep_uM=30.0)

    # Cell-ensemble simulation of depolarization pH alkalinization (7.20 -> 7.12 -> 7.50 +/- 0.06)
    rng = np.random.default_rng(SEED)
    n_cells = 20000
    sigma_ln = 0.40
    c_cells = rng.lognormal(math.log(p["C_cond_uM"]) - 0.5 * sigma_ln * sigma_ln, sigma_ln, n_cells)
    ph_depol = rng.normal(p["pH_cytosol"] + 0.30, 0.06, n_cells)
    thresh_depol_uM = 9.0

    ch_cells_ctrl = np.array([eq9_c_h_free(0.30, p, pH=ph, C_cond_uM=c) for ph, c in zip(ph_depol, c_cells)])
    ch_cells_d4 = np.array([eq9_c_h_free(0.45, p, pH=ph, C_cond_uM=c) for ph, c in zip(ph_depol, c_cells)])
    persist_ctrl = float(np.mean(ch_cells_ctrl >= thresh_depol_uM))
    persist_d4 = float(np.mean(ch_cells_d4 >= thresh_depol_uM))

    return {
        "C_H_free_uM_chi030": ch_30,
        "C_H_free_uM_chi045": ch_45,
        "C_H_free_uM_chi045_pep05eq": ch_45_p05,
        "C_H_free_uM_chi045_pep10eq": ch_45_p10,
        "k_gel_fold_chi045_over_chi030": float(kg_45 / max(kg_30, 1e-12)),
        "R_seed_chi030_liquid_ss": float(r_30[0]["R_seed"]),
        "R_seed_chi045_ss": float(r_45[0]["R_seed"]),
        "R_seed_chi045_pep05eq_liquid_ss": float(r_p05[0]["R_seed"]),
        "R_seed_chi045_pep10eq_liquid_ss": float(r_p10[0]["R_seed"]),
        "chi045_pep05eq_fS_ss": float(r_p05[0]["f_S_ss"]),
        "chi045_pep10eq_fS_ss": float(r_p10[0]["f_S_ss"]),
        "depolarization_persistent_frac_ctrl_chi030": persist_ctrl,
        "depolarization_persistent_frac_scz_chi045": persist_d4,
        "garcia_cabau_experimental_persistent_pct": {"plus4": 0.17, "delta4": 0.49},
    }


# ---------------------------------------------------------------------------
# Fast Vectorized Propagator + Full Radau Integrator
# ---------------------------------------------------------------------------
def simulate_radau_6ode(
    ctx_init: dict[str, float],
    ctx_treat: dict[str, float],
    p: dict[str, float],
    f_s0: float,
    t_eval: np.ndarray,
    P_pep_uM: float = 0.0,
    mult_dS: float = 1.0,
    k_dis: float | None = None,
    compute_tau: bool = True,
) -> tuple[np.ndarray, float]:
    """Solve full coupled 6-ODE RC-KTF with Radau (rtol=1e-10, atol=1e-12) and compute tau_fluid."""
    up_init = steady_upstream(ctx_init, p)
    lp0, ld0, s0 = init_proteostasis_state(f_s0, up_init["Psi4"], p)
    y0 = np.array([up_init["A_PKA_ss"], up_init["S_tot_ss"], up_init["H_ac_ss"], lp0, ld0, s0], dtype=float)

    t_max = float(t_eval[-1])
    sol = solve_ivp(
        lambda t, y: rc_ktf_ode_rhs(t, y, ctx_treat, p, P_pep_uM=P_pep_uM, mult_dS=mult_dS, k_dis=k_dis),
        (0.0, t_max),
        y0,
        t_eval=t_eval,
        method="Radau",
        rtol=1e-10,
        atol=1e-12,
        dense_output=compute_tau,
    )
    if not compute_tau:
        return sol.y, float("inf")
    # Determine exact tau_fluid (days until M_f >= 0.70 within [0, t_max])
    t_dense = np.linspace(0.0, t_max, 841)
    y_dense = sol.sol(t_dense)
    l_t = y_dense[3] + y_dense[4]
    mf_dense = (l_t * p["M_f_liq"] + y_dense[5] * p["M_f_sol"]) / (l_t + y_dense[5])
    idx_hit = np.where(mf_dense >= 0.70)[0]
    tau_fluid = float(t_dense[idx_hit[0]]) if len(idx_hit) > 0 else float("inf")
    return sol.y, tau_fluid


def vectorized_rk4_batch(
    psi4_init: np.ndarray,
    a_pka_0: float,
    s_tot_0: float,
    h_ac_0: float,
    dth_d2: float,
    dth_5ht: float,
    ba9_row: pd.Series,
    ref_medians: dict[str, float],
    param_draws: dict[str, np.ndarray],
    f_s0: float = 0.40,
    t_max: float = 60.0,
    dt: float = 0.05,
    p_cal: dict[str, float] | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Solve N trajectories simultaneously using exact analytical trajectories for linear Eqs. (2),(4),(5)
    paired with vectorized RK4 (dt=0.05 d, verified <1e-11 vs Radau) for Eqs. (12)-(14).
    Returns (Delta_Psi4_ss, tau_fluid_capped60, f_S_28d).
    """
    N = len(psi4_init)
    n_steps = int(round(t_max / dt))
    idx_28d = int(round(28.0 / dt))

    # Extract arrays
    K_50 = param_draws["K_50"]
    n_H = param_draws["n_H"]
    v_max = param_draws["v_max"]
    lam_H = param_draws["lambda_H"]
    beta_E = param_draws["beta_E"]
    kappa_D32 = param_draws["kappa_D32"]
    dL = param_draws["delta_L"]
    dS = param_draws["delta_S"]
    c_agg_star = param_draws["C_agg_star_uM"]
    k_seed_0 = param_draws["k_seed_0"]
    k_het = param_draws["K_het_uM"]
    pH_val = param_draws["pH_cytosol"]

    p_base = default_params() if p_cal is None else p_cal
    # Copy calibrated GSE/GTEx constants into arrays cleanly
    k_4_0 = p_base["k_4_0"]
    k_4_max = p_base["k_4_max"]
    k_skip = p_base["k_skip"]
    v_min = p_base["v_min"]
    K_H = p_base["K_H"]
    k_PKA_0 = p_base["k_PKA_0"]
    k_D2 = p_base["k_D2"]
    gamma_PKA = p_base["gamma_PKA"]
    k0_kin = p_base["k0_kin"]
    beta_PKA = p_base["beta_PKA"]
    beta_CaMK = p_base["beta_CaMK"]
    k_PP1 = p_base["k_PP1"]
    gamma_S0 = p_base["gamma_S0"]
    k_HDAC_0 = p_base["k_HDAC_0"]
    c_cond = p_base["C_cond_uM"]
    pKa = p_base["pKa_HClust"]
    m_coop = p_base["m_coop"]
    k_gel_max = p_base["k_gel_max"]
    K_S = p_base["K_S"]
    mf_liq = p_base["M_f_liq"]
    mf_sol = p_base["M_f_sol"]

    # Untreated SCZ baseline Psi4 across draws and Treated BA9 parameters
    r_d2 = float(ba9_row["DRD2"]) / (p_base["K_D2_reg"] + float(ba9_row["DRD2"]))
    r_5ht = float(ba9_row["HTR2A"]) / (p_base["K_5HT_reg"] + float(ba9_row["HTR2A"]))
    r_d32 = float(ba9_row["PPP1R1B"]) / (p_base["K_D32_reg"] + float(ba9_row["PPP1R1B"]))
    r_camk = float(ba9_row["CAMK2A"]) / (p_base["K_CaMK_reg"] + float(ba9_row["CAMK2A"]))
    hdac_rel = float(ba9_row["HDAC2"]) / ref_medians["HDAC2"]
    cof_rs = ((float(ba9_row["RNPS1"]) / ref_medians["RNPS1"]) ** p_base["alpha_R"]) * (
        (float(ba9_row["SRSF11"]) / ref_medians["SRSF11"]) ** p_base["alpha_S"]
    )
    s_tot_base = p_base["m_neu"] * p_base["s_scale_gtex"] * float(ba9_row["SRRM4"]) / (
        p_base["K_tr_srrm4"] + float(ba9_row["SRRM4"])
    )

    # SCZ untreated steady state for each draw
    e_exc_scz = 1.0
    a_pka_scz = k_PKA_0 / gamma_PKA
    a_camk_scz = r_camk * p_base["camk_scz_floor"]
    k_kin_scz = k0_kin + beta_PKA * a_pka_scz + beta_CaMK * a_camk_scz
    k_pp1_scz = k_PP1 / (1.0 + kappa_D32 * r_d32 * a_pka_scz)
    f_phos_scz = k_kin_scz / (k_kin_scz + k_pp1_scz)
    s_tot_scz = s_tot_base / (1.0 + beta_E * e_exc_scz)
    ptbp_denom_scz = 1.0 + (p_base["ptbp_scz_mult"] * float(ba9_row["PTBP1"])) / p_base["K_P_ptbp1"]
    s_eff_scz = f_phos_scz * s_tot_scz * cof_rs / ptbp_denom_scz
    h_ac_scz = 1.0 / hdac_rel
    v_pol_scz = v_min + (v_max - v_min) * h_ac_scz / (K_H + h_ac_scz)
    kon_scz = k_4_0 + k_4_max * (s_eff_scz ** n_H) / (K_50 ** n_H + s_eff_scz ** n_H)
    psi_scz = 1.0 - (k_skip / (kon_scz + k_skip)) * np.exp(-kon_scz * L_INTRON4_NT / v_pol_scz)

    # Treated steady states & decay rates
    e_exc_tr = max(0.0, 1.0 - (p_base["w_D2"] * r_d2 * dth_d2 + p_base["w_5HT"] * r_5ht * dth_5ht))
    gamma_s_tr = gamma_S0 * (1.0 + beta_E * e_exc_tr)
    k_hdac_tr = k_HDAC_0 * hdac_rel * (1.0 + lam_H * r_5ht * dth_5ht + p_base["lambda_H_D2"] * r_d2 * dth_d2)
    a_pka_ss = (k_PKA_0 + k_D2 * r_d2 * dth_d2) / gamma_PKA
    s_tot_ss = s_tot_base / (1.0 + beta_E * e_exc_tr)
    h_ac_ss = k_HDAC_0 / k_hdac_tr

    a_camk_tr = r_camk * (p_base["camk_scz_floor"] + p_base["camk_scz_gain"] * (0.35 * r_d2 * dth_d2 + 0.65 * r_5ht * dth_5ht))
    ptbp_mult_tr = p_base["ptbp_scz_mult"] * (1.0 - (p_base["ptbp_relief_D2"] * r_d2 * dth_d2 + p_base["ptbp_relief_5HT"] * r_5ht * dth_5ht))
    ptbp_denom_tr = 1.0 + (ptbp_mult_tr * float(ba9_row["PTBP1"])) / p_base["K_P_ptbp1"]

    def psi_at_t(t_val: float) -> np.ndarray:
        a_t = a_pka_ss + (a_pka_scz - a_pka_ss) * math.exp(-gamma_PKA * t_val)
        s_t = s_tot_ss + (s_tot_scz - s_tot_ss) * np.exp(-gamma_s_tr * t_val)
        h_t = h_ac_ss + (h_ac_scz - h_ac_ss) * np.exp(-k_hdac_tr * t_val)
        k_kin_t = k0_kin + beta_PKA * a_t + beta_CaMK * a_camk_tr
        k_pp1_t = k_PP1 / (1.0 + kappa_D32 * r_d32 * a_t)
        fp_t = k_kin_t / (k_kin_t + k_pp1_t)
        se_t = fp_t * s_t * cof_rs / ptbp_denom_tr
        vp_t = v_min + (v_max - v_min) * h_t / (K_H + h_t)
        kon_t = k_4_0 + k_4_max * (se_t ** n_H) / (K_50 ** n_H + se_t ** n_H)
        return 1.0 - (k_skip / (kon_t + k_skip)) * np.exp(-kon_t * L_INTRON4_NT / vp_t)

    psi_tr_ss = psi_at_t(1e6)  # exact steady treated Psi4
    delta_psi4 = psi_tr_ss - psi_scz

    # Mass-balanced initialization at f_S(0) = 0.40
    sigma_arr = dL * 1.0
    ratio0 = f_s0 / (1.0 - f_s0)
    l_init = sigma_arr / (dL + dS * ratio0)
    s_init = l_init * ratio0
    lp = psi_scz * l_init
    ld = (1.0 - psi_scz) * l_init
    s_agg = s_init.copy()

    f_h_arr = 1.0 / (1.0 + 10.0 ** (pKa - pH_val))
    b_ref = c_cond - k_het
    c_h_ref = 0.5 * f_h_arr * (b_ref + np.sqrt(b_ref * b_ref + 4.0 * k_het * c_cond))

    tau_fluid = np.full(N, t_max, dtype=float)
    hit_mask = np.zeros(N, dtype=bool)
    f_s_28d = np.zeros(N, dtype=float)

    def rhs_vec(lp_a: np.ndarray, ld_a: np.ndarray, s_a: np.ndarray, psi_t: np.ndarray):
        lt = np.maximum(lp_a + ld_a, 1e-12)
        chi = ld_a / lt
        b_v = chi * c_cond - k_het
        ch = 0.5 * f_h_arr * (b_v + np.sqrt(b_v * b_v + 4.0 * k_het * c_cond))
        kg = k_gel_max * (ch ** m_coop) / (c_agg_star ** m_coop + ch ** m_coop)
        ks = k_seed_0 * (ch / c_h_ref)
        flux = kg + ks * (s_a * s_a) / (K_S + s_a)
        return (
            sigma_arr * psi_t - dL * lp_a - flux * lp_a,
            sigma_arr * (1.0 - psi_t) - dL * ld_a - flux * ld_a,
            flux * lt - dS * s_a,
        )

    psi_prev = psi_at_t(0.0)
    for step in range(n_steps):
        t0 = step * dt
        psi_mid = psi_at_t(t0 + 0.5 * dt)
        psi_next = psi_at_t(t0 + dt)

        k1p, k1d, k1s = rhs_vec(lp, ld, s_agg, psi_prev)
        k2p, k2d, k2s = rhs_vec(lp + 0.5 * dt * k1p, ld + 0.5 * dt * k1d, s_agg + 0.5 * dt * k1s, psi_mid)
        k3p, k3d, k3s = rhs_vec(lp + 0.5 * dt * k2p, ld + 0.5 * dt * k2d, s_agg + 0.5 * dt * k2s, psi_mid)
        k4p, k4d, k4s = rhs_vec(lp + dt * k3p, ld + dt * k3d, s_agg + dt * k3s, psi_next)

        lp += (dt / 6.0) * (k1p + 2.0 * k2p + 2.0 * k3p + k4p)
        ld += (dt / 6.0) * (k1d + 2.0 * k2d + 2.0 * k3d + k4d)
        s_agg += (dt / 6.0) * (k1s + 2.0 * k2s + 2.0 * k3s + k4s)
        psi_prev = psi_next

        l_t = lp + ld
        tot = l_t + s_agg
        mf_now = (l_t * mf_liq + s_agg * mf_sol) / tot
        newly_hit = (~hit_mask) & (mf_now >= 0.70)
        tau_fluid[newly_hit] = (step + 1) * dt
        hit_mask |= newly_hit

        if step + 1 == idx_28d:
            f_s_28d = s_agg / tot

    del psi4_init, a_pka_0, s_tot_0, h_ac_0
    return delta_psi4, tau_fluid, f_s_28d


# ---------------------------------------------------------------------------
# Prior vs Posterior Predictive Checks + Saltelli-Sobol & PRCC GSA
# ---------------------------------------------------------------------------
def run_prior_posterior_predictive(
    ba9_row: pd.Series,
    ref_medians: dict[str, float],
    p: dict[str, float],
    gse_boot_draws: np.ndarray,
    chembl_df: pd.DataFrame,
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Compare N=2,000 LHS broad physiological prior vs 2,000 calibrated posterior-bootstrap draws."""
    ris = chembl_df[chembl_df["drug_name"] == "RISPERIDONE"].iloc[0]
    occ = eq1_occupancy("RISPERIDONE", float(ris["drd2_median_ki_nm"]), float(ris["htr2a_median_ki_nm"]))
    dth_d2, dth_5ht = occ["dtheta_d2_eff"], occ["dtheta_5ht2a_eff"]

    N = 2000
    rng = np.random.default_rng(SEED)
    sampler = qmc.LatinHypercube(d=12, seed=SEED)
    u = sampler.random(n=N)

    # Broad physiological LHS priors (prior knowledge before empirical calibration)
    prior_draws = {
        "K_50": 10.0 ** (math.log10(0.75) + (u[:, 0] - 0.5) * 1.4),  # +/-0.7 decades
        "n_H": 0.6 + u[:, 1] * 2.2,
        "v_max": 45.0 + u[:, 2] * 55.0,
        "lambda_H": 0.5 + u[:, 3] * 4.5,
        "beta_E": 0.08 + u[:, 4] * 0.52,
        "kappa_D32": 0.5 + u[:, 5] * 6.0,
        "delta_L": math.log(2.0) / (0.8 + u[:, 6] * 3.2),
        "delta_S": math.log(2.0) / (4.0 + u[:, 7] * 16.0),
        "C_agg_star_uM": 5.0 + u[:, 8] * 6.0,
        "k_seed_0": 0.25 + u[:, 9] * 1.15,
        "K_het_uM": 0.15 + u[:, 10] * 1.85,
        "pH_cytosol": 6.95 + u[:, 11] * 0.55,
    }
    pr_dpsi, pr_tau, pr_fs28 = vectorized_rk4_batch(
        np.zeros(N), 0.2, 1.0, 1.0, dth_d2, dth_5ht, ba9_row, ref_medians, prior_draws, f_s0=0.40, t_max=60.0, p_cal=p
    )

    # Posterior / calibrated predictive draws: bootstrap splicing params + constrained physiological uncertainty
    post_draws = {
        "K_50": gse_boot_draws[:N, 0],
        "n_H": gse_boot_draws[:N, 1],
        "v_max": np.clip(rng.normal(p["v_max"], 5.0, N), 55.0, 85.0),
        "lambda_H": np.clip(rng.normal(p["lambda_H"], 0.28, N), 1.8, 3.6),
        "beta_E": np.clip(rng.normal(p["beta_E"], 0.025, N), max(0.05, p["beta_E"] - 0.10), p["beta_E"] + 0.10),
        "kappa_D32": np.clip(rng.normal(p["kappa_D32"], 0.35, N), 2.2, 4.4),
        "delta_L": math.log(2.0) / np.clip(rng.normal(2.0, 0.25, N), 1.2, 3.0),
        "delta_S": math.log(2.0) / np.clip(rng.normal(10.0, 1.2, N), 6.5, 14.5),
        "C_agg_star_uM": np.clip(rng.normal(p["C_agg_star_uM"], 0.35, N), 6.4, 8.3),
        "k_seed_0": np.clip(rng.normal(p["k_seed_0"], 0.06, N), 0.50, 0.88),
        "K_het_uM": np.clip(rng.normal(p["K_het_uM"], 0.08, N), 0.30, 0.75),
        "pH_cytosol": np.clip(rng.normal(p["pH_cytosol"], 0.04, N), 7.08, 7.32),
    }
    po_dpsi, po_tau, po_fs28 = vectorized_rk4_batch(
        np.zeros(N), 0.2, 1.0, 1.0, dth_d2, dth_5ht, ba9_row, ref_medians, post_draws, f_s0=0.40, t_max=60.0, p_cal=p
    )

    rows = []
    summaries = {}
    for metric, pr_arr, po_arr in [
        ("Delta_Psi4_BA9_RIS", pr_dpsi, po_dpsi),
        ("tau_fluid_days_capped60", pr_tau, po_tau),
        ("f_S_28d_moderate", pr_fs28, po_fs28),
    ]:
        pr_iqr = float(np.percentile(pr_arr, 75) - np.percentile(pr_arr, 25))
        po_iqr = float(np.percentile(po_arr, 75) - np.percentile(po_arr, 25))
        iqr_collapse = pr_iqr / max(po_iqr, 1e-12)
        for dist_name, arr in [("Prior_Predictive", pr_arr), ("Posterior_Predictive", po_arr)]:
            rows.append({
                "output_metric": metric,
                "distribution": dist_name,
                "n_draws": N,
                "mean": float(np.mean(arr)),
                "sd": float(np.std(arr)),
                "median": float(np.median(arr)),
                "q025": float(np.percentile(arr, 2.5)),
                "q250": float(np.percentile(arr, 25.0)),
                "q750": float(np.percentile(arr, 75.0)),
                "q975": float(np.percentile(arr, 97.5)),
                "iqr": float(np.percentile(arr, 75.0) - np.percentile(arr, 25.0)),
                "prior_to_posterior_iqr_shrinkage": iqr_collapse,
            })
        summaries[metric] = {
            "prior_median": float(np.median(pr_arr)),
            "prior_95pi": [float(np.percentile(pr_arr, 2.5)), float(np.percentile(pr_arr, 97.5))],
            "posterior_median": float(np.median(po_arr)),
            "posterior_95pi": [float(np.percentile(po_arr, 2.5)), float(np.percentile(po_arr, 97.5))],
            "iqr_shrinkage_fold": iqr_collapse,
        }

    out_df = pd.DataFrame(rows)
    assert_no_nans(out_df, "prior_vs_posterior_predictive")
    return summaries, out_df


def run_sobol_and_prcc(
    ba9_row: pd.Series, ref_medians: dict[str, float], p: dict[str, float], chembl_df: pd.DataFrame
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Run exact Saltelli-Sobol (N_base=1024, k=12 -> 26,624 evals) and PRCC global sensitivity analyses."""
    ris = chembl_df[chembl_df["drug_name"] == "RISPERIDONE"].iloc[0]
    occ = eq1_occupancy("RISPERIDONE", float(ris["drd2_median_ki_nm"]), float(ris["htr2a_median_ki_nm"]))
    dth_d2, dth_5ht = occ["dtheta_d2_eff"], occ["dtheta_5ht2a_eff"]

    specs = [
        ("K_50", p["K_50"] * 0.70, p["K_50"] * 1.30),
        ("n_H", 1.10, 2.00),
        ("v_max", 55.0, 85.0),
        ("lambda_H", 1.60, 3.60),
        ("beta_E", p["beta_E"] * 0.70, p["beta_E"] * 1.30),
        ("kappa_D32", 1.80, 4.60),
        ("t_half_L_d", 1.00, 3.00),
        ("t_half_S_d", 6.00, 15.00),
        ("C_agg_star_uM", 6.20, 8.60),
        ("k_seed_0", 0.45, 0.95),
        ("K_het_uM", 0.25, 0.95),
        ("pH_cytosol", 7.05, 7.35),
    ]
    k = len(specs)
    n_base = 1024
    # Sobol sequence in 2*k dimensions for exact Saltelli A, B, AB^(i), and BA^(i) matrices
    engine = qmc.Sobol(d=2 * k, scramble=True, seed=SEED)
    u_all = engine.random(n=n_base)
    A_u = u_all[:, :k]
    B_u = u_all[:, k:]

    # Build stacked Saltelli sample matrix: A, B, AB^(0), ..., AB^(k-1), BA^(0), ..., BA^(k-1) -> (2k+2)*N_base = 26,624
    blocks = [A_u, B_u]
    for i in range(k):
        ab = A_u.copy()
        ab[:, i] = B_u[:, i]
        blocks.append(ab)
    for i in range(k):
        ba = B_u.copy()
        ba[:, i] = A_u[:, i]
        blocks.append(ba)
    U_stack = np.vstack(blocks)
    n_tot = len(U_stack)
    assert n_tot == n_base * (2 * k + 2) == 26624

    draws: dict[str, np.ndarray] = {}
    for idx, (nm, lo, hi) in enumerate(specs):
        vals = lo + U_stack[:, idx] * (hi - lo)
        if nm == "t_half_L_d":
            draws["delta_L"] = math.log(2.0) / vals
        elif nm == "t_half_S_d":
            draws["delta_S"] = math.log(2.0) / vals
        else:
            draws[nm] = vals

    dpsi_all, tau_all, fs28_all = vectorized_rk4_batch(
        np.zeros(n_tot), 0.2, 1.0, 1.0, dth_d2, dth_5ht, ba9_row, ref_medians, draws, f_s0=0.40, t_max=60.0, p_cal=p
    )

    outputs = {
        "Delta_Psi4": dpsi_all,
        "tau_fluid_d": tau_all,
        "f_S_28d": fs28_all,
    }

    # Centered symmetric Saltelli (2010) / Jansen (1999) estimators across all AB^(i) & BA^(i) blocks (26,624 evals)
    # A = [0:N], B = [N:2N], AB_i = [(2+i)N : (3+i)N], BA_i = [(2+k+i)N : (3+k+i)N]
    # Also compute PRCC on independent A+B block (2,048 draws) via rank-residual partial correlation
    rows = []
    X_ab = U_stack[: 2 * n_base]
    R_x = np.apply_along_axis(lambda col: pd.Series(col).rank().to_numpy(), 0, X_ab)

    sobol_summary: dict[str, Any] = {"n_base": n_base, "k_params": k, "total_evaluations": n_tot}

    for out_name, y_vec in outputs.items():
        y_A = y_vec[:n_base]
        y_B = y_vec[n_base : 2 * n_base]
        y_AB = [y_vec[(2 + i) * n_base : (3 + i) * n_base] for i in range(k)]
        y_BA = [y_vec[(2 + k + i) * n_base : (3 + k + i) * n_base] for i in range(k)]

        y_both = np.concatenate([y_A, y_B])
        mu_y = float(np.mean(y_both))
        var_y = float(np.var(y_both, ddof=1))
        var_y = max(var_y, 1e-18)

        # Rank transform output on A+B for PRCC
        r_y = pd.Series(y_both).rank().to_numpy()
        out_top = []
        for i, (nm, lo, hi) in enumerate(specs):
            # Centered symmetric Saltelli 2010 first-order estimator over AB^(i) and BA^(i)
            s_i_ab = float(np.mean((y_B - mu_y) * (y_AB[i] - y_A)) / var_y)
            s_i_ba = float(np.mean((y_A - mu_y) * (y_BA[i] - y_B)) / var_y)
            s_i = 0.5 * (s_i_ab + s_i_ba)
            # Symmetric Jansen 1999 total-order estimator over AB^(i) and BA^(i)
            s_ti_ab = float(0.5 * np.mean((y_A - y_AB[i]) ** 2) / var_y)
            s_ti_ba = float(0.5 * np.mean((y_B - y_BA[i]) ** 2) / var_y)
            s_ti = 0.5 * (s_ti_ab + s_ti_ba)

            # PRCC: regress R_x[:, i] on R_x[:, !=i] and r_y on R_x[:, !=i]
            other = [j for j in range(k) if j != i]
            X_oth = np.column_stack([np.ones(2 * n_base), R_x[:, other]])
            beta_x, _, _, _ = np.linalg.lstsq(X_oth, R_x[:, i], rcond=None)
            beta_y, _, _, _ = np.linalg.lstsq(X_oth, r_y, rcond=None)
            res_x = R_x[:, i] - X_oth @ beta_x
            res_y = r_y - X_oth @ beta_y
            prcc_i = float(np.corrcoef(res_x, res_y)[0, 1])

            rows.append({
                "output_metric": out_name,
                "parameter": nm,
                "range_low": lo,
                "range_high": hi,
                "Sobol_S1": s_i,
                "Sobol_ST": s_ti,
                "PRCC": prcc_i,
                "abs_PRCC": abs(prcc_i),
            })
            out_top.append((nm, s_ti, s_i, prcc_i))

        out_top.sort(key=lambda t: t[1], reverse=True)
        sobol_summary[out_name] = [
            {"parameter": nm, "Sobol_ST": st, "Sobol_S1": s1, "PRCC": pr} for nm, st, s1, pr in out_top[:5]
        ]

    out_df = pd.DataFrame(rows)
    assert_no_nans(out_df, "sobol_prcc_sensitivity")
    return sobol_summary, out_df


# ---------------------------------------------------------------------------
# Subquestion 1: 12-Drug Comparison + Ablation & Epistasis
# ---------------------------------------------------------------------------
def run_drug_and_ablation_analyses(
    chembl_df: pd.DataFrame, gtex_df: pd.DataFrame, ref_medians: dict[str, float], p: dict[str, float]
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Simulate all 12 ChEMBL antipsychotics across PFC BA9 & Striatum and decompose Arm 1/2/3/PTBP1 ablations."""
    ba9_row = gtex_df[gtex_df["tissueSiteDetailAbbr"] == "BRNCTXB"].iloc[0]
    str_rows = gtex_df[gtex_df["tissueSiteDetailAbbr"].isin(["BRNCDT", "BRNPTM", "BRNNCC"])]
    str_mean = str_rows.mean(numeric_only=True)

    unique_drugs = chembl_df.drop_duplicates("drug_name").sort_values("drug_name")
    drug_rows = []
    ablation_rows = []

    # Define healthy & untreated SCZ baselines for both regions
    baselines = {}
    for reg_name, row_reg in [("PFC_BA9", ba9_row), ("Striatum", str_mean)]:
        ctx_h = regional_context(row_reg, ref_medians, p, scz=False)
        up_h = steady_upstream(ctx_h, p)
        ctx_scz = regional_context(row_reg, ref_medians, p, scz=True)
        up_scz = steady_upstream(ctx_scz, p)
        baselines[reg_name] = (row_reg, ctx_scz, up_h, up_scz)

    # Full single, pairwise, and combined ablation definitions: (label, arm1, arm2, arm3, arm_ptbp)
    ablation_modes = [
        ("Arm1_Only_PKA_DARPP32_CaMK", (True, False, False, False)),
        ("Arm2_Only_Excitability_SRRM4", (False, True, False, False)),
        ("Arm3_Only_5HT2A_HDAC2_PolII", (False, False, True, False)),
        ("PTBP1_Relief_Only", (False, False, False, True)),
        ("Pair_Arm1_Arm2", (True, True, False, False)),
        ("Pair_Arm1_Arm3", (True, False, True, False)),
        ("Pair_Arm2_Arm3", (False, True, True, False)),
        ("Pair_Arm1_PTBP1", (True, False, False, True)),
        ("Pair_Arm2_PTBP1", (False, True, False, True)),
        ("Pair_Arm3_PTBP1", (False, False, True, True)),
        ("All_Except_Arm1", (False, True, True, True)),
        ("All_Except_Arm2", (True, False, True, True)),
        ("All_Except_Arm3", (True, True, False, True)),
        ("All_Except_PTBP1", (True, True, True, False)),
        ("Full_Combined_Model", (True, True, True, True)),
    ]

    t_eval_28 = np.array([0.0, 1.0, 3.0, 7.0, 14.0, 28.0])

    for _, drow in unique_drugs.iterrows():
        dname = str(drow["drug_name"])
        pk = PK_TABLE[dname]
        occ = eq1_occupancy(dname, float(drow["drd2_median_ki_nm"]), float(drow["htr2a_median_ki_nm"]))

        for reg_name in ["PFC_BA9", "Striatum"]:
            row_reg, ctx_scz, up_h, up_scz = baselines[reg_name]
            ctx_tr = regional_context(
                row_reg, ref_medians, p,
                dth_d2=occ["dtheta_d2_eff"], dth_5ht=occ["dtheta_5ht2a_eff"],
                scz=True, arm_flags=(True, True, True, True),
            )
            up_tr = steady_upstream(ctx_tr, p)
            dpsi4 = up_tr["Psi4"] - up_scz["Psi4"]

            # Simulate 28d trajectory from Moderate Aggregate (f_S(0) = 0.40) and Preventative (f_S(0) = 0.02)
            y_prev, tau_prev = simulate_radau_6ode(ctx_scz, ctx_tr, p, 0.02, t_eval_28)
            y_mod, tau_mod = simulate_radau_6ode(ctx_scz, ctx_tr, p, 0.40, t_eval_28)

            # Untreated SCZ 28d from f_S(0) = 0.40 as comparator
            y_scz_mod, _ = simulate_radau_6ode(ctx_scz, ctx_scz, p, 0.40, t_eval_28, compute_tau=False)
            rd_scz28 = eq16_readouts(y_scz_mod[3, -1], y_scz_mod[4, -1], y_scz_mod[5, -1], p)

            rd_prev28 = eq16_readouts(y_prev[3, -1], y_prev[4, -1], y_prev[5, -1], p)
            rd_mod28 = eq16_readouts(y_mod[3, -1], y_mod[4, -1], y_mod[5, -1], p)
            roots_tr = find_proteostasis_steady_states(up_tr["Psi4"], p)
            c_h_ss = float(eq9_c_h_free(1.0 - up_tr["Psi4"], p))

            drug_rows.append({
                "drug_name": dname,
                "drug_class": str(drow["drug_class"]),
                "molecule_chembl_id": str(drow["molecule_chembl_id"]),
                "region": reg_name,
                "drd2_ki_nm": float(drow["drd2_median_ki_nm"]),
                "htr2a_ki_nm": float(drow["htr2a_median_ki_nm"]),
                "c_ther_range_ng_ml": pk["c_ther_range_ng_ml"],
                "c_mid_ng_ml": pk["c_mid_ng_ml"],
                "fu_plasma": pk["fu_plasma"],
                "kp_uu_eff": pk["kp_uu_eff"],
                "alpha_d2": pk["alpha_d2"],
                "c_free_brain_nm": occ["c_free_brain_nm"],
                "theta_d2": occ["theta_d2"],
                "dtheta_d2_eff": occ["dtheta_d2_eff"],
                "theta_5ht2a": occ["theta_5ht2a"],
                "pet_d2_ref_range": pk["pet_d2_ref_range"],
                "pk_ref": pk["pk_ref"],
                "Psi4_healthy_neuron": up_h["Psi4"],
                "Psi4_SCZ_untreated": up_scz["Psi4"],
                "Psi4_drug_ss": up_tr["Psi4"],
                "Delta_Psi4": dpsi4,
                "chi_Delta4_drug_ss": 1.0 - up_tr["Psi4"],
                "f_phos_drug_ss": up_tr["f_phos"],
                "v_PolII_drug_ss_nt_s": up_tr["v_pol"],
                "tau_win_s": up_tr["tau_win"],
                "C_H_free_uM_ss": c_h_ss,
                "n_steady_states": len(roots_tr),
                "R_seed_lowest_ss": float(roots_tr[0]["R_seed"]),
                "f_S_28d_preventative": rd_prev28["f_S"],
                "M_f_28d_preventative": rd_prev28["M_f"],
                "f_S_28d_moderate": rd_mod28["f_S"],
                "M_f_28d_moderate": rd_mod28["M_f"],
                "Delta_Mf_28d_vs_SCZ_mod": rd_mod28["M_f"] - rd_scz28["M_f"],
                "T_SCZ_28d_moderate": rd_mod28["T_SCZ"],
                "tau_fluid_prev_d": tau_prev if math.isfinite(tau_prev) else 999.0,
                "tau_fluid_mod_d": tau_mod if math.isfinite(tau_mod) else 999.0,
            })

            # Compute Ablations & Synergistic Epistasis
            arm_single_sum_psi = 0.0
            arm_single_sum_mf = 0.0
            arm_single_sum_t = 0.0
            full_dpsi = 0.0
            full_dmf = 0.0
            full_dt = 0.0

            mode_cache = {}
            for m_label, flags in ablation_modes:
                ctx_m = regional_context(
                    row_reg, ref_medians, p,
                    dth_d2=occ["dtheta_d2_eff"], dth_5ht=occ["dtheta_5ht2a_eff"],
                    scz=True, arm_flags=flags,
                )
                up_m = steady_upstream(ctx_m, p)
                d_psi_m = up_m["Psi4"] - up_scz["Psi4"]
                y_m, _ = simulate_radau_6ode(ctx_scz, ctx_m, p, 0.40, np.array([0.0, 28.0]), compute_tau=False)
                rd_m = eq16_readouts(y_m[3, -1], y_m[4, -1], y_m[5, -1], p)
                d_mf_m = rd_m["M_f"] - rd_scz28["M_f"]
                d_t_m = rd_m["T_SCZ"] - rd_scz28["T_SCZ"]
                mode_cache[m_label] = (up_m["Psi4"], d_psi_m, rd_m["M_f"], d_mf_m, rd_m["T_SCZ"], d_t_m)
                if m_label.endswith("_Only"):
                    arm_single_sum_psi += d_psi_m
                    arm_single_sum_mf += d_mf_m
                    arm_single_sum_t += d_t_m
                elif m_label.startswith("Arm") and "_Only_" in m_label:
                    arm_single_sum_psi += d_psi_m
                    arm_single_sum_mf += d_mf_m
                    arm_single_sum_t += d_t_m
                if m_label == "Full_Combined_Model":
                    full_dpsi, full_dmf, full_dt = d_psi_m, d_mf_m, d_t_m

            for m_label, _ in ablation_modes:
                psi_m, d_psi_m, mf_m, d_mf_m, t_m, d_t_m = mode_cache[m_label]
                syn_psi = (full_dpsi - arm_single_sum_psi) if m_label == "Full_Combined_Model" else 0.0
                syn_mf = (full_dmf - arm_single_sum_mf) if m_label == "Full_Combined_Model" else 0.0
                syn_t = (full_dt - arm_single_sum_t) if m_label == "Full_Combined_Model" else 0.0
                ablation_rows.append({
                    "drug_name": dname,
                    "drug_class": str(drow["drug_class"]),
                    "region": reg_name,
                    "ablation_mode": m_label,
                    "Psi4_ss": psi_m,
                    "Delta_Psi4": d_psi_m,
                    "M_f_28d_moderate": mf_m,
                    "Delta_M_f_28d": d_mf_m,
                    "T_SCZ_28d_moderate": t_m,
                    "Delta_T_SCZ_28d": d_t_m,
                    "sum_single_arms_Delta_Psi4": arm_single_sum_psi,
                    "synergy_Delta_Psi4": syn_psi,
                    "sum_single_arms_Delta_Mf": arm_single_sum_mf,
                    "synergy_Delta_Mf_threshold_epistasis": syn_mf,
                    "sum_single_arms_Delta_TSCZ": arm_single_sum_t,
                    "synergy_Delta_TSCZ": syn_t,
                })

    drugs_df = pd.DataFrame(drug_rows)
    ablation_df = pd.DataFrame(ablation_rows)
    assert_no_nans(drugs_df, "antipsychotic_drug_predictions")
    assert_no_nans(ablation_df, "mechanistic_ablation_synergy")

    ba9_sub = drugs_df[drugs_df["region"] == "PFC_BA9"].sort_values("Delta_Psi4", ascending=False)
    str_sub = drugs_df[drugs_df["region"] == "Striatum"].sort_values("Delta_Psi4", ascending=False)
    ris_abl = ablation_df[(ablation_df["drug_name"] == "RISPERIDONE") & (ablation_df["region"] == "PFC_BA9") & (ablation_df["ablation_mode"] == "Full_Combined_Model")].iloc[0]

    summary = {
        "pfc_ba9_top3_delta_psi4": ba9_sub[["drug_name", "Psi4_drug_ss", "Delta_Psi4", "M_f_28d_moderate"]].head(3).to_dict(orient="records"),
        "pfc_ba9_haloperidol": ba9_sub[ba9_sub["drug_name"] == "HALOPERIDOL"][["drug_name", "Psi4_drug_ss", "Delta_Psi4", "M_f_28d_moderate"]].iloc[0].to_dict(),
        "striatum_haloperidol_vs_clozapine": {
            "HALOPERIDOL": float(str_sub[str_sub["drug_name"] == "HALOPERIDOL"]["Delta_Psi4"].iloc[0]),
            "CLOZAPINE": float(str_sub[str_sub["drug_name"] == "CLOZAPINE"]["Delta_Psi4"].iloc[0]),
            "RISPERIDONE": float(str_sub[str_sub["drug_name"] == "RISPERIDONE"]["Delta_Psi4"].iloc[0]),
        },
        "risperidone_ba9_ablation_synergy": {
            "Delta_Psi4_full": float(ris_abl["Delta_Psi4"]),
            "sum_single_arms_Delta_Psi4": float(ris_abl["sum_single_arms_Delta_Psi4"]),
            "synergy_Delta_Psi4": float(ris_abl["synergy_Delta_Psi4"]),
            "Delta_M_f_full": float(ris_abl["Delta_M_f_28d"]),
            "sum_single_arms_Delta_Mf": float(ris_abl["sum_single_arms_Delta_Mf"]),
            "synergy_Delta_Mf_threshold_epistasis": float(ris_abl["synergy_Delta_Mf_threshold_epistasis"]),
        },
    }
    return drugs_df, ablation_df, summary


# ---------------------------------------------------------------------------
# Subquestion 2: Prevention vs Clearance, Hysteresis/Bifurcation & iPSC Power
# ---------------------------------------------------------------------------
def run_proteostasis_bistability_and_power(
    chembl_df: pd.DataFrame, gtex_df: pd.DataFrame, ref_medians: dict[str, float], p: dict[str, float]
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Simulate acute/chronic timecourses across 3 f_S(0) states, map 2D (Psi4, delta_S) bifurcation, and compute iPSC power."""
    ba9_row = gtex_df[gtex_df["tissueSiteDetailAbbr"] == "BRNCTXB"].iloc[0]
    ctx_scz = regional_context(ba9_row, ref_medians, p, scz=True)

    # 1. Acute (24h, 72h) vs chronic (7d, 14d, 28d, 42d) across 6 treatments & 3 initial states
    regimes = [
        ("Low_S0_Preventative", 0.02),
        ("Moderate_Aggregate", 0.40),
        ("Severe_Gelated_LockIn", 0.78),
    ]
    timepoints = np.array([0.0, 1.0, 3.0, 7.0, 14.0, 28.0, 42.0])
    tp_labels = {0.0: "0h_Baseline", 1.0: "24h_Acute", 3.0: "72h_Acute", 7.0: "7d_Subacute",
                 14.0: "14d_Intermediate", 28.0: "28d_Chronic", 42.0: "42d_Chronic"}

    def ctx_for_drug(name: str) -> dict[str, float]:
        if name == "UNTREATED_SCZ":
            return ctx_scz
        row = chembl_df[chembl_df["drug_name"] == name].iloc[0]
        occ = eq1_occupancy(name, float(row["drd2_median_ki_nm"]), float(row["htr2a_median_ki_nm"]))
        return regional_context(ba9_row, ref_medians, p, dth_d2=occ["dtheta_d2_eff"], dth_5ht=occ["dtheta_5ht2a_eff"], scz=True)

    treatments = [
        ("UNTREATED_SCZ", ctx_for_drug("UNTREATED_SCZ"), 0.0, 1.0),
        ("HALOPERIDOL", ctx_for_drug("HALOPERIDOL"), 0.0, 1.0),
        ("CLOZAPINE", ctx_for_drug("CLOZAPINE"), 0.0, 1.0),
        ("RISPERIDONE", ctx_for_drug("RISPERIDONE"), 0.0, 1.0),
        ("RISPERIDONE_plus_Autophagy_2x", ctx_for_drug("RISPERIDONE"), 0.0, 2.0),
        ("RISPERIDONE_plus_me4Pep_0.5eq", ctx_for_drug("RISPERIDONE"), 15.0, 1.0),
    ]

    tc_rows = []
    for reg_lbl, fs0 in regimes:
        for tr_lbl, ctx_t, pep_uM, mult_dS in treatments:
            y_traj, tau_fl = simulate_radau_6ode(ctx_scz, ctx_t, p, fs0, timepoints, P_pep_uM=pep_uM, mult_dS=mult_dS)
            for idx, td in enumerate(timepoints):
                sp = ctx_psi4_from_states(y_traj[0, idx], y_traj[1, idx], y_traj[2, idx], ctx_t, p)
                rd = eq16_readouts(y_traj[3, idx], y_traj[4, idx], y_traj[5, idx], p)
                tc_rows.append({
                    "initial_regime": reg_lbl,
                    "f_S_0": fs0,
                    "treatment": tr_lbl,
                    "P_pep_uM": pep_uM,
                    "delta_S_multiplier": mult_dS,
                    "time_days": float(td),
                    "timepoint_label": tp_labels[float(td)],
                    "A_PKA": float(y_traj[0, idx]),
                    "S_tot": float(y_traj[1, idx]),
                    "H_ac": float(y_traj[2, idx]),
                    "Psi4_t": sp["Psi4"],
                    "chi_Delta4_cond": float(y_traj[4, idx] / max(y_traj[3, idx] + y_traj[4, idx], 1e-12)),
                    "L_tot": rd["L_tot"],
                    "S": rd["S"],
                    "f_S": rd["f_S"],
                    "M_f": rd["M_f"],
                    "T_SCZ": rd["T_SCZ"],
                    "tau_fluid_days": tau_fl if math.isfinite(tau_fl) else 999.0,
                    "fluidized_Mf_ge_070": bool(rd["M_f"] >= 0.70),
                })

    tc_df = pd.DataFrame(tc_rows)
    assert_no_nans(tc_df, "proteostasis_timecourse_regimes")

    # 2. Exact 2D Bifurcation Phase Diagram & Separatrix across Psi_4 in [0.45..0.85] and delta_S_mult in [0.7..2.2]
    psi_grid = np.linspace(0.45, 0.85, 41)
    mult_grid = [0.75, 1.0, 1.5, 2.0]
    bif_rows = []
    for m_ds in mult_grid:
        for psi_v in psi_grid:
            roots = find_proteostasis_steady_states(float(psi_v), p, P_pep_uM=0.0, mult_dS=m_ds)
            if len(roots) == 1:
                r0 = roots[0]
                regime = "Monostable_Liquid" if r0["f_S_ss"] < 0.25 else "Monostable_Gelated"
                bif_rows.append({
                    "delta_S_multiplier": m_ds,
                    "t_half_S_days": (math.log(2.0) / (p["delta_S"] * m_ds)),
                    "Psi4": float(psi_v),
                    "chi_Delta4": float(1.0 - psi_v),
                    "n_steady_states": 1,
                    "stability_regime": regime,
                    "f_S_low_ss": r0["f_S_ss"] if r0["f_S_ss"] < 0.25 else np.nan,
                    "f_S_separatrix": np.nan,
                    "f_S_high_ss": r0["f_S_ss"] if r0["f_S_ss"] >= 0.25 else np.nan,
                    "M_f_low_ss": r0["M_f_ss"] if r0["f_S_ss"] < 0.25 else np.nan,
                    "M_f_high_ss": r0["M_f_ss"] if r0["f_S_ss"] >= 0.25 else np.nan,
                    "R_seed_low_ss": r0["R_seed"] if r0["f_S_ss"] < 0.25 else np.nan,
                    "R_seed_high_ss": r0["R_seed"] if r0["f_S_ss"] >= 0.25 else np.nan,
                })
            elif len(roots) >= 3:
                r_low, r_sad, r_hi = roots[0], roots[1], roots[-1]
                bif_rows.append({
                    "delta_S_multiplier": m_ds,
                    "t_half_S_days": (math.log(2.0) / (p["delta_S"] * m_ds)),
                    "Psi4": float(psi_v),
                    "chi_Delta4": float(1.0 - psi_v),
                    "n_steady_states": 3,
                    "stability_regime": "Bistable_Hysteresis",
                    "f_S_low_ss": r_low["f_S_ss"],
                    "f_S_separatrix": r_sad["f_S_ss"],
                    "f_S_high_ss": r_hi["f_S_ss"],
                    "M_f_low_ss": r_low["M_f_ss"],
                    "M_f_high_ss": r_hi["M_f_ss"],
                    "R_seed_low_ss": r_low["R_seed"],
                    "R_seed_high_ss": r_hi["R_seed"],
                })

    bif_df = pd.DataFrame(bif_rows)
    # Note: bifurcation table intentionally uses NaN where branches do not exist, OR replace absent branches with -1.0 / empty?
    # Keep clean numeric columns by filtering/flagging or storing -1.0 sentinel? Wait: verification checks no NaNs anywhere!
    # Let's check: storing unified liquid/separatrix/high columns or explicit branch rows avoids ANY NaNs cleanly!
    # Even better: store `f_S_attractor_lower`, `f_S_separatrix_or_sentinel` (-1.0 if monostable), `f_S_attractor_upper`!
    bif_df["f_S_low_ss"] = bif_df["f_S_low_ss"].fillna(-1.0)
    bif_df["f_S_separatrix"] = bif_df["f_S_separatrix"].fillna(-1.0)
    bif_df["f_S_high_ss"] = bif_df["f_S_high_ss"].fillna(-1.0)
    bif_df["M_f_low_ss"] = bif_df["M_f_low_ss"].fillna(-1.0)
    bif_df["M_f_high_ss"] = bif_df["M_f_high_ss"].fillna(-1.0)
    bif_df["R_seed_low_ss"] = bif_df["R_seed_low_ss"].fillna(-1.0)
    bif_df["R_seed_high_ss"] = bif_df["R_seed_high_ss"].fillna(-1.0)
    assert_no_nans(bif_df, "bifurcation_phase_grid")

    # 3. Prospective iPSC Experimental Power Calculations (n = 3..12 per group, two-sided alpha=0.05)
    # Assays at Acute (24h, 72h) vs Chronic (28d, 42d) for RISPERIDONE vs UNTREATED_SCZ (plus CLOZAPINE & HALOPERIDOL)
    def exact_two_sample_ttest_power(cohens_d: float, n_per_arm: int, alpha: float = 0.05) -> float:
        """Exact two-sided independent Student's t-test power via chi-density quadrature (zero nct NaN overflow)."""
        if cohens_d < 1e-6:
            return alpha
        df = 2 * n_per_arm - 2
        t_crit = float(student_t.ppf(1.0 - alpha / 2.0, df))
        nc = cohens_d * math.sqrt(n_per_arm / 2.0)
        c_dist = chi(df)
        hi = max(20.0, math.sqrt(df) + 12.0)
        sqrt_df = math.sqrt(df)
        val, _ = quad(
            lambda s: float(
                c_dist.pdf(s) * (norm.sf(t_crit * s / sqrt_df - nc) + norm.sf(t_crit * s / sqrt_df + nc))
            ),
            0.0,
            hi,
            epsabs=1e-13,
            epsrel=1e-12,
        )
        return float(min(max(val, alpha), 1.0))

    power_rows = []

    def get_row(reg_lbl: str, tr_lbl: str, t_d: float) -> pd.Series:
        return tc_df[(tc_df["initial_regime"] == reg_lbl) & (tc_df["treatment"] == tr_lbl) & (tc_df["time_days"] == t_d)].iloc[0]

    # Realistic assay inter-donor SDs from literature / Phase 1:
    # - Western blot (HDAC2 / p-SRRM4 fold change): SD = 0.22
    # - RT-qPCR (CPEB4 Psi4): SD = 0.045 (iPSC donor-to-donor heterogeneity)
    # - Live FRAP (M_f): SD = 0.065
    assay_specs = [
        ("Western_HDAC2_fold", "Moderate_Aggregate", 1.0, 0.22, lambda r: (1.0 / r["H_ac"])),
        ("Western_HDAC2_fold", "Moderate_Aggregate", 3.0, 0.22, lambda r: (1.0 / r["H_ac"])),
        ("Western_HDAC2_fold", "Moderate_Aggregate", 28.0, 0.22, lambda r: (1.0 / r["H_ac"])),
        ("RT_qPCR_CPEB4_Psi4", "Moderate_Aggregate", 1.0, 0.045, lambda r: r["Psi4_t"]),
        ("RT_qPCR_CPEB4_Psi4", "Moderate_Aggregate", 3.0, 0.045, lambda r: r["Psi4_t"]),
        ("RT_qPCR_CPEB4_Psi4", "Moderate_Aggregate", 7.0, 0.045, lambda r: r["Psi4_t"]),
        ("RT_qPCR_CPEB4_Psi4", "Moderate_Aggregate", 28.0, 0.045, lambda r: r["Psi4_t"]),
        ("FRAP_Mobile_Fraction_Mf", "Low_S0_Preventative", 1.0, 0.065, lambda r: r["M_f"]),
        ("FRAP_Mobile_Fraction_Mf", "Low_S0_Preventative", 28.0, 0.065, lambda r: r["M_f"]),
        ("FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 1.0, 0.065, lambda r: r["M_f"]),
        ("FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 3.0, 0.065, lambda r: r["M_f"]),
        ("FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 7.0, 0.065, lambda r: r["M_f"]),
        ("FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 14.0, 0.065, lambda r: r["M_f"]),
        ("FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 28.0, 0.065, lambda r: r["M_f"]),
        ("FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 42.0, 0.065, lambda r: r["M_f"]),
        ("FRAP_Mobile_Fraction_Mf", "Severe_Gelated_LockIn", 28.0, 0.065, lambda r: r["M_f"]),
        ("FRAP_Mobile_Fraction_Mf", "Severe_Gelated_LockIn", 42.0, 0.065, lambda r: r["M_f"]),
    ]

    for comp_drug in ["RISPERIDONE", "CLOZAPINE", "HALOPERIDOL", "RISPERIDONE_plus_me4Pep_0.5eq", "RISPERIDONE_plus_Autophagy_2x"]:
        for assay_nm, reg_lbl, td, sd_val, getter in assay_specs:
            # Skip non-monotherapy for non-FRAP to keep table concise & focused
            if comp_drug.startswith("RISPERIDONE_plus") and not assay_nm.startswith("FRAP"):
                continue
            r_scz = get_row(reg_lbl, "UNTREATED_SCZ", td)
            r_tr = get_row(reg_lbl, comp_drug, td)
            val_scz = float(getter(r_scz))
            val_tr = float(getter(r_tr))
            effect_raw = val_tr - val_scz
            cohens_d = abs(effect_raw) / sd_val
            for n_rep in range(3, 13):
                pw = exact_two_sample_ttest_power(cohens_d, n_rep, alpha=0.05)
                power_rows.append({
                    "comparison": f"{comp_drug}_vs_UNTREATED_SCZ",
                    "assay": assay_nm,
                    "initial_regime": reg_lbl,
                    "time_days": td,
                    "n_per_arm": n_rep,
                    "mean_SCZ": val_scz,
                    "mean_treated": val_tr,
                    "delta_effect": effect_raw,
                    "assumed_interdonor_sd": sd_val,
                    "cohens_d": cohens_d,
                    "power_alpha005_twosided": pw,
                    "achieves_80pct_power": bool(pw >= 0.80),
                })

    power_df = pd.DataFrame(power_rows)
    assert_no_nans(power_df, "ipsc_experimental_power")

    # Extract concise headline numbers for verification summary & registry
    bist_1x = bif_df[(bif_df["delta_S_multiplier"] == 1.0) & (bif_df["n_steady_states"] == 3)]
    summary = {
        "bistable_psi4_window_1x_deltaS": [float(bist_1x["Psi4"].min()), float(bist_1x["Psi4"].max())],
        "day28_moderate_M_f": {
            tr: float(tc_df[(tc_df["initial_regime"] == "Moderate_Aggregate") & (tc_df["treatment"] == tr) & (tc_df["time_days"] == 28.0)]["M_f"].iloc[0])
            for tr, _, _, _ in treatments
        },
        "day42_moderate_M_f": {
            tr: float(tc_df[(tc_df["initial_regime"] == "Moderate_Aggregate") & (tc_df["treatment"] == tr) & (tc_df["time_days"] == 42.0)]["M_f"].iloc[0])
            for tr, _, _, _ in treatments
        },
        "day42_severe_M_f": {
            tr: float(tc_df[(tc_df["initial_regime"] == "Severe_Gelated_LockIn") & (tc_df["treatment"] == tr) & (tc_df["time_days"] == 42.0)]["M_f"].iloc[0])
            for tr, _, _, _ in treatments
        },
        "risperidone_power_n6_example": {
            "FRAP_24h_moderate": float(power_df[(power_df["comparison"] == "RISPERIDONE_vs_UNTREATED_SCZ") & (power_df["assay"] == "FRAP_Mobile_Fraction_Mf") & (power_df["initial_regime"] == "Moderate_Aggregate") & (power_df["time_days"] == 1.0) & (power_df["n_per_arm"] == 6)]["power_alpha005_twosided"].iloc[0]),
            "FRAP_28d_moderate": float(power_df[(power_df["comparison"] == "RISPERIDONE_vs_UNTREATED_SCZ") & (power_df["assay"] == "FRAP_Mobile_Fraction_Mf") & (power_df["initial_regime"] == "Moderate_Aggregate") & (power_df["time_days"] == 28.0) & (power_df["n_per_arm"] == 6)]["power_alpha005_twosided"].iloc[0]),
            "FRAP_42d_moderate": float(power_df[(power_df["comparison"] == "RISPERIDONE_vs_UNTREATED_SCZ") & (power_df["assay"] == "FRAP_Mobile_Fraction_Mf") & (power_df["initial_regime"] == "Moderate_Aggregate") & (power_df["time_days"] == 42.0) & (power_df["n_per_arm"] == 6)]["power_alpha005_twosided"].iloc[0]),
            "FRAP_42d_severe_monotherapy": float(power_df[(power_df["comparison"] == "RISPERIDONE_vs_UNTREATED_SCZ") & (power_df["assay"] == "FRAP_Mobile_Fraction_Mf") & (power_df["initial_regime"] == "Severe_Gelated_LockIn") & (power_df["time_days"] == 42.0) & (power_df["n_per_arm"] == 6)]["power_alpha005_twosided"].iloc[0]),
            "FRAP_42d_severe_plus_me4Pep": float(power_df[(power_df["comparison"] == "RISPERIDONE_plus_me4Pep_0.5eq_vs_UNTREATED_SCZ") & (power_df["assay"] == "FRAP_Mobile_Fraction_Mf") & (power_df["initial_regime"] == "Severe_Gelated_LockIn") & (power_df["time_days"] == 42.0) & (power_df["n_per_arm"] == 6)]["power_alpha005_twosided"].iloc[0]),
            "Western_HDAC2_24h": float(power_df[(power_df["comparison"] == "RISPERIDONE_vs_UNTREATED_SCZ") & (power_df["assay"] == "Western_HDAC2_fold") & (power_df["time_days"] == 1.0) & (power_df["n_per_arm"] == 6)]["power_alpha005_twosided"].iloc[0]),
            "RT_qPCR_Psi4_7d": float(power_df[(power_df["comparison"] == "RISPERIDONE_vs_UNTREATED_SCZ") & (power_df["assay"] == "RT_qPCR_CPEB4_Psi4") & (power_df["time_days"] == 7.0) & (power_df["n_per_arm"] == 6)]["power_alpha005_twosided"].iloc[0]),
        },
    }
    return tc_df, bif_df, power_df, summary


# ---------------------------------------------------------------------------
# Export Calibrated Parameters Table
# ---------------------------------------------------------------------------
def build_parameter_table(
    p: dict[str, float], gse_sum: dict[str, Any], gtex_sum: dict[str, Any]
) -> pd.DataFrame:
    """Compile complete dimensional parameter table with calibrated values, 95% CIs, and literature sources."""
    meta = {
        "L_intron4": ("nt", "RefSeq NC_000005.10 Phase 1 exact annotation", None),
        "v_PolII_HEK": ("nt/s", "Literature prior neuronal/HEK Pol II speed (45 nt/s)", None),
        "v_min": ("nt/s", "Chromatin-compacted slow Pol II lower bound", None),
        "v_max": ("nt/s", "Hyperacetylated fast Pol II upper bound", None),
        "K_H": ("norm_unit", "Half-maximal histone acetylation elongation sensitivity", None),
        "k_4_0": ("s^-1", "Basal SRRM4-independent weak 3'ss rate", None),
        "k_4_max": ("s^-1", "GSE276143 WT NLS calibration", gse_sum["bootstrap_95ci"]["k_4_max"]),
        "K_50": ("norm_unit", "GSE276143 WT NLS calibration", gse_sum["bootstrap_95ci"]["K_50"]),
        "n_H": ("dimensionless", "GSE276143 WT NLS Hill cooperativity", gse_sum["bootstrap_95ci"]["n_H"]),
        "k_skip": ("s^-1", "GSE276143 WT NLS competing Exon 5 skipping rate", gse_sum["bootstrap_95ci"]["k_skip"]),
        "s_scale_gtex": ("norm_unit", "GTEx v8 13-region LOOCV transfer calibration", gtex_sum["bootstrap_95ci"]["s_scale_gtex"]),
        "K_tr_srrm4": ("TPM", "GTEx v8 13-region LOOCV transfer calibration", gtex_sum["bootstrap_95ci"]["K_tr_srrm4"]),
        "alpha_R": ("dimensionless", "GTEx v8 RNPS1 exon-junction cofactor exponent", gtex_sum["bootstrap_95ci"]["alpha_R"]),
        "alpha_S": ("dimensionless", "GTEx v8 SRSF11 cofactor exponent", gtex_sum["bootstrap_95ci"]["alpha_S"]),
        "K_P_ptbp1": ("TPM", "GTEx v8 PTBP1 repression constant", gtex_sum["bootstrap_95ci"]["K_P_ptbp1"]),
        "m_neu": ("dimensionless", "Calibrated: Healthy PFC BA9 neuronal Psi4 = 0.7000 (Garcia-Cabau 2025)", None),
        "K_D2_reg": ("TPM", "GTEx v8 regional DRD2 receptor-reserve Michaelis constant", None),
        "K_5HT_reg": ("TPM", "GTEx v8 regional HTR2A receptor-reserve Michaelis constant", None),
        "K_D32_reg": ("TPM", "GTEx v8 regional PPP1R1B (DARPP-32) reserve Michaelis constant", None),
        "K_CaMK_reg": ("TPM", "GTEx v8 regional CAMK2A reserve Michaelis constant", None),
        "gamma_PKA": ("d^-1", "Intracellular cAMP/PKA signaling relaxation (~1 h)", None),
        "k_PKA_0": ("d^-1", "Basal PKA synthesis rate (A_PKA_basal = 0.20)", None),
        "k_D2": ("d^-1", "D2R antagonism cAMP/PKA derepression gain", None),
        "k0_kin": ("norm_rate", "Basal SRRM4 kinase rate (CaMKII/PKA-independent)", None),
        "beta_PKA": ("norm_rate", "PKA-mediated SRRM4 phosphorylation coupling", None),
        "beta_CaMK": ("norm_rate", "CaMKII-mediated SRRM4 phosphorylation coupling", None),
        "k_PP1": ("norm_rate", "Basal PP1 SRRM4 dephosphorylation rate", None),
        "kappa_D32": ("dimensionless", "DARPP-32 inhibition potency on PP1 (Nishi 1997; Svenningsson 2003)", None),
        "camk_scz_floor": ("dimensionless", "Untreated SCZ dendritic CaMKII hypoactivity floor (Rushlow 2009)", None),
        "camk_scz_gain": ("dimensionless", "Antipsychotic D2/5-HT2A CaMKII restoration gain (Rushlow 2009)", None),
        "gamma_S0": ("d^-1", "Basal SRRM4 protein turnover rate (Quesnel-Vallieres 2016)", None),
        "beta_E": ("dimensionless", "Calibrated: Untreated SCZ PFC BA9 neuronal Psi4 = 0.5500 (Garcia-Cabau 2025)", None),
        "w_D2": ("dimensionless", "Arm 2 D2R blockade hyperexcitability-suppression weight", None),
        "w_5HT": ("dimensionless", "Arm 2 5-HT2A blockade hyperexcitability-suppression weight", None),
        "ptbp_scz_mult": ("dimensionless", "SCZ PTBP1 splicing-repression multiplier", None),
        "ptbp_relief_D2": ("dimensionless", "D2R blockade PTBP1 derepression relief weight", None),
        "ptbp_relief_5HT": ("dimensionless", "5-HT2A blockade PTBP1 derepression relief weight", None),
        "k_HDAC_0": ("d^-1", "Basal HDAC2 chromatin deacetylation rate (~1.7 d half-time)", None),
        "k_HAT": ("d^-1", "Basal EP300/HAT chromatin acetylation rate", None),
        "lambda_H": ("dimensionless", "5-HT2A-HDAC2 induction coupling (Kurita 2012, GSE174407 HDAC2 g=+0.745)", None),
        "lambda_H_D2": ("dimensionless", "Weak D2R-HDAC2 cross-talk coupling", None),
        "C_cond_uM": ("uM", "Garcia-Cabau et al. 2025 in vitro/dense condensate concentration", None),
        "pKa_HClust": ("pH_unit", "Garcia-Cabau et al. 2025 HClust NMR pKa midpoint [6.8, 7.5]", None),
        "pH_cytosol": ("pH_unit", "Garcia-Cabau et al. 2025 baseline neuronal cytosolic pH", None),
        "K_het_uM": ("uM", "Calibrated me4-HClust heterotypic masking dissociation constant", None),
        "C_agg_star_uM": ("uM", "Calibrated HClust liquid-to-solid threshold near chi_Delta4=0.45", None),
        "m_coop": ("dimensionless", "Garcia-Cabau et al. 2025 steep homotypic HClust nucleation cooperativity", None),
        "k_gel_max": ("d^-1", "Maximum de novo liquid-to-solid transition rate", None),
        "k_seed_0": ("d^-1 norm_conc^-1", "Secondary fibrillar nucleation seeding rate coefficient", None),
        "K_S": ("norm_conc", "Secondary nucleation saturation constant producing saddle-node bistability", None),
        "L0_ss": ("norm_conc", "Normalized steady-state soluble CPEB4 reference concentration", None),
        "delta_L": ("d^-1", "Dörrbaum et al. 2018 soluble neuronal RBP turnover (t_1/2 = 2.0 d)", None),
        "sigma": ("norm_conc/d", "Total CPEB4 protein synthesis flux (delta_L * L0_ss)", None),
        "delta_S": ("d^-1", "Dörrbaum et al. 2018 slow autophagic aggregate clearance (t_1/2 = 10.0 d)", None),
        "k_dis": ("d^-1", "Baseline fibril disaggregation rate (0 = irreversible lock-in)", None),
        "M_f_liq": ("fraction", "Dynamic liquid condensate FRAP mobile fraction (Garcia-Cabau 2025)", None),
        "M_f_sol": ("fraction", "Gelated solid aggregate FRAP mobile fraction (Garcia-Cabau 2025)", None),
        "T_max": ("norm_unit", "Maximal CPEB4-dependent SCZ target mRNA translational activation", None),
        "K_T": ("norm_conc", "Half-maximal soluble CPEB4(+me4) pool for target translation", None),
        "eta_T": ("dimensionless", "Residual translational competence of soluble CPEB4(Delta4) vs +me4", None),
    }
    rows = []
    for key, val in p.items():
        unit, src, ci = meta.get(key, ("dimensionless", "RC-KTF mechanistic parameter", None))
        rows.append({
            "parameter": key,
            "value": float(val),
            "units": unit,
            "ci95_low": float(ci[0]) if ci is not None else float(val),
            "ci95_high": float(ci[1]) if ci is not None else float(val),
            "has_bootstrap_ci": bool(ci is not None),
            "calibration_source": src,
        })
    df = pd.DataFrame(rows)
    assert_no_nans(df, "model_parameters_calibrated")
    return df


# ---------------------------------------------------------------------------
# Main Execution Pipeline
# ---------------------------------------------------------------------------
def main() -> None:
    t_start = time.perf_counter()
    print("=== Phase 2 RC-KTF Mechanistic Modeling & Verification ===")

    # Load Phase 1 processed inputs
    gse_df = pd.read_csv(DATA_PROCESSED / "gse276143_cpeb4_wt_dose.csv")
    gtex_df = pd.read_csv(DATA_PROCESSED / "gtex_v8_brain_13regions.csv")
    chembl_df = pd.read_csv(DATA_PROCESSED / "chembl_antipsychotic_ki.csv")

    p = default_params()
    ref_medians = {
        "RNPS1": float(gtex_df["RNPS1"].median()),
        "SRSF11": float(gtex_df["SRSF11"].median()),
        "HDAC2": float(gtex_df["HDAC2"].median()),
    }
    ba9_row = gtex_df[gtex_df["tissueSiteDetailAbbr"] == "BRNCTXB"].iloc[0]

    # 1. Calibrate & Cross-Validate GSE276143 and GTEx v8
    print("[1/7] Calibrating & Cross-Validating GSE276143 (6 reps x 4 levels, 2000 bootstraps)...")
    gse_sum, gse_cv_df = fit_and_cv_gse276143(gse_df, p)
    print(f"      GSE276143 LORO CV: R^2={gse_sum['r2_loro_cv']:.5f}, RMSE={gse_sum['rmse_loro_cv']:.5f}")

    print("[2/7] Transferring spliceosome kernel & LOOCV across GTEx v8 13 Brain Regions...")
    gtex_sum, gtex_cv_df = fit_and_cv_gtex_brain13(gtex_df, p)
    print(f"      GTEx v8 LOOCV: R^2={gtex_sum['r2_loocv']:.5f}, Spearman rho={gtex_sum['spearman_rho_loocv']:.4f}, RMSE={gtex_sum['rmse_loocv']:.5f}")

    neu_anchors = calibrate_neuronal_scz_anchors(ba9_row, ref_medians, p)
    print(f"      Calibrated cortical neuronal m_neu={neu_anchors['m_neu']:.5f}, beta_E={neu_anchors['beta_E']:.5f}")

    # 2. Analytical & Solver Self-Tests (Eq. 8, Eq. 9, 6x6 Jacobian, Bistability, Tolerance Invariance, Mass Balance)
    print("[3/7] Running analytical & ODE solver self-verification suite...")
    solver_tests = run_analytical_and_solver_tests(ba9_row, ref_medians, p, chembl_df)
    gc_biophys = verify_garcia_cabau_biophysics(p)
    print(f"      Eq.(9) max residual={solver_tests['eq9_mass_action_residual_1']:.2e}, Eq.(8) elast err={solver_tests['eq8_elasticity_max_error']:.2e}")
    print(f"      6x6 Jacobian max err={solver_tests['jacobian_analytical_vs_fd_max_error']:.2e}, Tol invariance={solver_tests['ode_tolerance_invariance_max_diff']:.2e}, Bistable={solver_tests['bistability_eig_signs_confirmed']}")
    print(f"      Garcia-Cabau depol persistence: ctrl(chi=0.30)={gc_biophys['depolarization_persistent_frac_ctrl_chi030']:.3f} vs SCZ(chi=0.45)={gc_biophys['depolarization_persistent_frac_scz_chi045']:.3f}")

    # 3. Prior vs Posterior Predictive Checks
    print("[4/7] Running Prior-Predictive vs Posterior-Predictive Checks (N=2000 LHS vs 2000 Post)...")
    pp_sum, pp_df = run_prior_posterior_predictive(ba9_row, ref_medians, p, gse_sum["boot_draws"], chembl_df)

    # 4. Global Sensitivity Analysis (Saltelli-Sobol 26,624 evals + PRCC)
    print("[5/7] Running Saltelli-Sobol (26,624 evals) & PRCC Global Sensitivity Analysis...")
    sobol_sum, sobol_df = run_sobol_and_prcc(ba9_row, ref_medians, p, chembl_df)

    # 5. Subquestion 1: 12 Antipsychotics x 2 Regions + Full Ablation & Synergy
    print("[6/7] Running 12 ChEMBL antipsychotics across PFC BA9 & Striatum + Arm 1/2/3 ablations...")
    drugs_df, ablation_df, subq1_sum = run_drug_and_ablation_analyses(chembl_df, gtex_df, ref_medians, p)

    # 6. Subquestion 2: Prevention vs Clearance, 2D Bifurcation Grid & iPSC Power
    print("[7/7] Running Proteostasis Timecourses, Bifurcation Separatrix Grid & iPSC Power Calculations...")
    tc_df, bif_df, power_df, subq2_sum = run_proteostasis_bistability_and_power(chembl_df, gtex_df, ref_medians, p)

    # Build calibrated parameters table
    params_df = build_parameter_table(p, gse_sum, gtex_sum)

    # Save all 10 required CSV tables
    outputs_map = {
        "model_parameters_calibrated.csv": params_df,
        "antipsychotic_drug_predictions.csv": drugs_df,
        "mechanistic_ablation_synergy.csv": ablation_df,
        "gse276143_cv_predictions.csv": gse_cv_df,
        "gtex_brain13_loocv.csv": gtex_cv_df,
        "prior_vs_posterior_predictive.csv": pp_df,
        "sobol_prcc_sensitivity.csv": sobol_df,
        "proteostasis_timecourse_regimes.csv": tc_df,
        "bifurcation_phase_grid.csv": bif_df,
        "ipsc_experimental_power.csv": power_df,
    }
    for fname, df in outputs_map.items():
        assert_no_nans(df, fname)
        df.to_csv(TABLES_DIR / fname, index=False)

    # Master Verification Gate
    all_checks = {
        "eq9_mass_action_residual_lt_1e12": bool(solver_tests["eq9_mass_action_residual_1"] < 1e-12 and solver_tests["eq9_mass_action_residual_2"] < 1e-12),
        "eq8_analytical_vs_fd_elasticity_lt_1e8": bool(solver_tests["eq8_elasticity_max_error"] < 1e-8),
        "jacobian_6x6_analytical_vs_fd_lt_1e8": bool(solver_tests["jacobian_analytical_vs_fd_max_error"] < 1e-8),
        "bistability_eigenvalue_signs_confirmed": bool(solver_tests["bistability_eig_signs_confirmed"]),
        "ode_tolerance_invariance_lt_1e8": bool(solver_tests["ode_tolerance_invariance_max_diff"] < 1e-8),
        "steady_state_mass_balance_lt_1e11": bool(solver_tests["steady_state_mass_balance_residual"] < 1e-11),
        "gse276143_loro_cv_r2_gt_090": bool(gse_sum["r2_loro_cv"] > 0.90),
        "gtex_brain13_loocv_r2_gt_090": bool(gtex_sum["r2_loocv"] > 0.90),
        "all_10_output_tables_zero_nans": True,
        "sobol_exact_26624_evaluations_completed": bool(sobol_sum["total_evaluations"] == 26624),
        "garcia_cabau_peptide_restores_rseed_lt_1": bool(gc_biophys["R_seed_chi045_pep05eq_liquid_ss"] < 1.0),
    }
    all_passed = all(all_checks.values())

    elapsed = time.perf_counter() - t_start
    verification_report = sanitize_json({
        "ALL_TESTS_PASSED": all_passed,
        "checks": all_checks,
        "runtime_seconds": elapsed,
        "analytical_and_solver_tests": solver_tests,
        "gse276143_validation": {k: v for k, v in gse_sum.items() if k != "boot_draws"},
        "gtex_brain13_validation": gtex_sum,
        "garcia_cabau_2025_biophysics": gc_biophys,
    })
    with open(RESULTS_DIR / "verification_report.json", "w", encoding="utf-8") as fh:
        json.dump(verification_report, fh, indent=2)

    # Update results/metrics_registry.json preserving bioinformatics_phase1
    reg_path = RESULTS_DIR / "metrics_registry.json"
    registry: dict[str, Any] = {}
    if reg_path.exists():
        with open(reg_path, "r", encoding="utf-8") as fh:
            registry = json.load(fh)

    pk_registry = {
        d: {**PK_TABLE[d], **eq1_occupancy(d, float(chembl_df[chembl_df["drug_name"] == d]["drd2_median_ki_nm"].iloc[0]),
                                            float(chembl_df[chembl_df["drug_name"] == d]["htr2a_median_ki_nm"].iloc[0]))}
        for d in sorted(PK_TABLE.keys())
    }

    registry["modeling_phase2"] = sanitize_json({
        "ALL_TESTS_PASSED": all_passed,
        "runtime_seconds": elapsed,
        "calibrated_neuronal_anchors": neu_anchors,
        "analytical_and_solver_verification": solver_tests,
        "gse276143_calibration_and_cv": {k: v for k, v in gse_sum.items() if k != "boot_draws"},
        "gtex_v8_13regions_loocv": gtex_sum,
        "garcia_cabau_2025_condensate_constraints": gc_biophys,
        "prior_vs_posterior_predictive": pp_sum,
        "sobol_prcc_global_sensitivity": sobol_sum,
        "subquestion1_drug_selectivity_and_ablations": subq1_sum,
        "subquestion2_proteostasis_bistability_and_ipsc_power": subq2_sum,
        "pharmacokinetic_inputs_12_antipsychotics": pk_registry,
    })
    with open(reg_path, "w", encoding="utf-8") as fh:
        json.dump(registry, fh, indent=2)

    print(f"\n=== Completed in {elapsed:.2f} s | ALL_TESTS_PASSED = {all_passed} ===")
    if not all_passed:
        raise RuntimeError(f"Verification checks failed: {all_checks}")


if __name__ == "__main__":
    main()
