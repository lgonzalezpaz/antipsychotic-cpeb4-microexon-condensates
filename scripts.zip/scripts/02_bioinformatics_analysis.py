#!/usr/bin/env python3
"""
Phase 1 - Step 2: Reproducible multi-omics bioinformatics analysis across all
8 verified public datasets cached in data/raw/.

Outputs:
  data/processed/gtex_v8_brain_13regions.csv
  data/processed/gtex_v8_54tissues.csv
  results/tables/gtex_v8_correlations.csv
  data/processed/gse276143_cpeb4_wt_dose.csv
  data/processed/gse276143_cpeb4_variants.csv
  data/processed/cpeb4_cis_architecture.json
  data/processed/uniprot_protein_features.csv
  data/processed/chembl_antipsychotic_ki.csv
  data/processed/string_network_edges.csv
  data/processed/string_network_paths.csv
  results/tables/string_network_centrality.csv
  data/processed/gse138082_differential.csv
  data/processed/gse174407_neun_donor_counts.csv.gz
  data/processed/gse174407_differential.csv
  data/processed/gse163161_differential.csv
  data/processed/gse315204_differential.csv
  data/processed/gse67755_differential.csv
  data/processed/cross_cohort_meta.csv
  results/tables/bioinformatics_summary.json
  results/metrics_registry.json
"""

from __future__ import annotations

import datetime as dt
import gzip
import io
import json
import math
import re
import sys
from pathlib import Path
from typing import Any

import networkx as nx
import numpy as np
import pandas as pd
import scipy.stats as st
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = PROJECT_ROOT / "data" / "raw"
PROC_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results"
TABLES_DIR = RESULTS_DIR / "tables"

GENES_31 = [
    "CPEB4", "SRRM4", "SRRM3", "SRSF11", "RNPS1", "RBFOX1", "RBFOX2", "RBFOX3",
    "PTBP1", "PTBP2", "HNRNPC", "DRD2", "HTR2A", "DRD1", "HTR1A", "ADRA1A",
    "PRKACA", "PRKACB", "PPP1R1B", "CAMK2A", "CAMK2B", "AKT1", "GSK3B",
    "SRPK1", "SRPK2", "DYRK1A", "HDAC2", "HDAC1", "POLR2A", "SYP", "SNAP25",
]

# Expanded 37-gene pathway panel covering GTEx (31) + STRING (27) union
PATHWAY_GENES_37 = [
    "CPEB4", "SRRM4", "SRRM3", "SRSF11", "RNPS1", "RBFOX1", "RBFOX2", "RBFOX3",
    "PTBP1", "PTBP2", "HNRNPC", "DRD2", "HTR2A", "DRD1", "HTR1A", "ADRA1A",
    "GNAI2", "GNAQ", "ARRB2", "PRKACA", "PRKACB", "PPP1R1B", "PPP1CA",
    "CAMK2A", "CAMK2B", "AKT1", "GSK3B", "MAPK1", "SRPK1", "SRPK2", "DYRK1A",
    "HDAC2", "HDAC1", "EP300", "POLR2A", "SYP", "SNAP25",
]

MODULES = {
    "MODULE_SPLICING_COMPLEX": [
        "SRRM4", "SRRM3", "SRSF11", "RNPS1", "RBFOX1", "RBFOX2", "RBFOX3", "PTBP2", "CPEB4"
    ],
    "MODULE_HYPEREXCITABILITY_KINASES": [
        "PRKACA", "PRKACB", "PPP1R1B", "CAMK2A", "CAMK2B", "AKT1", "GSK3B", "SRPK1", "SRPK2", "DYRK1A", "MAPK1"
    ],
    "MODULE_EPIGENETIC_POL2": [
        "HDAC1", "HDAC2", "EP300", "POLR2A"
    ],
}

STRING_NODES_27 = [
    "DRD2", "HTR2A", "DRD1", "HTR1A", "GNAI2", "GNAQ", "ARRB2",
    "PRKACA", "PPP1R1B", "PPP1CA", "CAMK2A", "AKT1", "GSK3B", "MAPK1",
    "SRPK1", "SRPK2", "DYRK1A", "HDAC2", "EP300", "POLR2A",
    "SRRM4", "SRSF11", "RNPS1", "RBFOX1", "PTBP1", "HNRNPC", "CPEB4",
]

CHEMBL_DRUG_CLASSES = {
    "HALOPERIDOL": "Typical (First-Gen)",
    "FLUPHENAZINE": "Typical (First-Gen)",
    "CHLORPROMAZINE": "Typical (First-Gen)",
    "RISPERIDONE": "Atypical (SDA)",
    "PALIPERIDONE": "Atypical (SDA)",
    "OLANZAPINE": "Atypical (MARTA)",
    "CLOZAPINE": "Atypical (MARTA)",
    "QUETIAPINE": "Atypical (MARTA)",
    "ARIPIPRAZOLE": "Atypical (D2 Partial Agonist)",
    "ZIPRASIDONE": "Atypical (SDA)",
    "AMISULPRIDE": "Atypical (D2/D3 Benzamide)",
    "LURASIDONE": "Atypical (SDA)",
}

Z_95 = 1.959963984540054


def bh_fdr(pvals: np.ndarray | list[float]) -> np.ndarray:
    arr = np.asarray(pvals, dtype=float)
    if arr.size == 0:
        return arr
    return multipletests(arr, method="fdr_bh")[1]


def fisher_ci(r: float, n: int, k_cov: int = 0, spearman: bool = False) -> tuple[float, float]:
    if n <= 3 + k_cov:
        return (float(r), float(r))
    if abs(r) >= 0.999999:
        return (float(r), float(r))
    z = math.atanh(r)
    if spearman:
        se = math.sqrt((1.0 + 0.5 * (r ** 2)) / (n - 3 - k_cov))
    else:
        se = 1.0 / math.sqrt(n - 3 - k_cov)
    return (math.tanh(z - Z_95 * se), math.tanh(z + Z_95 * se))


def partial_corr(
    x: np.ndarray,
    y: np.ndarray,
    covs: np.ndarray,
    spearman: bool = False,
) -> tuple[float, float, float, float]:
    """Compute partial Pearson or Spearman correlation controlling for covs."""
    n = len(x)
    k = covs.shape[1]
    if spearman:
        xv = st.rankdata(x)
        yv = st.rankdata(y)
        zv = np.column_stack([st.rankdata(covs[:, j]) for j in range(k)])
    else:
        xv = x.astype(float)
        yv = y.astype(float)
        zv = covs.astype(float)
    design = np.column_stack([np.ones(n), zv])
    bx, _, _, _ = np.linalg.lstsq(design, xv, rcond=None)
    by, _, _, _ = np.linalg.lstsq(design, yv, rcond=None)
    rx = xv - design @ bx
    ry = yv - design @ by
    if np.std(rx) < 1e-12 or np.std(ry) < 1e-12:
        return (0.0, 1.0, 0.0, 0.0)
    r, _ = st.pearsonr(rx, ry)
    r = float(np.clip(r, -0.999999999, 0.999999999))
    df = n - 2 - k
    t_val = r * math.sqrt(df / max(1e-15, 1.0 - r ** 2))
    p_val = float(2.0 * st.t.sf(abs(t_val), df))
    ci_lo, ci_hi = fisher_ci(r, n, k_cov=k, spearman=spearman)
    return (r, p_val, ci_lo, ci_hi)


def verify_no_nans(df: pd.DataFrame, name: str) -> None:
    nan_counts = df.isna().sum()
    bad = nan_counts[nan_counts > 0]
    if not bad.empty:
        raise ValueError(f"Unexpected NaNs in {name}: {bad.to_dict()}")


# ==============================================================================
# 1. GTEx v8 Analysis
# ==============================================================================
def analyze_gtex_v8() -> dict[str, Any]:
    print("[1/8] Analyzing GTEx v8...")
    gdir = RAW_DIR / "gtex_v8"
    tissues_raw = json.loads((gdir / "tissueSiteDetail.json").read_text(encoding="utf-8"))["data"]
    junc_raw = json.loads((gdir / "cpeb4_median_junction_expression.json").read_text(encoding="utf-8"))["data"]
    exon_raw = json.loads((gdir / "cpeb4_median_exon_expression.json").read_text(encoding="utf-8"))["data"]
    mge_raw = json.loads((gdir / "median_gene_expression_31genes.json").read_text(encoding="utf-8"))["data"]

    t_meta = pd.DataFrame([
        {
            "tissueSiteDetailId": t["tissueSiteDetailId"],
            "tissueSiteDetail": t["tissueSiteDetail"],
            "tissueSiteDetailAbbr": t["tissueSiteDetailAbbr"],
            "ontologyId": t["ontologyId"],
            "is_brain": bool(t["tissueSiteDetailId"].startswith("Brain_")),
        }
        for t in tissues_raw
    ]).sort_values("tissueSiteDetailId").reset_index(drop=True)
    if len(t_meta) != 54 or int(t_meta["is_brain"].sum()) != 13:
        raise RuntimeError(f"Expected 54 tissues and 13 brain regions, got {len(t_meta)} and {t_meta['is_brain'].sum()}")

    # Pivot junctions
    j_df = pd.DataFrame(junc_raw)
    j_piv = j_df.pivot(index="tissueSiteDetailId", columns="junctionId", values="median")
    req_juncs = {
        "J_2_4": "chr5_173910605_173943025",
        "J_3_4": "chr5_173932501_173943025",
        "J_4_5": "chr5_173943050_173944966",
        "J_2_5": "chr5_173910605_173944966",
        "J_3_5": "chr5_173932501_173944966",
    }
    j_tbl = pd.DataFrame(index=t_meta["tissueSiteDetailId"])
    for k, col in req_juncs.items():
        j_tbl[k] = j_piv[col].reindex(j_tbl.index).astype(float)
    j_tbl["I4"] = 0.5 * (j_tbl["J_2_4"] + j_tbl["J_3_4"] + j_tbl["J_4_5"])
    j_tbl["E4"] = j_tbl["J_2_5"] + j_tbl["J_3_5"]
    denom = j_tbl["I4"] + j_tbl["E4"]
    j_tbl["PSI4"] = np.where(denom > 0, j_tbl["I4"] / denom, 0.0)

    # Exon 7 / Exon 8 orthogonal cross-check
    e_df = pd.DataFrame(exon_raw)
    e_piv = e_df.pivot(index="tissueSiteDetailId", columns="exonId", values="median")
    j_tbl["exon7_median"] = e_piv["ENSG00000113742.12_7"].reindex(j_tbl.index).astype(float)
    j_tbl["exon8_median"] = e_piv["ENSG00000113742.12_8"].reindex(j_tbl.index).astype(float)
    j_tbl["exon7_exon8_ratio"] = np.where(
        j_tbl["exon8_median"] > 0, j_tbl["exon7_median"] / j_tbl["exon8_median"], 0.0
    )
    j_tbl["exon7_exon8_len_norm_ratio"] = np.where(
        j_tbl["exon8_median"] > 0, (j_tbl["exon7_median"] / 24.0) / (j_tbl["exon8_median"] / 174.0), 0.0
    )

    # 31 gene TPMs
    g_df = pd.DataFrame(mge_raw)
    g_piv = g_df.pivot(index="tissueSiteDetailId", columns="geneSymbol", values="median")[GENES_31]
    g_piv = g_piv.reindex(j_tbl.index).astype(float)

    full_df = t_meta.merge(j_tbl.reset_index(), on="tissueSiteDetailId").merge(g_piv.reset_index(), on="tissueSiteDetailId")
    brain_df = full_df[full_df["is_brain"]].copy().reset_index(drop=True)

    verify_no_nans(full_df, "gtex_v8_54tissues")
    verify_no_nans(brain_df, "gtex_v8_brain_13regions")
    full_df.to_csv(PROC_DIR / "gtex_v8_54tissues.csv", index=False)
    brain_df.to_csv(PROC_DIR / "gtex_v8_brain_13regions.csv", index=False)

    # Correlations across brain_13 and all_54
    corr_rows: list[dict[str, Any]] = []
    for scope_name, sub in [("brain_13", brain_df), ("all_54", full_df)]:
        n = len(sub)
        psi = sub["PSI4"].to_numpy(dtype=float)
        rbfox3_log2 = np.log2(sub["RBFOX3"].to_numpy(dtype=float) + 1.0)
        syp_log2 = np.log2(sub["SYP"].to_numpy(dtype=float) + 1.0)

        scope_rows: list[dict[str, Any]] = []
        for gene in GENES_31:
            tpm = sub[gene].to_numpy(dtype=float)
            log2_tpm = np.log2(tpm + 1.0)
            if np.std(tpm) < 1e-12:
                rho, sp_p, sp_lo, sp_hi = 0.0, 1.0, 0.0, 0.0
                pr, pr_p, pr_lo, pr_hi = 0.0, 1.0, 0.0, 0.0
            else:
                rho_res = st.spearmanr(tpm, psi)
                rho = float(rho_res.statistic)
                sp_p = float(rho_res.pvalue)
                sp_lo, sp_hi = fisher_ci(rho, n, k_cov=0, spearman=True)
                pr_res = st.pearsonr(log2_tpm, psi)
                pr = float(pr_res.statistic)
                pr_p = float(pr_res.pvalue)
                pr_lo, pr_hi = fisher_ci(pr, n, k_cov=0, spearman=False)

            if gene == "RBFOX3":
                cov_mat = syp_log2[:, None]
                cov_label = "SYP"
            elif gene == "SYP":
                cov_mat = rbfox3_log2[:, None]
                cov_label = "RBFOX3"
            else:
                cov_mat = np.column_stack([rbfox3_log2, syp_log2])
                cov_label = "RBFOX3,SYP"

            ps_r, ps_p, ps_lo, ps_hi = partial_corr(log2_tpm, psi, cov_mat, spearman=True)
            pp_r, pp_p, pp_lo, pp_hi = partial_corr(log2_tpm, psi, cov_mat, spearman=False)

            scope_rows.append({
                "scope": scope_name,
                "n_tissues": n,
                "gene": gene,
                "mean_tpm": float(np.mean(tpm)),
                "median_tpm": float(np.median(tpm)),
                "spearman_rho": rho,
                "spearman_ci95_low": sp_lo,
                "spearman_ci95_high": sp_hi,
                "spearman_p": sp_p,
                "pearson_r_log2": pr,
                "pearson_ci95_low": pr_lo,
                "pearson_ci95_high": pr_hi,
                "pearson_p_log2": pr_p,
                "partial_covariates": cov_label,
                "partial_spearman_rho": ps_r,
                "partial_spearman_ci95_low": ps_lo,
                "partial_spearman_ci95_high": ps_hi,
                "partial_spearman_p": ps_p,
                "partial_pearson_r": pp_r,
                "partial_pearson_ci95_low": pp_lo,
                "partial_pearson_ci95_high": pp_hi,
                "partial_pearson_p": pp_p,
            })

        sdf = pd.DataFrame(scope_rows)
        sdf["spearman_fdr"] = bh_fdr(sdf["spearman_p"].to_numpy())
        sdf["pearson_fdr"] = bh_fdr(sdf["pearson_p_log2"].to_numpy())
        sdf["partial_spearman_fdr"] = bh_fdr(sdf["partial_spearman_p"].to_numpy())
        sdf["partial_pearson_fdr"] = bh_fdr(sdf["partial_pearson_p"].to_numpy())
        corr_rows.extend(sdf.to_dict(orient="records"))

    corr_df = pd.DataFrame(corr_rows)
    verify_no_nans(corr_df, "gtex_v8_correlations")
    corr_df.to_csv(TABLES_DIR / "gtex_v8_correlations.csv", index=False)

    # Orthogonal cross-check PSI4 vs exon7/exon8 ratio
    ortho_all_sp = st.spearmanr(full_df["PSI4"], full_df["exon7_exon8_ratio"])
    ortho_all_pr = st.pearsonr(full_df["PSI4"], full_df["exon7_exon8_ratio"])
    ortho_br_sp = st.spearmanr(brain_df["PSI4"], brain_df["exon7_exon8_ratio"])
    ortho_br_pr = st.pearsonr(brain_df["PSI4"], brain_df["exon7_exon8_ratio"])

    b13 = corr_df[corr_df["scope"] == "brain_13"].set_index("gene")
    a54 = corr_df[corr_df["scope"] == "all_54"].set_index("gene")

    return {
        "n_tissues": 54,
        "n_brain_regions": 13,
        "psi4_brain_min": float(brain_df["PSI4"].min()),
        "psi4_brain_max": float(brain_df["PSI4"].max()),
        "psi4_brain_median": float(brain_df["PSI4"].median()),
        "psi4_brain_mean": float(brain_df["PSI4"].mean()),
        "psi4_nonbrain_median": float(full_df.loc[~full_df["is_brain"], "PSI4"].median()),
        "psi4_nonbrain_max": float(full_df.loc[~full_df["is_brain"], "PSI4"].max()),
        "psi4_cerebellar_hemisphere": float(brain_df.loc[brain_df["tissueSiteDetailId"] == "Brain_Cerebellar_Hemisphere", "PSI4"].iloc[0]),
        "psi4_cortex": float(brain_df.loc[brain_df["tissueSiteDetailId"] == "Brain_Cortex", "PSI4"].iloc[0]),
        "psi4_hippocampus": float(brain_df.loc[brain_df["tissueSiteDetailId"] == "Brain_Hippocampus", "PSI4"].iloc[0]),
        "orthogonal_exon7_exon8_vs_psi4": {
            "all_54_spearman_rho": float(ortho_all_sp.statistic),
            "all_54_spearman_p": float(ortho_all_sp.pvalue),
            "all_54_pearson_r": float(ortho_all_pr.statistic),
            "all_54_pearson_p": float(ortho_all_pr.pvalue),
            "brain_13_spearman_rho": float(ortho_br_sp.statistic),
            "brain_13_spearman_p": float(ortho_br_sp.pvalue),
            "brain_13_pearson_r": float(ortho_br_pr.statistic),
            "brain_13_pearson_p": float(ortho_br_pr.pvalue),
        },
        "key_brain13_correlations": {
            g: {
                "spearman_rho": float(b13.loc[g, "spearman_rho"]),
                "spearman_p": float(b13.loc[g, "spearman_p"]),
                "spearman_fdr": float(b13.loc[g, "spearman_fdr"]),
                "pearson_r_log2": float(b13.loc[g, "pearson_r_log2"]),
                "pearson_p_log2": float(b13.loc[g, "pearson_p_log2"]),
                "partial_spearman_rho": float(b13.loc[g, "partial_spearman_rho"]),
                "partial_spearman_p": float(b13.loc[g, "partial_spearman_p"]),
                "partial_spearman_fdr": float(b13.loc[g, "partial_spearman_fdr"]),
                "partial_pearson_r": float(b13.loc[g, "partial_pearson_r"]),
                "partial_pearson_p": float(b13.loc[g, "partial_pearson_p"]),
                "partial_pearson_fdr": float(b13.loc[g, "partial_pearson_fdr"]),
            }
            for g in ["SRRM4", "SRRM3", "SRSF11", "RNPS1", "RBFOX1", "RBFOX2", "PTBP1", "HNRNPC", "DRD2", "HTR2A", "HDAC2", "SRPK1", "SRPK2"]
        },
        "key_all54_correlations": {
            g: {
                "spearman_rho": float(a54.loc[g, "spearman_rho"]),
                "spearman_p": float(a54.loc[g, "spearman_p"]),
                "spearman_fdr": float(a54.loc[g, "spearman_fdr"]),
                "partial_spearman_rho": float(a54.loc[g, "partial_spearman_rho"]),
                "partial_spearman_p": float(a54.loc[g, "partial_spearman_p"]),
                "partial_spearman_fdr": float(a54.loc[g, "partial_spearman_fdr"]),
            }
            for g in ["SRRM4", "SRRM3", "SRSF11", "RNPS1", "RBFOX1", "PTBP1", "HNRNPC", "DRD2", "HTR2A"]
        },
    }


# ==============================================================================
# 2. GEO GSE276143 Analysis
# ==============================================================================
def analyze_gse276143() -> dict[str, Any]:
    print("[2/8] Analyzing GEO GSE276143 (CPEB4 me4 minigene MPRA)...")
    gdir = RAW_DIR / "gse276143"
    tier_order = {"GFP": 0, "LOW": 1, "MID": 2, "HIGH": 3}

    frames = []
    for rep in range(1, 7):
        fpath = gdir / f"GSE276143_T0_INCLUSION_TABLE_rep{rep}.tab.gz"
        with gzip.open(fpath, "rt", encoding="utf-8") as fh:
            df_rep = pd.read_csv(fh, sep="\t")
        sub = df_rep[df_rep["EVENT"] == "HsaEX0016976"].copy()
        sub["replicate"] = rep
        frames.append(sub)
    all_df = pd.concat(frames, ignore_index=True)
    all_df["srrm4_tier_order"] = all_df["CONDITION"].map(tier_order)
    all_df["psi_frac"] = all_df["PSI"] / 100.0

    # WT 24-row table
    wt_df = all_df[all_df["TYPE"] == "WT"].sort_values(["srrm4_tier_order", "replicate"]).reset_index(drop=True)
    wt_out = wt_df[[
        "replicate", "CONDITION", "srrm4_tier_order", "VARIANT",
        "PSI", "psi_frac", "INC_CORR", "EXC", "NREADS_CORR", "VAR_LEN", "VAR_SEQ",
    ]].rename(columns={
        "CONDITION": "condition",
        "VARIANT": "variant",
        "PSI": "psi",
        "INC_CORR": "inc_corr",
        "EXC": "exc",
        "NREADS_CORR": "nreads_corr",
        "VAR_LEN": "var_len",
        "VAR_SEQ": "var_seq",
    })
    if len(wt_out) != 24:
        raise RuntimeError(f"Expected 24 WT rows, got {len(wt_out)}")
    verify_no_nans(wt_out, "gse276143_cpeb4_wt_dose")
    wt_out.to_csv(PROC_DIR / "gse276143_cpeb4_wt_dose.csv", index=False)

    # All variants across 6 reps
    wt_by_cond_rep = wt_df.set_index(["CONDITION", "replicate"])["PSI"]
    var_rows: list[dict[str, Any]] = []
    for (variant, cond), grp in all_df.groupby(["VARIANT", "CONDITION"], sort=False):
        grp = grp.sort_values("replicate")
        vals = grp["PSI"].to_numpy(dtype=float)
        reps = grp["replicate"].to_numpy(dtype=int)
        wt_vals = np.array([wt_by_cond_rep[(cond, r)] for r in reps], dtype=float)
        n = len(vals)
        mean_psi = float(np.mean(vals))
        sd_psi = float(np.std(vals, ddof=1))
        sem_psi = float(sd_psi / math.sqrt(n))
        t_crit = float(st.t.ppf(0.975, n - 1))
        ci_lo = mean_psi - t_crit * sem_psi
        ci_hi = mean_psi + t_crit * sem_psi
        wt_mean = float(np.mean(wt_vals))
        delta_psi = mean_psi - wt_mean
        if variant == "CPEB4-HsaEX0016976-WT":
            t_stat, p_val = 0.0, 1.0
        else:
            t_res = st.ttest_rel(vals, wt_vals)
            t_stat = float(t_res.statistic) if np.isfinite(t_res.statistic) else 0.0
            p_val = float(t_res.pvalue) if np.isfinite(t_res.pvalue) else 1.0

        suffix = variant.replace("CPEB4-HsaEX0016976-", "")
        if suffix == "WT":
            mclass, mparam = "WT", "0"
        elif "_" in suffix:
            mclass, mparam = suffix.split("-", 1)[0], suffix.split("-", 1)[1]
        else:
            parts = suffix.split("-", 1)
            mclass, mparam = parts[0], (parts[1] if len(parts) > 1 else "0")

        var_rows.append({
            "variant": variant,
            "type": str(grp["TYPE"].iloc[0]),
            "mutation_class": mclass,
            "mutation_param": mparam,
            "condition": cond,
            "srrm4_tier_order": tier_order[cond],
            "var_len": int(grp["VAR_LEN"].iloc[0]),
            "var_seq": str(grp["VAR_SEQ"].iloc[0]),
            "upint": str(grp["UPINT"].iloc[0]),
            "doint": str(grp["DOINT"].iloc[0]),
            "n_reps": n,
            "mean_psi": mean_psi,
            "sd_psi": sd_psi,
            "sem_psi": sem_psi,
            "ci95_low": ci_lo,
            "ci95_high": ci_hi,
            "wt_mean_psi": wt_mean,
            "delta_psi_vs_wt": delta_psi,
            "paired_t_vs_wt": t_stat,
            "p_val_vs_wt": p_val,
            "mean_nreads_corr": float(grp["NREADS_CORR"].mean()),
        })

    vdf = pd.DataFrame(var_rows).sort_values(["srrm4_tier_order", "type", "variant"]).reset_index(drop=True)
    is_var = vdf["type"] == "VAR"
    vdf["fdr_vs_wt"] = 1.0
    vdf.loc[is_var, "fdr_vs_wt"] = bh_fdr(vdf.loc[is_var, "p_val_vs_wt"].to_numpy())
    verify_no_nans(vdf, "gse276143_cpeb4_variants")
    vdf.to_csv(PROC_DIR / "gse276143_cpeb4_variants.csv", index=False)

    wt_summary = {
        cond: {
            "mean_psi": float(vdf.loc[(vdf["type"] == "WT") & (vdf["condition"] == cond), "mean_psi"].iloc[0]),
            "sd_psi": float(vdf.loc[(vdf["type"] == "WT") & (vdf["condition"] == cond), "sd_psi"].iloc[0]),
            "sem_psi": float(vdf.loc[(vdf["type"] == "WT") & (vdf["condition"] == cond), "sem_psi"].iloc[0]),
        }
        for cond in ["GFP", "LOW", "MID", "HIGH"]
    }
    return {
        "n_replicates": 6,
        "n_unique_variants": int(vdf["variant"].nunique()),
        "n_variant_condition_rows": len(vdf),
        "wt_dose_response": wt_summary,
        "n_sig_variants_fdr_0_05": int((vdf.loc[is_var, "fdr_vs_wt"] < 0.05).sum()),
    }


# ==============================================================================
# 3. NCBI RefSeq & UniProt Cis-Regulatory Architecture
# ==============================================================================
# Published human splice-site position frequency matrices (Shapiro & Senapathy 1987 / Zhang & Marr)
PWM_5SS = [
    {"A": 0.33, "C": 0.36, "G": 0.19, "T": 0.12},  # -3 (exon)
    {"A": 0.61, "C": 0.12, "G": 0.14, "T": 0.13},  # -2
    {"A": 0.10, "C": 0.03, "G": 0.80, "T": 0.07},  # -1
    {"A": 0.001, "C": 0.001, "G": 0.997, "T": 0.001},  # +1 (G)
    {"A": 0.001, "C": 0.001, "G": 0.001, "T": 0.997},  # +2 (T)
    {"A": 0.60, "C": 0.03, "G": 0.34, "T": 0.03},  # +3
    {"A": 0.71, "C": 0.08, "G": 0.12, "T": 0.09},  # +4
    {"A": 0.07, "C": 0.05, "G": 0.81, "T": 0.07},  # +5
    {"A": 0.16, "C": 0.17, "G": 0.20, "T": 0.47},  # +6
]

PWM_3SS = [
    {"A": 0.14, "C": 0.31, "G": 0.12, "T": 0.43},  # -20
    {"A": 0.13, "C": 0.32, "G": 0.11, "T": 0.44},  # -19
    {"A": 0.12, "C": 0.33, "G": 0.11, "T": 0.44},  # -18
    {"A": 0.12, "C": 0.33, "G": 0.10, "T": 0.45},  # -17
    {"A": 0.11, "C": 0.34, "G": 0.10, "T": 0.45},  # -16
    {"A": 0.11, "C": 0.34, "G": 0.09, "T": 0.46},  # -15
    {"A": 0.10, "C": 0.35, "G": 0.09, "T": 0.46},  # -14
    {"A": 0.10, "C": 0.35, "G": 0.08, "T": 0.47},  # -13
    {"A": 0.10, "C": 0.35, "G": 0.07, "T": 0.48},  # -12
    {"A": 0.09, "C": 0.35, "G": 0.07, "T": 0.49},  # -11
    {"A": 0.09, "C": 0.36, "G": 0.06, "T": 0.49},  # -10
    {"A": 0.09, "C": 0.37, "G": 0.06, "T": 0.48},  # -9
    {"A": 0.09, "C": 0.38, "G": 0.07, "T": 0.46},  # -8
    {"A": 0.10, "C": 0.38, "G": 0.07, "T": 0.45},  # -7
    {"A": 0.08, "C": 0.39, "G": 0.06, "T": 0.47},  # -6
    {"A": 0.08, "C": 0.41, "G": 0.07, "T": 0.44},  # -5
    {"A": 0.27, "C": 0.27, "G": 0.23, "T": 0.23},  # -4 (N)
    {"A": 0.04, "C": 0.71, "G": 0.01, "T": 0.24},  # -3 (C/T)
    {"A": 0.997, "C": 0.001, "G": 0.001, "T": 0.001},  # -2 (A)
    {"A": 0.001, "C": 0.001, "G": 0.997, "T": 0.001},  # -1 (G)
    {"A": 0.28, "C": 0.12, "G": 0.50, "T": 0.10},  # +1 (exon)
    {"A": 0.24, "C": 0.15, "G": 0.14, "T": 0.47},  # +2
    {"A": 0.25, "C": 0.24, "G": 0.27, "T": 0.24},  # +3
]


def score_pwm(seq: str, pwm: list[dict[str, float]]) -> dict[str, Any]:
    assert len(seq) == len(pwm), f"Expected len {len(pwm)}, got {len(seq)}"
    log2_odds = sum(math.log2(pwm[i][ch] / 0.25) for i, ch in enumerate(seq))
    raw_sum = sum(pwm[i][ch] for i, ch in enumerate(seq))
    min_sum = sum(min(pos.values()) for pos in pwm)
    max_sum = sum(max(pos.values()) for pos in pwm)
    shapiro_pct = 100.0 * (raw_sum - min_sum) / (max_sum - min_sum)
    return {
        "sequence": seq,
        "log2_odds_bits": round(log2_odds, 4),
        "shapiro_senapathy_pct": round(shapiro_pct, 2),
    }


def gc_pct(s: str) -> float:
    return round(100.0 * (s.count("G") + s.count("C")) / len(s), 2) if s else 0.0


def find_motif_positions(seq: str, motif: str) -> list[int]:
    return [m.start() for m in re.finditer(f"(?={re.escape(motif)})", seq)]


def analyze_refseq_and_uniprot() -> dict[str, Any]:
    print("[3/8] Analyzing RefSeq NC_000005.10 cis-architecture & UniProt features...")
    rdir = RAW_DIR / "refseq_uniprot"
    fa_lines = (rdir / "NC_000005.10_173932440_173945150.fasta").read_text(encoding="utf-8").splitlines()
    seq = "".join(l.strip().upper() for l in fa_lines[1:])
    seq_start = 173932440

    def gsub(g1: int, g2: int) -> str:
        return seq[g1 - seq_start : g2 - seq_start + 1]

    ex3 = gsub(173932450, 173932500)
    int3 = gsub(173932501, 173943025)
    me4 = gsub(173943026, 173943049)
    int4 = gsub(173943050, 173944966)
    ex5 = gsub(173944967, 173945140)

    # Verify splice dinucleotides and microexon sequence
    assert me4 == "CAAGGACATATGGGCGAAGGAGAG", f"Unexpected me4 seq: {me4}"
    assert int3[:2] == "GT" and int3[-2:] == "AG"
    assert int4[:2] == "GT" and int4[-2:] == "AG"

    # Verify translation against UniProt Q17RY0
    q17_json = json.loads((rdir / "uniprot_Q17RY0.json").read_text(encoding="utf-8"))
    q17_seq = q17_json["sequence"]["value"]
    codons = {
        "TTT":"F","TTC":"F","TTA":"L","TTG":"L","CTT":"L","CTC":"L","CTA":"L","CTG":"L",
        "ATT":"I","ATC":"I","ATA":"I","ATG":"M","GTT":"V","GTC":"V","GTA":"V","GTG":"V",
        "TCT":"S","TCC":"S","TCA":"S","TCG":"S","CCT":"P","CCC":"P","CCA":"P","CCG":"P",
        "ACT":"T","ACC":"T","ACA":"T","ACG":"T","GCT":"A","GCC":"A","GCA":"A","GCG":"A",
        "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*","CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
        "AAT":"N","AAC":"N","AAA":"K","AAG":"K","GAT":"D","GAC":"D","GAA":"E","GAG":"E",
        "TGT":"C","TGC":"C","TGA":"*","TGG":"W","CGT":"R","CGC":"R","CGA":"R","CGG":"R",
        "AGT":"S","AGC":"S","AGA":"R","AGG":"R","GGT":"G","GGC":"G","GGA":"G","GGG":"G",
    }
    joined_frame2 = (ex3 + me4 + ex5)[2:]
    translated = "".join(codons.get(joined_frame2[i : i + 3], "X") for i in range(0, len(joined_frame2) - 2, 3))
    assert "RLNYSYPGSDSSLLINARTYGRRRG" in q17_seq and "RLNYSYPGSDSSLLINARTYGRRRG" in translated
    me4_aa_inserted = "ARTYGRRR"  # Q17RY0 pos 420..427 (vs delta-me4 G|GT = G)

    # Upstream SRRM4 bipartite enhancer motifs in [-60..-1] of intron 3
    up60 = int3[-60:]
    up50 = int3[-50:]
    tgc_positions_rel = [idx - 60 for idx in find_motif_positions(up60, "TGC")]
    ppt_y_frac_me4 = round((up50.count("C") + up50.count("T")) / len(up50), 4)
    up50_ex5 = int4[-50:]
    ppt_y_frac_ex5 = round((up50_ex5.count("C") + up50_ex5.count("T")) / len(up50_ex5), 4)
    tgc_ex5_rel = [idx - 60 for idx in find_motif_positions(int4[-60:], "TGC")]

    # hnRNPC continuous TTTTT (>=5T) tracks
    def poly_t_runs(s: str, min_len: int = 5) -> list[dict[str, Any]]:
        return [
            {"start_idx0": m.start(), "end_idx0": m.end(), "length": m.end() - m.start(), "seq": m.group(0)}
            for m in re.finditer(rf"T{{{min_len},}}", s)
        ]

    int3_runs = poly_t_runs(int3, 5)
    int4_runs = poly_t_runs(int4, 5)
    win_up300 = int3[-300:]
    win_dn300 = int4[:300]
    up300_runs = [
        {"rel_start": r["start_idx0"] - 300, "rel_end": r["end_idx0"] - 300, "length": r["length"]}
        for r in poly_t_runs(win_up300, 5)
    ]
    dn300_runs = [
        {"rel_start": r["start_idx0"] + 1, "rel_end": r["end_idx0"], "length": r["length"]}
        for r in poly_t_runs(win_dn300, 5)
    ]

    # RBFOX (T)GCATG motifs in +/-300 nt window & full introns
    rbfox_up300_tgcatg = [i - 300 for i in find_motif_positions(win_up300, "TGCATG")]
    rbfox_up300_gcatg = [i - 300 for i in find_motif_positions(win_up300, "GCATG")]
    rbfox_dn300_tgcatg = [i + 1 for i in find_motif_positions(win_dn300, "TGCATG")]
    rbfox_dn300_gcatg = [i + 1 for i in find_motif_positions(win_dn300, "GCATG")]

    # Splice site PWM scores: me4 vs Exon 5 (and Exon 3 5'ss)
    me4_3ss = score_pwm(gsub(173943026 - 20, 173943026 + 2), PWM_3SS)
    me4_5ss = score_pwm(gsub(173943049 - 2, 173943049 + 6), PWM_5SS)
    ex5_3ss = score_pwm(gsub(173944967 - 20, 173944967 + 2), PWM_3SS)
    ex5_5ss = score_pwm(gsub(173945140 - 2, 173945140 + 6), PWM_5SS)
    ex3_5ss = score_pwm(gsub(173932500 - 2, 173932500 + 6), PWM_5SS)

    # Sliding GC% across [-500..end of exon 5]
    region_seq = gsub(173943026 - 500, 173945140)
    region_start = 173943026 - 500
    sliding_gc = []
    for pos in range(0, len(region_seq) - 50 + 1, 10):
        w = region_seq[pos : pos + 50]
        g_mid = region_start + pos + 25
        sliding_gc.append({
            "genomic_center": g_mid,
            "rel_to_me4_start": g_mid - 173943026,
            "gc_pct": gc_pct(w),
        })

    cis_arch = {
        "refseq_accession": "NC_000005.10",
        "genome_build": "GRCh38.p14",
        "strand": "+",
        "coordinates": {
            "exon_3": {"start": 173932450, "end": 173932500, "length_nt": len(ex3), "gc_pct": gc_pct(ex3)},
            "intron_3": {"start": 173932501, "end": 173943025, "length_nt": len(int3), "gc_pct": gc_pct(int3)},
            "microexon_4": {"start": 173943026, "end": 173943049, "length_nt": len(me4), "gc_pct": gc_pct(me4)},
            "intron_4": {"start": 173943050, "end": 173944966, "length_nt": len(int4), "gc_pct": gc_pct(int4)},
            "exon_5": {"start": 173944967, "end": 173945140, "length_nt": len(ex5), "gc_pct": gc_pct(ex5)},
        },
        "microexon_4_sequence": {
            "nucleotide_seq": me4,
            "reading_frame_phase": 1,
            "spliced_junction_context": f"{ex3[-6:]}|{me4}|{ex5[:6]}",
            "inserted_peptide_vs_delta_me4": me4_aa_inserted,
            "q17ry0_residues_420_428": "ARTYGRRRG",
            "n_arg_residues": me4_aa_inserted.count("R"),
            "n_tyr_residues": me4_aa_inserted.count("Y"),
            "net_charge_ph7_4": 4,
        },
        "srrm4_bipartite_enhancer": {
            "upstream_60nt_intron3": up60,
            "tgc_positions_rel_me4_3ss": tgc_positions_rel,
            "has_proximal_tgc_in_minus10_to_minus1": any(-10 <= p <= -1 for p in tgc_positions_rel),
            "ppt_50nt_pyrimidine_frac_me4": ppt_y_frac_me4,
            "ppt_50nt_pyrimidine_frac_ex5": ppt_y_frac_ex5,
            "ex5_tgc_positions_rel_3ss": tgc_ex5_rel,
        },
        "hnrnpc_poly_t_tracks": {
            "intron3_total_polyT_runs_ge5": len(int3_runs),
            "intron3_overlapping_TTTTT_5mers": len(find_motif_positions(int3, "TTTTT")),
            "intron3_max_polyT_len": max((r["length"] for r in int3_runs), default=0),
            "intron4_total_polyT_runs_ge5": len(int4_runs),
            "intron4_overlapping_TTTTT_5mers": len(find_motif_positions(int4, "TTTTT")),
            "intron4_max_polyT_len": max((r["length"] for r in int4_runs), default=0),
            "upstream_300nt_polyT_runs_ge5": up300_runs,
            "downstream_300nt_polyT_runs_ge5": dn300_runs,
            "upstream_50nt_polyT_runs_ge5": [r for r in up300_runs if r["rel_end"] > -50],
        },
        "rbfox_motifs": {
            "upstream_300nt_TGCATG_rel": rbfox_up300_tgcatg,
            "upstream_300nt_GCATG_rel": rbfox_up300_gcatg,
            "downstream_300nt_TGCATG_rel": rbfox_dn300_tgcatg,
            "downstream_300nt_GCATG_rel": rbfox_dn300_gcatg,
            "full_intron3_TGCATG_count": len(find_motif_positions(int3, "TGCATG")),
            "full_intron3_GCATG_count": len(find_motif_positions(int3, "GCATG")),
            "full_intron4_TGCATG_count": len(find_motif_positions(int4, "TGCATG")),
            "full_intron4_GCATG_count": len(find_motif_positions(int4, "GCATG")),
        },
        "splice_site_pwm_scores": {
            "me4_3ss": me4_3ss,
            "me4_5ss": me4_5ss,
            "exon5_3ss": ex5_3ss,
            "exon5_5ss": ex5_5ss,
            "exon3_5ss": ex3_5ss,
        },
        "sliding_gc_50nt_step10": sliding_gc,
    }
    (PROC_DIR / "cpeb4_cis_architecture.json").write_text(json.dumps(cis_arch, indent=2) + "\n", encoding="utf-8")

    # UniProt features table across the 7 curated proteins
    up_rows = []
    for acc in ["Q17RY0", "A7MD48", "Q9NWB1", "P14416", "P28223", "Q9UD71", "Q92769"]:
        data = json.loads((rdir / f"uniprot_{acc}.json").read_text(encoding="utf-8"))
        gene = data.get("genes", [{}])[0].get("geneName", {}).get("value", acc)
        pname = data.get("proteinDescription", {}).get("recommendedName", {}).get("fullName", {}).get("value", "")
        seq_val = data.get("sequence", {}).get("value", "")
        feats = data.get("features", [])

        iso_count = 1
        for c in data.get("comments", []):
            if c.get("commentType") == "ALTERNATIVE PRODUCTS":
                iso_count = len(c.get("isoforms", [])) or 1

        disordered_spans = [
            (f["location"]["start"]["value"], f["location"]["end"]["value"])
            for f in feats
            if f.get("type") == "Region" and "Disordered" in f.get("description", "")
        ]
        disordered_aa = sum(e - s + 1 for s, e in disordered_spans)
        domains = [f for f in feats if f.get("type") == "Domain"]
        mod_res = [f for f in feats if f.get("type") == "Modified residue"]
        p_ser = sum(1 for f in mod_res if "Phosphoserine" in f.get("description", ""))
        p_thr = sum(1 for f in mod_res if "Phosphothreonine" in f.get("description", ""))
        p_tyr = sum(1 for f in mod_res if "Phosphotyrosine" in f.get("description", ""))
        other_mod = len(mod_res) - p_ser - p_thr - p_tyr
        glyc = sum(1 for f in feats if f.get("type") == "Glycosylation")
        disulf = sum(1 for f in feats if f.get("type") == "Disulfide bond")

        if acc == "Q17RY0":
            hclust_his_dense = seq_val[211:263].count("H")  # residues 212..263
            hclust_his_idr = seq_val[:403].count("H")       # N-term IDR 1..403
            me4_len_aa = 8
        else:
            hclust_his_dense = 0
            hclust_his_idr = 0
            me4_len_aa = 0

        up_rows.append({
            "uniprot_id": acc,
            "gene_symbol": gene,
            "protein_name": pname,
            "sequence_length_aa": len(seq_val),
            "isoform_count": iso_count,
            "total_his_count": seq_val.count("H"),
            "hclust_dense_212_263_his_count": hclust_his_dense,
            "nterm_idr_his_count": hclust_his_idr,
            "me4_length_aa": me4_len_aa,
            "disordered_regions_count": len(disordered_spans),
            "disordered_total_aa": disordered_aa,
            "domain_count": len(domains),
            "ptm_modified_residue_total": len(mod_res),
            "ptm_phosphoserine": p_ser,
            "ptm_phosphothreonine": p_thr,
            "ptm_phosphotyrosine": p_tyr,
            "ptm_other_modified_residue": other_mod,
            "ptm_glycosylation": glyc,
            "ptm_disulfide_bond": disulf,
            "ptm_all_annotated_total": len(mod_res) + glyc + disulf,
        })
    up_df = pd.DataFrame(up_rows)
    verify_no_nans(up_df, "uniprot_protein_features")
    up_df.to_csv(PROC_DIR / "uniprot_protein_features.csv", index=False)

    return {
        "intron3_len_nt": len(int3),
        "me4_len_nt": len(me4),
        "me4_seq": me4,
        "me4_aa": me4_aa_inserted,
        "intron4_len_nt": len(int4),
        "exon5_len_nt": len(ex5),
        "tgc_positions_rel_me4_3ss": tgc_positions_rel,
        "ppt_50nt_y_frac_me4": ppt_y_frac_me4,
        "ppt_50nt_y_frac_ex5": ppt_y_frac_ex5,
        "intron3_polyT_runs_ge5": len(int3_runs),
        "intron4_polyT_runs_ge5": len(int4_runs),
        "me4_3ss_bits": me4_3ss["log2_odds_bits"],
        "exon5_3ss_bits": ex5_3ss["log2_odds_bits"],
        "me4_5ss_bits": me4_5ss["log2_odds_bits"],
        "exon5_5ss_bits": ex5_5ss["log2_odds_bits"],
        "cpeb4_q17ry0_len_aa": len(q17_seq),
        "cpeb4_hclust_dense_his": int(up_df.loc[up_df["uniprot_id"] == "Q17RY0", "hclust_dense_212_263_his_count"].iloc[0]),
        "cpeb4_ptm_total": int(up_df.loc[up_df["uniprot_id"] == "Q17RY0", "ptm_all_annotated_total"].iloc[0]),
    }


# ==============================================================================
# 4. ChEMBL v35 Antipsychotic Pharmacology
# ==============================================================================
def analyze_chembl_v35() -> dict[str, Any]:
    print("[4/8] Analyzing ChEMBL v35 experimental human Ki...")
    cdir = RAW_DIR / "chembl_v35"
    status = json.loads((cdir / "chembl_status.json").read_text(encoding="utf-8"))
    target_map = {
        "CHEMBL217": "DRD2",
        "CHEMBL224": "HTR2A",
        "CHEMBL2056": "DRD1",
        "CHEMBL214": "HTR1A",
        "CHEMBL229": "ADRA1A",
        "CHEMBL231": "HRH1",
        "CHEMBL216": "CHRM1",
    }

    records = []
    for p in sorted(cdir.glob("chembl_ki_*.json")):
        obj = json.loads(p.read_text(encoding="utf-8"))
        drug = obj["drug_name"]
        mol_id = obj["molecule_chembl_id"]
        for a in obj["activities"]:
            if (
                a.get("target_organism") == "Homo sapiens"
                and a.get("standard_type") == "Ki"
                and a.get("standard_units") == "nM"
                and a.get("standard_relation") == "="
                and a.get("standard_value") is not None
            ):
                val = float(a["standard_value"])
                if val > 0:
                    tid = a["target_chembl_id"]
                    records.append({
                        "drug_name": drug,
                        "molecule_chembl_id": mol_id,
                        "target_symbol": target_map[tid],
                        "target_chembl_id": tid,
                        "ki_nm": val,
                        "pki": 9.0 - math.log10(val),
                    })

    raw_act = pd.DataFrame(records)
    agg_rows = []
    for (drug, mol_id, tsym, tid), grp in raw_act.groupby(
        ["drug_name", "molecule_chembl_id", "target_symbol", "target_chembl_id"], sort=True
    ):
        vals = grp["ki_nm"].to_numpy(dtype=float)
        pkis = grp["pki"].to_numpy(dtype=float)
        q1 = float(np.percentile(vals, 25))
        med = float(np.median(vals))
        q3 = float(np.percentile(vals, 75))
        agg_rows.append({
            "drug_name": drug,
            "drug_class": CHEMBL_DRUG_CLASSES[drug],
            "molecule_chembl_id": mol_id,
            "target_symbol": tsym,
            "target_chembl_id": tid,
            "n_assays": int(len(vals)),
            "median_ki_nm": med,
            "q1_ki_nm": q1,
            "q3_ki_nm": q3,
            "iqr_ki_nm": q3 - q1,
            "min_ki_nm": float(np.min(vals)),
            "max_ki_nm": float(np.max(vals)),
            "median_pki": 9.0 - math.log10(med),
            "mean_pki": float(np.mean(pkis)),
        })
    cdf = pd.DataFrame(agg_rows)

    # Compute per-drug HTR2A/DRD2 selectivity ratios
    drd2_map = cdf[cdf["target_symbol"] == "DRD2"].set_index("drug_name")["median_ki_nm"].to_dict()
    htr2a_map = cdf[cdf["target_symbol"] == "HTR2A"].set_index("drug_name")["median_ki_nm"].to_dict()
    cdf["drd2_median_ki_nm"] = cdf["drug_name"].map(drd2_map)
    cdf["htr2a_median_ki_nm"] = cdf["drug_name"].map(htr2a_map)
    cdf["ki_ratio_htr2a_over_drd2"] = cdf["htr2a_median_ki_nm"] / cdf["drd2_median_ki_nm"]
    cdf["affinity_ratio_drd2_over_htr2a"] = cdf["drd2_median_ki_nm"] / cdf["htr2a_median_ki_nm"]
    cdf["delta_pki_htr2a_minus_drd2"] = np.log10(cdf["ki_ratio_htr2a_over_drd2"]) * -1.0

    cdf = cdf.sort_values(["drug_name", "target_symbol"]).reset_index(drop=True)
    verify_no_nans(cdf, "chembl_antipsychotic_ki")
    cdf.to_csv(PROC_DIR / "chembl_antipsychotic_ki.csv", index=False)

    selectivity_summary = {
        d: {
            "drug_class": CHEMBL_DRUG_CLASSES[d],
            "drd2_ki_nm": float(drd2_map[d]),
            "htr2a_ki_nm": float(htr2a_map[d]),
            "ki_ratio_htr2a_over_drd2": float(htr2a_map[d] / drd2_map[d]),
            "affinity_ratio_drd2_over_htr2a": float(drd2_map[d] / htr2a_map[d]),
        }
        for d in sorted(drd2_map)
    }
    return {
        "chembl_db_version": status.get("chembl_db_version", "unknown"),
        "total_ki_assay_records": int(len(raw_act)),
        "observed_drug_target_pairs": int(len(cdf)),
        "selectivity_by_drug": selectivity_summary,
    }


# ==============================================================================
# 5. STRING v12 Network Topology
# ==============================================================================
def analyze_string_v12() -> dict[str, Any]:
    print("[5/8] Analyzing STRING v12 27-node human network...")
    sdir = RAW_DIR / "string_v12"
    ver = json.loads((sdir / "string_version.json").read_text(encoding="utf-8"))
    edges_raw = json.loads((sdir / "string_v12_network_27nodes.json").read_text(encoding="utf-8"))

    G = nx.Graph()
    G.add_nodes_from(STRING_NODES_27)

    seen_pairs = set()
    edge_rows = []
    for e in edges_raw:
        u = e["preferredName_A"]
        v = e["preferredName_B"]
        if u not in G or v not in G or u == v:
            continue
        pair = tuple(sorted((u, v)))
        if pair in seen_pairs:
            continue
        seen_pairs.add(pair)
        score = float(e["score"])
        weight = -math.log(score)
        G.add_edge(u, v, weight=weight, score=score)
        edge_rows.append({
            "protein_a": pair[0],
            "protein_b": pair[1],
            "combined_score": score,
            "neglog_weight": weight,
            "nscore": float(e.get("nscore", 0.0)),
            "fscore": float(e.get("fscore", 0.0)),
            "pscore": float(e.get("pscore", 0.0)),
            "ascore": float(e.get("ascore", 0.0)),
            "escore": float(e.get("escore", 0.0)),
            "dscore": float(e.get("dscore", 0.0)),
            "tscore": float(e.get("tscore", 0.0)),
        })

    edf = pd.DataFrame(edge_rows).sort_values("combined_score", ascending=False).reset_index(drop=True)
    verify_no_nans(edf, "string_network_edges")
    edf.to_csv(PROC_DIR / "string_network_edges.csv", index=False)

    # Shortest paths from DRD2 and HTR2A to downstream targets
    sources = ["DRD2", "HTR2A"]
    targets = ["SRRM4", "SRSF11", "RNPS1", "RBFOX1", "HDAC2", "POLR2A"]
    path_rows = []
    for src in sources:
        for tgt in targets:
            if nx.has_path(G, src, tgt):
                p = nx.shortest_path(G, src, tgt, weight="weight")
                dist = float(nx.shortest_path_length(G, src, tgt, weight="weight"))
                path_rows.append({
                    "source": src,
                    "target": tgt,
                    "reachable": True,
                    "hop_count": len(p) - 1,
                    "total_neglog_weight": dist,
                    "path_product_confidence": math.exp(-dist),
                    "shortest_path_nodes": " -> ".join(p),
                })
            else:
                path_rows.append({
                    "source": src,
                    "target": tgt,
                    "reachable": False,
                    "hop_count": -1,
                    "total_neglog_weight": -1.0,
                    "path_product_confidence": 0.0,
                    "shortest_path_nodes": "UNREACHABLE",
                })
    pdf = pd.DataFrame(path_rows)
    verify_no_nans(pdf, "string_network_paths")
    pdf.to_csv(PROC_DIR / "string_network_paths.csv", index=False)

    # Node centrality
    deg = dict(G.degree())
    wdeg = dict(G.degree(weight="score"))
    bet_unw = nx.betweenness_centrality(G, normalized=True)
    bet_w = nx.betweenness_centrality(G, weight="weight", normalized=True)
    closeness = nx.closeness_centrality(G, distance="weight")
    cent_rows = [
        {
            "node": n,
            "degree": int(deg[n]),
            "weighted_degree_sum_score": float(wdeg[n]),
            "betweenness_unweighted": float(bet_unw[n]),
            "betweenness_weighted": float(bet_w[n]),
            "closeness_weighted": float(closeness[n]),
        }
        for n in STRING_NODES_27
    ]
    cent_df = pd.DataFrame(cent_rows).sort_values("betweenness_weighted", ascending=False).reset_index(drop=True)
    verify_no_nans(cent_df, "string_network_centrality")
    cent_df.to_csv(TABLES_DIR / "string_network_centrality.csv", index=False)

    return {
        "string_version": ver[0].get("string_version", "12.0") if isinstance(ver, list) else str(ver),
        "n_nodes": G.number_of_nodes(),
        "n_connected_nodes": sum(1 for _, d in G.degree() if d > 0),
        "n_edges": G.number_of_edges(),
        "isolated_nodes": [n for n, d in G.degree() if d == 0],
        "top_5_betweenness_nodes": cent_df.head(5)[["node", "degree", "betweenness_weighted"]].to_dict(orient="records"),
        "shortest_paths": pdf.to_dict(orient="records"),
    }


# ==============================================================================
# Shared Transcriptomic Normalization, Covariate-Adjusted OLS, & Meta Helpers
# ==============================================================================
def normalize_log2_cpm(counts_df: pd.DataFrame) -> pd.DataFrame:
    lib_sizes = counts_df.sum(axis=0).astype(float)
    cpm = counts_df.div(lib_sizes, axis=1) * 1e6
    return np.log2(cpm + 1.0)


def compute_module_matrix(expr_log2: pd.DataFrame) -> pd.DataFrame:
    """Compute sample-level composite z-scores for the 3 biological modules."""
    mod_rows = {}
    for mod_name, gene_list in MODULES.items():
        present = [g for g in gene_list if g in expr_log2.index]
        sub = expr_log2.loc[present]
        # Z-score each gene across all samples in cohort
        stds = sub.std(axis=1, ddof=1).replace(0.0, np.nan)
        z_mat = sub.sub(sub.mean(axis=1), axis=0).div(stds, axis=0).dropna(how="all")
        mod_rows[mod_name] = z_mat.mean(axis=0)
    return pd.DataFrame(mod_rows).T


def run_ols_contrast(
    expr_mat: pd.DataFrame,
    meta: pd.DataFrame,
    group_col: str,
    ref_group: str,
    target_group: str,
    covariates_formula: str,
    cluster_col: str | None = None,
) -> pd.DataFrame:
    """
    Fit covariate-adjusted OLS (optionally clustered) for target_group vs ref_group
    across all rows (genes + modules) in expr_mat.
    """
    sub_samples = meta.index.tolist()
    n1 = int((meta[group_col] == target_group).sum())
    n2 = int((meta[group_col] == ref_group).sum())

    rhs = f"C({group_col}, Treatment(reference='{ref_group}'))"
    if covariates_formula:
        rhs = f"{rhs} + {covariates_formula}"
    term_name = f"C({group_col}, Treatment(reference='{ref_group}'))[T.{target_group}]"

    rows = []
    for feature in expr_mat.index:
        d = meta.copy()
        d["y"] = expr_mat.loc[feature, sub_samples].to_numpy(dtype=float)
        if np.std(d["y"]) < 1e-12:
            rows.append({
                "feature": feature,
                "n_target": n1,
                "n_ref": n2,
                "beta_log2fc": 0.0,
                "se": 0.0,
                "t_stat": 0.0,
                "p_val": 1.0,
                "df_resid": float(len(d) - 2),
                "hedges_g": 0.0,
                "var_g": 1.0 / n1 + 1.0 / n2,
                "se_g": math.sqrt(1.0 / n1 + 1.0 / n2),
                "g_ci95_low": -Z_95 * math.sqrt(1.0 / n1 + 1.0 / n2),
                "g_ci95_high": Z_95 * math.sqrt(1.0 / n1 + 1.0 / n2),
            })
            continue
        mod = smf.ols(f"y ~ {rhs}", data=d)
        if cluster_col is not None:
            fit = mod.fit(cov_type="cluster", cov_kwds={"groups": d[cluster_col]})
        else:
            fit = mod.fit()
        beta = float(fit.params[term_name])
        se = float(fit.bse[term_name])
        t_val = float(fit.tvalues[term_name])
        p_val = float(fit.pvalues[term_name])
        df_res = float(fit.df_resid)
        sigma = float(math.sqrt(fit.mse_resid)) if fit.mse_resid > 0 else 1e-9

        # Covariate-adjusted Hedges' g preserving exact Wald/cluster SE ratio
        d_adj = beta / sigma
        se_d_adj = se / sigma
        j_corr = 1.0 - 3.0 / max(1.0, 4.0 * df_res - 1.0)
        g = d_adj * j_corr
        var_g = (se_d_adj ** 2 + (d_adj ** 2) / (2.0 * (n1 + n2))) * (j_corr ** 2)
        se_g = math.sqrt(max(1e-12, var_g))
        rows.append({
            "feature": feature,
            "n_target": n1,
            "n_ref": n2,
            "beta_log2fc": beta,
            "se": se,
            "t_stat": t_val,
            "p_val": p_val,
            "df_resid": df_res,
            "hedges_g": g,
            "var_g": var_g,
            "se_g": se_g,
            "g_ci95_low": g - Z_95 * se_g,
            "g_ci95_high": g + Z_95 * se_g,
        })
    res_df = pd.DataFrame(rows)
    res_df["is_module"] = res_df["feature"].str.startswith("MODULE_")
    # Compute BH-FDR separately across individual target genes and across the 3 modules
    res_df["fdr"] = 1.0
    gene_mask = ~res_df["is_module"]
    mod_mask = res_df["is_module"]
    if gene_mask.any():
        res_df.loc[gene_mask, "fdr"] = bh_fdr(res_df.loc[gene_mask, "p_val"].to_numpy())
    if mod_mask.any():
        res_df.loc[mod_mask, "fdr"] = bh_fdr(res_df.loc[mod_mask, "p_val"].to_numpy())
    return res_df


def parse_series_matrix_meta(path: Path) -> pd.DataFrame:
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as fh:
        lines = fh.read().splitlines()
    titles: list[str] = []
    acc: list[str] = []
    char_rows: list[list[str]] = []
    for l in lines:
        if l.startswith("!Sample_title"):
            titles = [c.strip().strip('"') for c in l.split("\t")[1:]]
        elif l.startswith("!Sample_geo_accession"):
            acc = [c.strip().strip('"') for c in l.split("\t")[1:]]
        elif l.startswith("!Sample_characteristics_ch1"):
            char_rows.append([c.strip().strip('"') for c in l.split("\t")[1:]])
    records = []
    for j in range(len(titles)):
        d: dict[str, Any] = {"title": titles[j], "geo_accession": acc[j] if j < len(acc) else ""}
        for cr in char_rows:
            if j < len(cr) and ":" in cr[j]:
                k, v = cr[j].split(":", 1)
                d[k.strip()] = v.strip()
        records.append(d)
    return pd.DataFrame(records)


# ==============================================================================
# 6. GEO GSE138082 Analysis (Human Hippocampal Subfields)
# ==============================================================================
def analyze_gse138082() -> tuple[pd.DataFrame, dict[str, Any]]:
    print("[6/8] Analyzing GEO GSE138082 (n=78 human hippocampal subfields)...")
    gdir = RAW_DIR / "gse138082"
    meta = parse_series_matrix_meta(gdir / "GSE138082_series_matrix.txt.gz")
    if len(meta) != 78:
        raise RuntimeError(f"Expected 78 samples in GSE138082, got {len(meta)}")

    meta["age"] = meta["age"].astype(float)
    meta["pmi"] = meta["pmi"].astype(float)
    meta["rin"] = meta["rin"].astype(float)
    meta["sex"] = meta["gender"]
    meta["subfield"] = meta["hippocampal_subfield"]

    def map_grp(row: pd.Series) -> str:
        if row["diagnosis"] == "control":
            return "CTL"
        return "SCZ_ON" if row["drug"] == "ON" else "SCZ_OFF"

    meta["group"] = meta.apply(map_grp, axis=1)
    meta = meta.set_index("title")

    with gzip.open(gdir / "GSE138082_Subfields_Counts.txt.gz", "rt", encoding="utf-8") as fh:
        counts = pd.read_csv(fh, sep="\t", index_col=0)
    counts = counts[meta.index]  # exact sample alignment
    log2_cpm = normalize_log2_cpm(counts)

    present_genes = [g for g in PATHWAY_GENES_37 if g in log2_cpm.index]
    mod_df = compute_module_matrix(log2_cpm)
    panel_mat = pd.concat([log2_cpm.loc[present_genes], mod_df], axis=0)

    c1 = run_ols_contrast(
        panel_mat, meta,
        group_col="group", ref_group="CTL", target_group="SCZ_OFF",
        covariates_formula="C(subfield) + age + C(sex) + pmi + rin",
        cluster_col="original_id",
    )
    c1["contrast"] = "SCZ_OFF_vs_CTL"
    c2 = run_ols_contrast(
        panel_mat, meta,
        group_col="group", ref_group="SCZ_OFF", target_group="SCZ_ON",
        covariates_formula="C(subfield) + age + C(sex) + pmi + rin",
        cluster_col="original_id",
    )
    c2["contrast"] = "SCZ_ON_vs_SCZ_OFF"

    out_df = pd.concat([c1, c2], ignore_index=True)
    out_df["cohort"] = "GSE138082"
    verify_no_nans(out_df, "gse138082_differential")
    out_df.to_csv(PROC_DIR / "gse138082_differential.csv", index=False)

    summary = {
        "n_samples": 78,
        "n_unique_donors": int(meta["original_id"].nunique()),
        "group_counts": meta["group"].value_counts().to_dict(),
        "subfield_counts": meta["subfield"].value_counts().to_dict(),
        "n_genes_present": len(present_genes),
        "covariates": ["subfield", "age", "sex", "pmi", "rin"],
        "cluster_var": "original_id",
    }
    return out_df, summary


# ==============================================================================
# 7. GEO GSE174407 Analysis (Human Frontal Cortex NeuN+ Neurons)
# ==============================================================================
def analyze_gse174407() -> tuple[pd.DataFrame, dict[str, Any]]:
    print("[7/8] Analyzing GEO GSE174407 (58 donors, 116 NeuN+_RNA files)...")
    gdir = RAW_DIR / "gse174407"
    hgnc_path = RAW_DIR / "hgnc" / "hgnc_complete_set.txt"
    hgnc = pd.read_csv(hgnc_path, sep="\t", usecols=["symbol", "ensembl_gene_id", "status"], low_memory=False)
    hgnc = hgnc.dropna(subset=["ensembl_gene_id", "symbol"])
    ens_to_sym = hgnc.drop_duplicates("ensembl_gene_id").set_index("ensembl_gene_id")["symbol"].to_dict()

    sm_meta = parse_series_matrix_meta(gdir / "GSE174407_series_matrix.txt.gz")
    sm_rna = sm_meta[sm_meta["title"].str.contains(r"NeuN\+_RNA", regex=True)].copy()
    if len(sm_rna) != 116:
        raise RuntimeError(f"Expected 116 NeuN+_RNA rows in GSE174407 metadata, got {len(sm_rna)}")

    sm_rna["donor_id"] = sm_rna["title"].str.replace(r"_NeuN\+_RNA_R[12]$", "", regex=True)
    sm_rna["age_num"] = sm_rna["age"].str.extract(r"(\d+(?:\.\d+)?)")[0].astype(float)

    def map_g174(row: pd.Series) -> str:
        if row["disease state"] == "Control":
            return "CTL"
        trt = str(row.get("treatment", "")).lower()
        return "SCZ_untreated" if "untreated" in trt else "SCZ_treated"

    sm_rna["group"] = sm_rna.apply(map_g174, axis=1)
    donor_meta = sm_rna.groupby("donor_id", sort=True).agg(
        group=("group", "first"),
        age=("age_num", "first"),
        disease_state=("disease state", "first"),
    )
    if len(donor_meta) != 58:
        raise RuntimeError(f"Expected 58 unique donors in GSE174407, got {len(donor_meta)}")

    # Merge R1 + R2 count files per donor
    rna_files = sorted((gdir / "rna_counts").glob("*_NeuN+_RNA_*.txt.gz"))
    if len(rna_files) != 116:
        raise RuntimeError(f"Expected 116 count files in {gdir / 'rna_counts'}, got {len(rna_files)}")

    donor_counts: dict[str, np.ndarray] = {}
    gene_ids: list[str] | None = None
    for fpath in rna_files:
        # Filename: GSM5297346_SCZ_1_untreated_NeuN+_RNA_R1.txt.gz
        fname = fpath.name
        m = re.match(r"GSM\d+_(.+)_NeuN\+_RNA_R[12]\.txt\.gz$", fname)
        if not m:
            raise RuntimeError(f"Unexpected GSE174407 filename: {fname}")
        donor = m.group(1)
        with gzip.open(fpath, "rt", encoding="utf-8") as fh:
            df_c = pd.read_csv(fh, sep="\t", comment="#")
        if gene_ids is None:
            gene_ids = df_c["Geneid"].astype(str).tolist()
        vec = df_c.iloc[:, -1].to_numpy(dtype=np.int64)
        if donor in donor_counts:
            donor_counts[donor] += vec
        else:
            donor_counts[donor] = vec.copy()

    counts_mat = pd.DataFrame(donor_counts, index=gene_ids)[donor_meta.index]
    symbols = [ens_to_sym.get(g, g) for g in counts_mat.index]
    counts_out = counts_mat.copy()
    counts_out.insert(0, "gene_symbol", symbols)
    counts_out.index.name = "ensembl_gene_id"
    counts_out.to_csv(PROC_DIR / "gse174407_neun_donor_counts.csv.gz", compression="gzip")

    # Aggregate counts by HGNC symbol for normalization & pathway matrix
    counts_sym = counts_mat.copy()
    counts_sym["gene_symbol"] = symbols
    counts_sym = counts_sym.groupby("gene_symbol", sort=False).sum()
    log2_cpm = normalize_log2_cpm(counts_sym)

    present_genes = [g for g in PATHWAY_GENES_37 if g in log2_cpm.index]
    mod_df = compute_module_matrix(log2_cpm)
    panel_mat = pd.concat([log2_cpm.loc[present_genes], mod_df], axis=0)

    c1 = run_ols_contrast(
        panel_mat, donor_meta,
        group_col="group", ref_group="CTL", target_group="SCZ_untreated",
        covariates_formula="age",
    )
    c1["contrast"] = "SCZ_untreated_vs_CTL"
    c2 = run_ols_contrast(
        panel_mat, donor_meta,
        group_col="group", ref_group="SCZ_untreated", target_group="SCZ_treated",
        covariates_formula="age",
    )
    c2["contrast"] = "SCZ_treated_vs_SCZ_untreated"

    out_df = pd.concat([c1, c2], ignore_index=True)
    out_df["cohort"] = "GSE174407"
    verify_no_nans(out_df, "gse174407_differential")
    out_df.to_csv(PROC_DIR / "gse174407_differential.csv", index=False)

    # Sensitivity check: infer biological sex from XIST vs RPS4Y1/DDX3Y in NeuN+ RNA-seq
    sens_sex_inferred = False
    if "XIST" in log2_cpm.index and "RPS4Y1" in log2_cpm.index:
        sens_sex_inferred = True
        donor_meta_sens = donor_meta.copy()
        donor_meta_sens["inferred_sex"] = np.where(
            log2_cpm.loc["XIST", donor_meta.index] > log2_cpm.loc["RPS4Y1", donor_meta.index], "F", "M"
        )
        sex_counts = donor_meta_sens["inferred_sex"].value_counts().to_dict()
    else:
        sex_counts = {}

    summary = {
        "n_rna_files": 116,
        "n_donors": 58,
        "group_counts": donor_meta["group"].value_counts().to_dict(),
        "n_genes_present": len(present_genes),
        "covariates_available_in_geo": ["age"],
        "covariates_absent_in_geo": ["sex", "pmi"],
        "inferred_sex_distribution_sensitivity": sex_counts if sens_sex_inferred else {},
    }
    return out_df, summary


# ==============================================================================
# 8. Cross-Species Drug Perturbation Cohorts & Meta-Analysis
# ==============================================================================
def analyze_gse163161() -> tuple[pd.DataFrame, dict[str, Any]]:
    print("[8a/8] Analyzing GEO GSE163161 (human iPSC Ngn2 neurons: 6 clozapine vs 4 control)...")
    gdir = RAW_DIR / "gse163161"
    with gzip.open(gdir / "GSE163161_Processed_data.csv.gz", "rt", encoding="utf-8") as fh:
        df = pd.read_csv(fh, index_col=0)
    df = df.groupby(level=0, sort=False).sum()
    # Scale columns to TPM (1e6) then log2(TPM+1)
    tpm = df.div(df.sum(axis=0), axis=1) * 1e6
    log2_expr = np.log2(tpm + 1.0)

    meta = pd.DataFrame(index=log2_expr.columns)
    meta["treatment"] = np.where(meta.index.str.lower().str.startswith("cloz"), "CLOZAPINE", "CONTROL")
    if int((meta["treatment"] == "CLOZAPINE").sum()) != 6 or int((meta["treatment"] == "CONTROL").sum()) != 4:
        raise RuntimeError(f"Unexpected GSE163161 counts: {meta['treatment'].value_counts().to_dict()}")

    present_genes = [g for g in PATHWAY_GENES_37 if g in log2_expr.index]
    mod_df = compute_module_matrix(log2_expr)
    panel_mat = pd.concat([log2_expr.loc[present_genes], mod_df], axis=0)

    res = run_ols_contrast(
        panel_mat, meta,
        group_col="treatment", ref_group="CONTROL", target_group="CLOZAPINE",
        covariates_formula="",
    )
    res["contrast"] = "Clozapine_vs_Control"
    res["cohort"] = "GSE163161"
    verify_no_nans(res, "gse163161_differential")
    res.to_csv(PROC_DIR / "gse163161_differential.csv", index=False)

    return res, {
        "n_samples": 10,
        "group_counts": meta["treatment"].value_counts().to_dict(),
        "n_genes_present": len(present_genes),
    }


def analyze_gse315204() -> tuple[pd.DataFrame, dict[str, Any]]:
    print("[8b/8] Analyzing GEO GSE315204 (mouse frontal cortex THY1+/HEPA/CD45+ RIS/CLZ/VEH)...")
    gdir = RAW_DIR / "gse315204"
    with gzip.open(gdir / "GSE315204_rawcounts.csv.gz", "rt", encoding="utf-8") as fh:
        counts = pd.read_csv(fh, index_col=0)
    counts.index = counts.index.astype(str).str.upper()
    counts = counts.groupby(level=0, sort=False).sum()
    log2_cpm = normalize_log2_cpm(counts)

    # Parse column names: counts_S586_01_2_CD45_VEH_S1
    col_records = []
    for col in log2_cpm.columns:
        m = re.match(r"counts_S586_\d+_(\d+)_(CD45|THY1|HEPA)_(VEH|RISPE|CLOZA)_S\d+$", col)
        if not m:
            raise RuntimeError(f"Unexpected GSE315204 column name: {col}")
        batch_num = "1" if m.group(1) == "2" else "2"
        celltype = m.group(2)
        trt_raw = m.group(3)
        trt = {"VEH": "VEHICLE", "RISPE": "RISPERIDONE", "CLOZA": "CLOZAPINE"}[trt_raw]
        any_drug = "VEHICLE" if trt == "VEHICLE" else "ANTIPSYCHOTIC"
        col_records.append({
            "sample": col,
            "batch": batch_num,
            "celltype": celltype,
            "treatment": trt,
            "any_drug": any_drug,
        })
    meta = pd.DataFrame(col_records).set_index("sample")

    present_genes = [g for g in PATHWAY_GENES_37 if g in log2_cpm.index]
    mod_df = compute_module_matrix(log2_cpm)
    panel_mat = pd.concat([log2_cpm.loc[present_genes], mod_df], axis=0)

    contrasts_list = []
    # Cell-type-stratified contrasts (with batch adjustment)
    for ct in ["THY1", "HEPA", "CD45"]:
        sub_meta = meta[meta["celltype"] == ct]
        sub_mat = panel_mat[sub_meta.index]
        for trt in ["RISPERIDONE", "CLOZAPINE"]:
            r_trt = run_ols_contrast(
                sub_mat, sub_meta,
                group_col="treatment", ref_group="VEHICLE", target_group=trt,
                covariates_formula="C(batch)",
            )
            r_trt["celltype"] = ct
            r_trt["contrast"] = f"{ct}_{trt}_vs_VEHICLE"
            contrasts_list.append(r_trt)
        r_pool = run_ols_contrast(
            sub_mat, sub_meta,
            group_col="any_drug", ref_group="VEHICLE", target_group="ANTIPSYCHOTIC",
            covariates_formula="C(batch)",
        )
        r_pool["celltype"] = ct
        r_pool["contrast"] = f"{ct}_ANTIPSYCHOTIC_vs_VEHICLE"
        contrasts_list.append(r_pool)

    # Pan-cortex (all 18 samples) adjusted for celltype + batch
    for trt in ["RISPERIDONE", "CLOZAPINE"]:
        r_pan = run_ols_contrast(
            panel_mat, meta,
            group_col="treatment", ref_group="VEHICLE", target_group=trt,
            covariates_formula="C(celltype) + C(batch)",
        )
        r_pan["celltype"] = "ALL"
        r_pan["contrast"] = f"ALL_{trt}_vs_VEHICLE"
        contrasts_list.append(r_pan)

    r_pan_pool = run_ols_contrast(
        panel_mat, meta,
        group_col="any_drug", ref_group="VEHICLE", target_group="ANTIPSYCHOTIC",
        covariates_formula="C(celltype) + C(batch)",
    )
    r_pan_pool["celltype"] = "ALL"
    r_pan_pool["contrast"] = "ALL_ANTIPSYCHOTIC_vs_VEHICLE"
    contrasts_list.append(r_pan_pool)

    out_df = pd.concat(contrasts_list, ignore_index=True)
    out_df["cohort"] = "GSE315204"
    verify_no_nans(out_df, "gse315204_differential")
    out_df.to_csv(PROC_DIR / "gse315204_differential.csv", index=False)

    return out_df, {
        "n_samples": len(meta),
        "celltypes": meta["celltype"].value_counts().to_dict(),
        "treatments": meta["treatment"].value_counts().to_dict(),
        "n_genes_present": len(present_genes),
    }


def analyze_gse67755() -> tuple[pd.DataFrame, dict[str, Any]]:
    print("[8c/8] Analyzing GEO GSE67755 (mouse whole brain chronic haloperidol n=10 vs placebo n=10)...")
    gdir = RAW_DIR / "gse67755"
    meta = parse_series_matrix_meta(gdir / "GSE67755-GPL11533_series_matrix.txt.gz")
    brain_meta = meta[meta["tissue"] == "whole brain"].copy()
    if len(brain_meta) != 20:
        raise RuntimeError(f"Expected 20 whole brain samples in GSE67755, got {len(brain_meta)}")
    brain_meta["treatment_grp"] = np.where(brain_meta["treatment"] == "drug", "HALOPERIDOL", "PLACEBO")
    brain_meta = brain_meta.set_index("geo_accession")

    # Parse probe-to-symbol map from GPL11533.annot.gz
    probe_to_sym: dict[str, str] = {}
    with gzip.open(gdir / "GPL11533.annot.gz", "rt", encoding="utf-8", errors="replace") as fh:
        in_table = False
        for line in fh:
            if line.startswith("!platform_table_begin"):
                in_table = True
                continue
            if line.startswith("!platform_table_end"):
                break
            if not in_table or line.startswith("#") or line.startswith("ID\t"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) > 2 and parts[2].strip():
                # Take primary symbol if multiple separated by ///
                sym = parts[2].split("///")[0].strip().upper()
                if sym:
                    probe_to_sym[parts[0].strip()] = sym

    # Parse expression matrix table from series matrix
    with gzip.open(gdir / "GSE67755-GPL11533_series_matrix.txt.gz", "rt", encoding="utf-8", errors="replace") as fh:
        sm_lines = fh.read().splitlines()
    i0 = next(i for i, l in enumerate(sm_lines) if l.startswith("!series_matrix_table_begin")) + 1
    i1 = next(i for i, l in enumerate(sm_lines) if l.startswith("!series_matrix_table_end"))
    mat = pd.read_csv(io.StringIO("\n".join(sm_lines[i0:i1])), sep="\t", index_col=0)
    mat.index = mat.index.astype(str)
    mat = mat[brain_meta.index].astype(float)

    mat["gene_symbol"] = mat.index.map(probe_to_sym)
    mat_sym = mat.dropna(subset=["gene_symbol"]).groupby("gene_symbol", sort=False).mean()

    present_genes = [g for g in PATHWAY_GENES_37 if g in mat_sym.index]
    mod_df = compute_module_matrix(mat_sym)
    panel_mat = pd.concat([mat_sym.loc[present_genes], mod_df], axis=0)

    res = run_ols_contrast(
        panel_mat, brain_meta,
        group_col="treatment_grp", ref_group="PLACEBO", target_group="HALOPERIDOL",
        covariates_formula="",
    )
    res["contrast"] = "Haloperidol_vs_Placebo"
    res["cohort"] = "GSE67755"
    verify_no_nans(res, "gse67755_differential")
    res.to_csv(PROC_DIR / "gse67755_differential.csv", index=False)

    return res, {
        "n_samples_whole_brain": 20,
        "group_counts": brain_meta["treatment_grp"].value_counts().to_dict(),
        "n_genes_present": len(present_genes),
    }


def dersimonian_laird_and_stouffer(rows: list[pd.Series]) -> dict[str, Any]:
    k = len(rows)
    g_arr = np.array([float(r["hedges_g"]) for r in rows])
    v_arr = np.array([max(1e-8, float(r["var_g"])) for r in rows])
    p_arr = np.array([max(1e-300, min(1.0 - 1e-16, float(r["p_val"]))) for r in rows])
    n_arr = np.array([float(r["n_target"] + r["n_ref"]) for r in rows])

    w = 1.0 / v_arr
    g_fe = float(np.sum(w * g_arr) / np.sum(w))
    q_stat = float(np.sum(w * ((g_arr - g_fe) ** 2)))
    df_q = max(1, k - 1)
    q_p = float(st.chi2.sf(q_stat, df_q)) if k > 1 else 1.0
    i2 = max(0.0, 100.0 * (q_stat - df_q) / q_stat) if (k > 1 and q_stat > 0) else 0.0
    c_val = float(np.sum(w) - np.sum(w ** 2) / np.sum(w))
    tau2 = max(0.0, (q_stat - df_q) / c_val) if (k > 1 and c_val > 0) else 0.0

    w_re = 1.0 / (v_arr + tau2)
    re_g = float(np.sum(w_re * g_arr) / np.sum(w_re))
    re_se = float(math.sqrt(1.0 / np.sum(w_re)))
    re_z = re_g / re_se
    re_p = float(2.0 * st.norm.sf(abs(re_z)))

    # Signed Stouffer Z
    signs = np.where(g_arr >= 0, 1.0, -1.0)
    z_ind = signs * st.norm.isf(p_arr / 2.0)
    stouffer_z = float(np.sum(z_ind) / math.sqrt(k))
    stouffer_p = float(2.0 * st.norm.sf(abs(stouffer_z)))

    w_sqrt_n = np.sqrt(n_arr)
    w_stouffer_z = float(np.sum(w_sqrt_n * z_ind) / math.sqrt(np.sum(n_arr)))
    w_stouffer_p = float(2.0 * st.norm.sf(abs(w_stouffer_z)))

    return {
        "k_cohorts": k,
        "total_n": int(np.sum(n_arr)),
        "fe_hedges_g": g_fe,
        "re_hedges_g": re_g,
        "re_se": re_se,
        "re_ci95_low": re_g - Z_95 * re_se,
        "re_ci95_high": re_g + Z_95 * re_se,
        "re_z": re_z,
        "re_p": re_p,
        "q_stat": q_stat,
        "q_p": q_p,
        "i2_pct": i2,
        "tau2": tau2,
        "stouffer_z": stouffer_z,
        "stouffer_p": stouffer_p,
        "weighted_stouffer_z": w_stouffer_z,
        "weighted_stouffer_p": w_stouffer_p,
    }


def run_cross_cohort_meta(
    df138: pd.DataFrame,
    df174: pd.DataFrame,
    df163: pd.DataFrame,
    df315: pd.DataFrame,
    df677: pd.DataFrame,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    print("[8d/8] Running DerSimonian-Laird & Stouffer cross-cohort meta-analysis...")

    # Meta Set A: Antipsychotic Perturbation across all 5 cohorts (using THY1+ neurons for GSE315204)
    drug_sources_5 = {
        "GSE138082_SCZ_ON_vs_OFF": df138[df138["contrast"] == "SCZ_ON_vs_SCZ_OFF"].set_index("feature"),
        "GSE174407_SCZ_Trt_vs_Untrt": df174[df174["contrast"] == "SCZ_treated_vs_SCZ_untreated"].set_index("feature"),
        "GSE163161_CLZ_vs_CTL": df163.set_index("feature"),
        "GSE315204_THY1_Drug_vs_VEH": df315[df315["contrast"] == "THY1_ANTIPSYCHOTIC_vs_VEHICLE"].set_index("feature"),
        "GSE67755_HAL_vs_PLAC": df677.set_index("feature"),
    }
    # Meta Set B: Disease vs Control in Human Postmortem SCZ (2 cohorts)
    disease_sources_2 = {
        "GSE138082_SCZ_OFF_vs_CTL": df138[df138["contrast"] == "SCZ_OFF_vs_CTL"].set_index("feature"),
        "GSE174407_SCZ_Untrt_vs_CTL": df174[df174["contrast"] == "SCZ_untreated_vs_CTL"].set_index("feature"),
    }
    # Meta Set C: Human-only Antipsychotic Perturbation (3 human cohorts)
    human_drug_sources_3 = {
        k: drug_sources_5[k]
        for k in ["GSE138082_SCZ_ON_vs_OFF", "GSE174407_SCZ_Trt_vs_Untrt", "GSE163161_CLZ_vs_CTL"]
    }

    all_features = PATHWAY_GENES_37 + list(MODULES.keys())
    meta_rows = []
    for meta_label, src_dict in [
        ("ANTIPSYCHOTIC_5COHORT_CROSS_SPECIES", drug_sources_5),
        ("ANTIPSYCHOTIC_3COHORT_HUMAN", human_drug_sources_3),
        ("SCZ_UNTREATED_VS_CTL_2COHORT_HUMAN", disease_sources_2),
    ]:
        scope_rows = []
        for feat in all_features:
            present_rows = [df.loc[feat] for df in src_dict.values() if feat in df.index]
            if len(present_rows) < 2:
                continue
            res = dersimonian_laird_and_stouffer(present_rows)
            res["meta_analysis"] = meta_label
            res["feature"] = feat
            res["is_module"] = feat.startswith("MODULE_")
            res["cohorts_included"] = ",".join(name for name, df in src_dict.items() if feat in df.index)
            scope_rows.append(res)
        sdf = pd.DataFrame(scope_rows)
        sdf["re_fdr"] = 1.0
        sdf["stouffer_fdr"] = 1.0
        sdf["weighted_stouffer_fdr"] = 1.0
        for mask in [~sdf["is_module"], sdf["is_module"]]:
            if mask.any():
                sdf.loc[mask, "re_fdr"] = bh_fdr(sdf.loc[mask, "re_p"].to_numpy())
                sdf.loc[mask, "stouffer_fdr"] = bh_fdr(sdf.loc[mask, "stouffer_p"].to_numpy())
                sdf.loc[mask, "weighted_stouffer_fdr"] = bh_fdr(sdf.loc[mask, "weighted_stouffer_p"].to_numpy())
        meta_rows.extend(sdf.to_dict(orient="records"))

    meta_df = pd.DataFrame(meta_rows)
    verify_no_nans(meta_df, "cross_cohort_meta")
    meta_df.to_csv(PROC_DIR / "cross_cohort_meta.csv", index=False)

    # Extract concise summary metrics
    m5 = meta_df[meta_df["meta_analysis"] == "ANTIPSYCHOTIC_5COHORT_CROSS_SPECIES"].set_index("feature")
    md2 = meta_df[meta_df["meta_analysis"] == "SCZ_UNTREATED_VS_CTL_2COHORT_HUMAN"].set_index("feature")
    return meta_df, {
        "antipsychotic_5cohort_modules": m5.loc[list(MODULES.keys())][[
            "re_hedges_g", "re_se", "re_p", "re_fdr", "stouffer_z", "stouffer_p", "stouffer_fdr", "i2_pct"
        ]].to_dict(orient="index"),
        "scz_2cohort_modules": md2.loc[list(MODULES.keys())][[
            "re_hedges_g", "re_se", "re_p", "re_fdr", "stouffer_z", "stouffer_p", "stouffer_fdr", "i2_pct"
        ]].to_dict(orient="index"),
        "antipsychotic_5cohort_key_genes": {
            g: m5.loc[g][[
                "re_hedges_g", "re_p", "re_fdr", "stouffer_z", "stouffer_p", "stouffer_fdr", "i2_pct"
            ]].to_dict()
            for g in ["CPEB4", "SRRM4", "SRSF11", "RNPS1", "RBFOX1", "PTBP1", "HNRNPC", "HDAC2", "POLR2A", "PRKACA", "DRD2", "HTR2A"]
            if g in m5.index
        },
    }


def main() -> int:
    PROC_DIR.mkdir(parents=True, exist_ok=True)
    TABLES_DIR.mkdir(parents=True, exist_ok=True)

    gtex_sum = analyze_gtex_v8()
    gse276_sum = analyze_gse276143()
    cis_sum = analyze_refseq_and_uniprot()
    chembl_sum = analyze_chembl_v35()
    string_sum = analyze_string_v12()

    df138, s138 = analyze_gse138082()
    df174, s174 = analyze_gse174407()
    df163, s163 = analyze_gse163161()
    df315, s315 = analyze_gse315204()
    df677, s677 = analyze_gse67755()
    _, meta_sum = run_cross_cohort_meta(df138, df174, df163, df315, df677)

    bio_summary = {
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "datasets": {
            "gtex_v8": gtex_sum,
            "gse276143": gse276_sum,
            "refseq_uniprot_cis": cis_sum,
            "chembl_v35": chembl_sum,
            "string_v12": string_sum,
            "gse138082": s138,
            "gse174407": s174,
            "gse163161": s163,
            "gse315204": s315,
            "gse67755": s677,
            "cross_cohort_meta": meta_sum,
        },
    }
    (TABLES_DIR / "bioinformatics_summary.json").write_text(
        json.dumps(bio_summary, indent=2) + "\n", encoding="utf-8"
    )

    registry_path = RESULTS_DIR / "metrics_registry.json"
    if registry_path.exists():
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
    else:
        registry = {}
    registry["bioinformatics_phase1"] = bio_summary
    registry_path.write_text(json.dumps(registry, indent=2) + "\n", encoding="utf-8")

    print("[DONE] All Phase 1 bioinformatics analyses complete and verified with zero NaNs.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
