#!/usr/bin/env python3
"""
Phase 6: Comprehensive Manuscript, Equation, Citation, Figure, Table, and OOXML Auditor.

Verifies:
  1. Required manuscript section presence and exact order (SKILL.md).
  2. Structural & word limits (Title <= 25 words, Abstract 200-250 words & 0 citations,
     Keywords 5-8, Intro 4-6 paras, Results 6-8 declarative headings & 0 bullets,
     Conclusions 100-200 words).
  3. Strict 1..N first-appearance ordering for Equations (1)-(16), Figures 1-6,
     Tables 1-4, Supplementary Figures S1-S3, Supplementary Tables S1-S4, and
     References 1-N (with zero uncited/out-of-order entries and 100% grounding in
     data/verified_references.json).
  4. Native Word OOXML integrity on Manuscript_with_Figures.docx, Manuscript_Text_Only.docx,
     and Supplementary_Material.docx: 16 editable <m:oMath> equations, continuous left
     line numbering, top-right PAGE header, zero stray markdown tokens, image embedding
     counts (6 / 0 / 3), black typography, and zero AI watermarks outside the
     Generative AI Declaration.
  5. Cross-check against results/metrics_registry.json and results/verification_report.json.

Outputs: results/manuscript_audit_report.json
Exit code: 0 iff ALL_CHECKS_PASSED is True, else 1.
"""

from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path
from typing import Any

from lxml import etree

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"
MANUSCRIPT_DIR = ROOT / "manuscript"

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"

EXPECTED_SECTIONS = [
    "Abstract",
    "Introduction",
    "Methodology",
    "Results",
    "Discussion",
    "Conclusions",
    "CRediT Authorship Contribution Statement",
    "Ethics Statement",
    "Funding",
    "Declaration of Competing Interest",
    "Data Availability Statement",
    "Declaration of Generative AI and AI-Assisted Technologies in the Writing Process",
    "References",
]


def parse_sup_citation_nums(expr: str) -> list[int]:
    """Expand '1–3,7' or '1-3,7' into [1, 2, 3, 7]."""
    nums: list[int] = []
    for part in expr.split(","):
        part = part.strip()
        if not part:
            continue
        m = re.match(r"^(\d+)[–\-](\d+)$", part)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            nums.extend(range(a, b + 1))
        elif part.isdigit():
            nums.append(int(part))
    return nums


def extract_first_appearance_order(matches: list[int]) -> list[int]:
    seen: set[int] = set()
    order: list[int] = []
    for n in matches:
        if n not in seen:
            seen.add(n)
            order.append(n)
    return order


def audit_markdown(verified_refs: dict[str, Any]) -> dict[str, Any]:
    md_path = MANUSCRIPT_DIR / "Manuscript.md"
    supp_md_path = MANUSCRIPT_DIR / "Supplementary_Material.md"
    text = md_path.read_text(encoding="utf-8")
    supp_text = supp_md_path.read_text(encoding="utf-8")

    lines = text.splitlines()
    title = lines[0].lstrip("# ").strip()
    title_words = len(title.split())

    # Split Level-1 sections (## ...)
    sec_order: list[str] = []
    sec_bodies: dict[str, str] = {}
    cur_sec: str | None = None
    buf: list[str] = []
    for ln in lines:
        if ln.startswith("## "):
            if cur_sec is not None:
                sec_bodies[cur_sec] = "\n".join(buf).strip()
            cur_sec = ln[3:].strip()
            sec_order.append(cur_sec)
            buf = []
        elif cur_sec is not None:
            buf.append(ln)
    if cur_sec is not None:
        sec_bodies[cur_sec] = "\n".join(buf).strip()

    # Abstract
    abs_raw = sec_bodies.get("Abstract", "")
    abs_para_lines = [p for p in abs_raw.split("\n\n") if p.strip() and not p.strip().startswith("**Keywords:**")]
    abs_text = " ".join(abs_para_lines)
    abs_clean = re.sub(r"<[^>]+>|[\*~^`]", "", abs_text)
    abs_words = len(abs_clean.split())
    abs_has_citations = bool(re.search(r"(?<!\*R\*)(?<!\*I\*)(?<!\*S\*)(?<!10)<sup>\d", abs_text))

    # Keywords
    kw_match = re.search(r"\*\*Keywords:\*\*\s*(.+)", abs_raw)
    kw_list = [k.strip() for k in kw_match.group(1).split(";") if k.strip()] if kw_match else []

    # Introduction paragraphs (non-empty) & zero subheadings
    intro_raw = sec_bodies.get("Introduction", "")
    intro_paras = [p.strip() for p in intro_raw.split("\n\n") if p.strip()]
    intro_no_subheadings = not any(p.startswith("### ") for p in intro_paras)

    # Results declarative headings & zero bullet points
    res_raw = sec_bodies.get("Results", "")
    res_headings = [ln[4:].strip() for ln in res_raw.splitlines() if ln.startswith("### ")]
    res_bullets = [
        ln for ln in res_raw.splitlines()
        if re.match(r"^\s*[-*•]\s+", ln)
    ]

    # Conclusions
    conc_raw = sec_bodies.get("Conclusions", "")
    conc_clean = re.sub(r"<[^>]+>|[\*~^`]", "", conc_raw)
    conc_words = len(conc_clean.split())

    # Equations 1..16 (display order + first appearance across Methods & Results)
    disp_eqs = [int(x) for x in re.findall(r"\\qquad \((\d+)\)\s*\$\$", text)]
    body_before_refs = text.split("## References")[0]
    eq_mentions = []
    for m in re.finditer(r"(?:Eqs?\.\s*\(?(\d+)(?:[–\-](\d+))?|\$\$[^\n]+?\\qquad \((\d+)\)\s*\$\$)", body_before_refs):
        if m.group(3):
            eq_mentions.append(int(m.group(3)))
        elif m.group(1):
            a = int(m.group(1))
            b = int(m.group(2)) if m.group(2) else a
            eq_mentions.extend(range(a, b + 1))
    eq_first_order = extract_first_appearance_order(eq_mentions)

    # Figures 1..6 first appearance
    fig_matches = [int(x) for x in re.findall(r"\b(?:Figure|Fig\.)\s+(\d+)\b", body_before_refs)]
    fig_first_order = extract_first_appearance_order(fig_matches)

    # Tables 1..4 first appearance
    tab_matches = [int(x) for x in re.findall(r"\bTable\s+(\d+)\b", body_before_refs)]
    tab_first_order = extract_first_appearance_order(tab_matches)

    # Supplementary Figs S1..S3 & Supplementary Tables S1..S4 first appearance in main text + supp
    sfig_main = extract_first_appearance_order([int(x) for x in re.findall(r"Supplementary Fig(?:ure)?\.?\s+S(\d+)[a-z]?\b", body_before_refs)])
    sfig_supp = extract_first_appearance_order([int(x) for x in re.findall(r"Supplementary Fig(?:ure)?\.?\s+S(\d+)[a-z]?\b", supp_text)])
    stab_main = extract_first_appearance_order([int(x) for x in re.findall(r"Supplementary Table\s+S(\d+)\b", body_before_refs)])
    stab_supp = extract_first_appearance_order([int(x) for x in re.findall(r"Supplementary Table\s+S(\d+)\b", supp_text)])

    # References 1..N citation sequence vs bibliography (excluding exponent <sup>2</sup>/10<sup>-</sup>)
    sup_cites: list[int] = []
    for m in re.finditer(r"(?<!\*R\*)(?<!\*I\*)(?<!\*S\*)(?<!10)<sup>(\d+(?:[–\-]\d+|,\d+)*)</sup>", body_before_refs):
        sup_cites.extend(parse_sup_citation_nums(m.group(1)))
    cite_first_order = extract_first_appearance_order(sup_cites)

    refs_raw = sec_bodies.get("References", "")
    ref_lines = [ln.strip() for ln in refs_raw.splitlines() if re.match(r"^\d+\.\s+", ln.strip())]
    ref_nums = [int(re.match(r"^(\d+)\.", ln).group(1)) for ln in ref_lines]

    # Verify all cited refs exist in verified_references.json and passed claim audit
    dois_in_db = {str(r.get("doi")).lower(): r for r in verified_refs if r.get("doi")}
    pmids_in_db = {str(r.get("pmid")): r for r in verified_refs if r.get("pmid")}
    unverified_refs: list[str] = []
    for ln in ref_lines:
        pmid_m = re.search(r"PMID:\s*(\d+)", ln)
        doi_m = re.search(r"https://doi\.org/([^\s]+)", ln)
        ok = False
        if pmid_m and pmid_m.group(1) in pmids_in_db and pmids_in_db[pmid_m.group(1)].get("claim_audit_passed"):
            ok = True
        elif doi_m and doi_m.group(1).rstrip(".").lower() in dois_in_db and dois_in_db[doi_m.group(1).rstrip(".").lower()].get("claim_audit_passed"):
            ok = True
        if not ok:
            unverified_refs.append(ln[:80])

    # Check zero AI mentions outside Declaration of Generative AI
    non_ai_text = "\n".join(
        sec_bodies[s] for s in sec_order
        if s != "Declaration of Generative AI and AI-Assisted Technologies in the Writing Process"
    )
    ai_leaks = re.findall(
        r"\b(?:ChatGPT|OpenAI|Anthropic|Claude|Gemini|large language model|AI-assisted|generated by AI|watermark)\b",
        non_ai_text,
        flags=re.IGNORECASE,
    )

    return {
        "title_word_count": title_words,
        "title_le_25": title_words <= 25,
        "sections_present": sec_order,
        "exact_section_order_match": sec_order == EXPECTED_SECTIONS,
        "abstract_word_count": abs_words,
        "abstract_200_to_250": 200 <= abs_words <= 250,
        "abstract_zero_citations": not abs_has_citations,
        "keywords_count": len(kw_list),
        "keywords_5_to_8": 5 <= len(kw_list) <= 8,
        "intro_paragraph_count": len(intro_paras),
        "intro_4_to_6_paras_no_subheadings": (4 <= len(intro_paras) <= 6) and intro_no_subheadings,
        "results_heading_count": len(res_headings),
        "results_6_to_8_headings_zero_bullets": (6 <= len(res_headings) <= 8) and (len(res_bullets) == 0),
        "conclusions_word_count": conc_words,
        "conclusions_100_to_200": 100 <= conc_words <= 200,
        "display_equations_order": disp_eqs,
        "equations_1_to_16_display_exact": disp_eqs == list(range(1, 17)),
        "equations_1_to_16_first_appearance_exact": eq_first_order == list(range(1, 17)),
        "figures_first_appearance": fig_first_order,
        "figures_1_to_6_exact": fig_first_order == [1, 2, 3, 4, 5, 6],
        "tables_first_appearance": tab_first_order,
        "tables_1_to_4_exact": tab_first_order == [1, 2, 3, 4],
        "supp_figs_main_order": sfig_main,
        "supp_figs_supp_order": sfig_supp,
        "supp_figs_S1_to_S3_exact": (sfig_main == [1, 2, 3]) and (sfig_supp == [1, 2, 3]),
        "supp_tabs_main_order": stab_main,
        "supp_tabs_supp_order": stab_supp,
        "supp_tabs_S1_to_S4_exact": (stab_main == [1, 2, 3, 4]) and (stab_supp == [1, 2, 3, 4]),
        "n_cited_refs": len(cite_first_order),
        "n_listed_refs": len(ref_nums),
        "refs_strict_order_1_to_N_no_uncited": (cite_first_order == list(range(1, len(ref_nums) + 1))) and (ref_nums == list(range(1, len(ref_nums) + 1))),
        "unverified_refs_count": len(unverified_refs),
        "all_refs_verified_and_claim_passed": len(unverified_refs) == 0,
        "ai_mentions_outside_declaration": ai_leaks,
        "zero_ai_leaks_outside_declaration": len(ai_leaks) == 0,
    }


def audit_docx(path: Path, expected_images: int, expected_omath: int, check_sections: bool = True) -> dict[str, Any]:
    with zipfile.ZipFile(path, "r") as zf:
        names = set(zf.namelist())
        doc_xml = etree.fromstring(zf.read("word/document.xml"))
        hdr_xml = etree.fromstring(zf.read("word/header1.xml"))
        core_xml = etree.fromstring(zf.read("docProps/core.xml"))

    omaths = doc_xml.findall(f".//{{{M_NS}}}oMath")
    ln_nums = doc_xml.findall(f".//{{{W_NS}}}lnNumType")
    media_imgs = [n for n in names if n.startswith("word/media/")]

    hdr_instr = " ".join((el.text or "") for el in hdr_xml.findall(f".//{{{W_NS}}}instrText"))
    has_page_field = "PAGE" in hdr_instr

    # Check font colors are only 000000 or auto
    bad_colors = []
    for c_el in doc_xml.findall(f".//{{{W_NS}}}color"):
        v = c_el.get(f"{{{W_NS}}}val")
        if v not in ("000000", "auto", None):
            bad_colors.append(v)

    # Extract rendered paragraph text
    paras_txt: list[str] = []
    for p in doc_xml.findall(f".//{{{W_NS}}}p"):
        txt = "".join((t.text or "") for t in p.findall(f".//{{{W_NS}}}t"))
        if txt.strip():
            paras_txt.append(txt.strip())

    joined = "\n".join(paras_txt)
    stray_md = re.findall(r"(\*\*|`|\[cite:|<sub>|<sup>)", joined)

    # Extract section headings from DOCX if main manuscript
    docx_secs_ok = True
    if check_sections:
        found_secs = [t for t in paras_txt if t in EXPECTED_SECTIONS]
        docx_secs_ok = (found_secs == EXPECTED_SECTIONS)

    has_comments_xml = "word/comments.xml" in names
    core_txt = " ".join((el.text or "") for el in core_xml.iter())
    ai_in_core = bool(re.search(r"chatgpt|openai|anthropic|claude|gemini|watermark", core_txt, re.I))

    return {
        "file": path.name,
        "valid_ooxml": True,
        "omath_count": len(omaths),
        "omath_count_exact": len(omaths) == expected_omath,
        "continuous_line_numbers": len(ln_nums) >= 1,
        "top_right_page_number_field": has_page_field,
        "embedded_image_count": len(media_imgs),
        "image_count_exact": len(media_imgs) == expected_images,
        "all_text_black": len(bad_colors) == 0,
        "zero_stray_markdown_tokens": len(stray_md) == 0,
        "stray_tokens_found": stray_md[:10],
        "docx_sections_exact": docx_secs_ok,
        "zero_comments_and_core_watermarks": (not has_comments_xml) and (not ai_in_core),
    }


def check_numeric_grounding(md_text: str) -> dict[str, Any]:
    reg = json.loads((RESULTS_DIR / "metrics_registry.json").read_text(encoding="utf-8"))
    ver = json.loads((RESULTS_DIR / "verification_report.json").read_text(encoding="utf-8"))

    required_tokens = [
        "0.9984",   # GSE276143 LORO CV R2
        "0.937",    # GTEx brain 13 LOOCV R2
        "−0.621",   # RBFOX1 partial r
        "−0.696",   # SRRM4 5-cohort meta RE g
        "−0.676",   # PTBP1 5-cohort meta RE g
        "+0.794",   # HDAC2 3-cohort human RE g
        "74.39%",   # Risperidone BA9 Psi4*
        "+10.36",   # Epistasis % points
        "0.981",    # R_seed with 0.5 eq peptide
        "0.657",    # Day-42 moderate Risperidone M_f
        "0.252",    # Day-42 severe lock-in Risperidone M_f
        "0.818",    # Day-42 severe + 2x Autophagy M_f
        "0.732",    # Day-42 severe + 0.5 eq me4Pep M_f
    ]
    missing = [tok for tok in required_tokens if tok not in md_text]
    return {
        "modeling_verification_passed": bool(ver.get("ALL_TESTS_PASSED")),
        "missing_key_numeric_tokens": missing,
        "all_key_metrics_grounded": (len(missing) == 0) and bool(ver.get("ALL_TESTS_PASSED")) and bool(reg["modeling_phase2"]["ALL_TESTS_PASSED"]),
    }


def main() -> None:
    raw_refs = json.loads((DATA_DIR / "verified_references.json").read_text(encoding="utf-8"))
    ref_list = raw_refs["references"] if isinstance(raw_refs, dict) and "references" in raw_refs else (
        list(raw_refs.values()) if isinstance(raw_refs, dict) else raw_refs
    )

    md_res = audit_markdown(ref_list)
    md_text = (MANUSCRIPT_DIR / "Manuscript.md").read_text(encoding="utf-8")
    num_res = check_numeric_grounding(md_text)

    docx_fig_res = audit_docx(MANUSCRIPT_DIR / "Manuscript_with_Figures.docx", expected_images=6, expected_omath=16, check_sections=True)
    docx_txt_res = audit_docx(MANUSCRIPT_DIR / "Manuscript_Text_Only.docx", expected_images=0, expected_omath=16, check_sections=True)
    docx_sup_res = audit_docx(MANUSCRIPT_DIR / "Supplementary_Material.docx", expected_images=3, expected_omath=0, check_sections=False)

    bool_checks = []
    for block in (md_res, num_res, docx_fig_res, docx_txt_res, docx_sup_res):
        for k, v in block.items():
            if isinstance(v, bool):
                bool_checks.append((f"{block.get('file', 'manuscript')}:{k}", v))

    failed = [name for name, val in bool_checks if not val]
    report = {
        "ALL_CHECKS_PASSED": len(failed) == 0,
        "failed_checks": failed,
        "total_boolean_checks": len(bool_checks),
        "markdown_audit": md_res,
        "numeric_grounding": num_res,
        "docx_with_figures_audit": docx_fig_res,
        "docx_text_only_audit": docx_txt_res,
        "docx_supplementary_audit": docx_sup_res,
    }
    (RESULTS_DIR / "manuscript_audit_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Manuscript audit: {len(bool_checks) - len(failed)}/{len(bool_checks)} checks passed.")
    if failed:
        print("FAILED CHECKS:", failed)
        sys.exit(1)
    print("ALL_CHECKS_PASSED = true")


if __name__ == "__main__":
    main()
