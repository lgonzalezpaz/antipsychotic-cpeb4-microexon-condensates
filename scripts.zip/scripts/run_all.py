#!/usr/bin/env python3
"""
Master End-to-End Pipeline Runner for Reproducibility.

Modes:
  python scripts/run_all.py                          # Full live fetch + analysis + modeling + figures + manuscript + audit
  python scripts/run_all.py --skip-download          # Use cached 164 raw files (SHA256-verified) + full pipeline
  python scripts/run_all.py --from-processed         # Start from verified data/processed/*.csv through 03, 05, 06, 07
  python scripts/run_all.py --from-processed --skip-modeling  # Regenerate figures, manuscript, DOCX, and audit (~15-60 s)
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = ROOT / "scripts"


def run_step(script_name: str, extra_args: list[str] | None = None) -> None:
    cmd = [sys.executable, "-u", str(SCRIPTS_DIR / script_name)] + (extra_args or [])
    print(f"\n>>> Running: {' '.join(cmd)}")
    t0 = time.perf_counter()
    res = subprocess.run(cmd, cwd=str(ROOT))
    dt = time.perf_counter() - t0
    if res.returncode != 0:
        raise RuntimeError(f"Step {script_name} failed with exit code {res.returncode} after {dt:.2f} s")
    print(f"<<< Completed {script_name} in {dt:.2f} s")


def main() -> None:
    parser = argparse.ArgumentParser(description="Reproducible end-to-end execution of the CPEB4 antipsychotic study.")
    parser.add_argument("--skip-download", action="store_true", help="Verify SHA256 manifest of cached raw files instead of re-downloading.")
    parser.add_argument("--from-processed", action="store_true", help="Skip steps 01/02/04 and start from data/processed/.")
    parser.add_argument("--skip-modeling", action="store_true", help="Skip computationally intensive step 03 (Sobol/bootstrap) and rebuild figures/manuscript/audit.")
    args = parser.parse_args()

    t_start = time.perf_counter()
    if not args.from_processed:
        run_step("01_fetch_public_databases.py", ["--skip-download"] if args.skip_download else [])
        run_step("02_bioinformatics_analysis.py")
        run_step("04_verify_literature.py")

    if not args.skip_modeling:
        run_step("03_mechanistic_model_and_validation.py")

    run_step("05_generate_figures.py")
    run_step("06_build_manuscript_docx.py")
    run_step("07_audit_manuscript.py")

    print(f"\n=== ALL PIPELINE STEPS SUCCEEDED IN {time.perf_counter() - t_start:.2f} s ===")


if __name__ == "__main__":
    main()
