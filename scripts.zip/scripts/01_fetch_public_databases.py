#!/usr/bin/env python3
"""
Phase 1 - Step 1: Fetch and cache all 8 verified public multi-omics datasets
into data/raw/ and maintain a reproducible SHA256 manifest in
data/raw/sha256_manifest.json.

Supports:
  --skip-download : Skip all network requests; verify all expected raw files
                    exist locally and match data/raw/sha256_manifest.json.
  --force         : Re-download files even if already cached locally.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import datetime as dt
import hashlib
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = PROJECT_ROOT / "data" / "raw"
MANIFEST_PATH = RAW_DIR / "sha256_manifest.json"

USER_AGENT = "Python-urllib/3.12 (Antipsychotic-CPEB4-Bioinformatics-Curator)"

GENES_31 = [
    "CPEB4", "SRRM4", "SRRM3", "SRSF11", "RNPS1", "RBFOX1", "RBFOX2", "RBFOX3",
    "PTBP1", "PTBP2", "HNRNPC", "DRD2", "HTR2A", "DRD1", "HTR1A", "ADRA1A",
    "PRKACA", "PRKACB", "PPP1R1B", "CAMK2A", "CAMK2B", "AKT1", "GSK3B",
    "SRPK1", "SRPK2", "DYRK1A", "HDAC2", "HDAC1", "POLR2A", "SYP", "SNAP25",
]

UNIPROT_ACCESSIONS = [
    "Q17RY0",  # CPEB4
    "A7MD48",  # SRRM4
    "Q9NWB1",  # RBFOX1
    "P14416",  # DRD2
    "P28223",  # HTR2A
    "Q9UD71",  # PPP1R1B
    "Q92769",  # HDAC2
]

CHEMBL_DRUGS = {
    "HALOPERIDOL": "CHEMBL54",
    "FLUPHENAZINE": "CHEMBL726",
    "CHLORPROMAZINE": "CHEMBL71",
    "RISPERIDONE": "CHEMBL85",
    "PALIPERIDONE": "CHEMBL1621",
    "OLANZAPINE": "CHEMBL715",
    "CLOZAPINE": "CHEMBL42",
    "QUETIAPINE": "CHEMBL716",
    "ARIPIPRAZOLE": "CHEMBL1112",
    "ZIPRASIDONE": "CHEMBL708",
    "AMISULPRIDE": "CHEMBL243712",
    "LURASIDONE": "CHEMBL1237021",
}

CHEMBL_TARGETS = {
    "DRD2": "CHEMBL217",
    "HTR2A": "CHEMBL224",
    "DRD1": "CHEMBL2056",
    "HTR1A": "CHEMBL214",
    "ADRA1A": "CHEMBL229",
    "HRH1": "CHEMBL231",
    "CHRM1": "CHEMBL216",
}

STRING_NODES_27 = [
    "DRD2", "HTR2A", "DRD1", "HTR1A", "GNAI2", "GNAQ", "ARRB2",
    "PRKACA", "PPP1R1B", "PPP1CA", "CAMK2A", "AKT1", "GSK3B", "MAPK1",
    "SRPK1", "SRPK2", "DYRK1A", "HDAC2", "EP300", "POLR2A",
    "SRRM4", "SRSF11", "RNPS1", "RBFOX1", "PTBP1", "HNRNPC", "CPEB4",
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def http_get_bytes(url: str, timeout: int = 90, retries: int = 4, sleep_before: float = 0.0) -> bytes:
    if sleep_before > 0:
        time.sleep(sleep_before)
    last_err: Exception | None = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read()
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError) as exc:
            last_err = exc
            wait = 1.5 * (2 ** attempt)
            time.sleep(wait)
    raise RuntimeError(f"Failed GET {url} after {retries} attempts: {last_err}")


def http_get_json(url: str, timeout: int = 90, sleep_before: float = 0.0) -> Any:
    raw = http_get_bytes(url, timeout=timeout, sleep_before=sleep_before)
    return json.loads(raw.decode("utf-8"))


def download_binary_cached(
    url: str,
    dest: Path,
    force: bool = False,
    timeout: int = 120,
    sleep_before: float = 0.0,
) -> dict[str, Any]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0 and not force:
        return {
            "relpath": dest.relative_to(RAW_DIR).as_posix(),
            "url": url,
            "bytes": dest.stat().st_size,
            "sha256": sha256_file(dest),
            "cached": True,
        }
    data = http_get_bytes(url, timeout=timeout, sleep_before=sleep_before)
    if not data:
        raise RuntimeError(f"Empty response from {url}")
    dest.write_bytes(data)
    return {
        "relpath": dest.relative_to(RAW_DIR).as_posix(),
        "url": url,
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "cached": False,
    }


def write_json_cached(obj: Any, dest: Path, url: str) -> dict[str, Any]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps(obj, indent=2, sort_keys=False) + "\n").encode("utf-8")
    dest.write_bytes(payload)
    return {
        "relpath": dest.relative_to(RAW_DIR).as_posix(),
        "url": url,
        "bytes": len(payload),
        "sha256": hashlib.sha256(payload).hexdigest(),
        "cached": False,
    }


def fetch_gtex_paginated(base_url: str, params: dict[str, Any]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    page = 0
    while True:
        q = dict(params)
        q["page"] = page
        q["itemsPerPage"] = 250
        url = f"{base_url}?{urllib.parse.urlencode(q, doseq=True)}"
        res = http_get_json(url, sleep_before=0.1)
        data = res.get("data", [])
        records.extend(data)
        paging = res.get("paging_info", {})
        num_pages = int(paging.get("numberOfPages", 1))
        page += 1
        if page >= num_pages or not data:
            break
    return records


def fetch_gtex_v8(force: bool) -> list[dict[str, Any]]:
    print("[1/8] Fetching GTEx v8...")
    out_dir = RAW_DIR / "gtex_v8"
    entries: list[dict[str, Any]] = []

    files_needed = [
        out_dir / "tissueSiteDetail.json",
        out_dir / "cpeb4_reference_exon.json",
        out_dir / "cpeb4_median_junction_expression.json",
        out_dir / "cpeb4_median_exon_expression.json",
        out_dir / "reference_genes_31.json",
        out_dir / "median_gene_expression_31genes.json",
    ]
    if not force and all(p.exists() and p.stat().st_size > 0 for p in files_needed):
        for p in files_needed:
            entries.append({
                "relpath": p.relative_to(RAW_DIR).as_posix(),
                "url": "https://gtexportal.org/api/v2/",
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
                "cached": True,
            })
        return entries

    # Tissue metadata
    tissue_url = "https://gtexportal.org/api/v2/dataset/tissueSiteDetail?datasetId=gtex_v8&itemsPerPage=100"
    tissue_res = http_get_json(tissue_url)
    entries.append(write_json_cached(tissue_res, out_dir / "tissueSiteDetail.json", tissue_url))

    # CPEB4 exon reference
    ref_ex_url = "https://gtexportal.org/api/v2/reference/exon"
    ref_ex_data = fetch_gtex_paginated(ref_ex_url, {
        "gencodeId": "ENSG00000113742.12",
        "gencodeVersion": "v26",
        "genomeBuild": "GRCh38/hg38",
    })
    entries.append(write_json_cached(
        {"data": ref_ex_data},
        out_dir / "cpeb4_reference_exon.json",
        ref_ex_url + "?gencodeId=ENSG00000113742.12",
    ))

    # CPEB4 medianJunctionExpression (all pages)
    junc_url = "https://gtexportal.org/api/v2/expression/medianJunctionExpression"
    junc_data = fetch_gtex_paginated(junc_url, {
        "gencodeId": "ENSG00000113742.12",
        "datasetId": "gtex_v8",
    })
    entries.append(write_json_cached(
        {"data": junc_data},
        out_dir / "cpeb4_median_junction_expression.json",
        junc_url + "?gencodeId=ENSG00000113742.12&datasetId=gtex_v8",
    ))

    # CPEB4 medianExonExpression (all pages)
    exon_url = "https://gtexportal.org/api/v2/expression/medianExonExpression"
    exon_data = fetch_gtex_paginated(exon_url, {
        "gencodeId": "ENSG00000113742.12",
        "datasetId": "gtex_v8",
    })
    entries.append(write_json_cached(
        {"data": exon_data},
        out_dir / "cpeb4_median_exon_expression.json",
        exon_url + "?gencodeId=ENSG00000113742.12&datasetId=gtex_v8",
    ))

    # Resolve 31 genes via reference/gene
    ref_gene_url = "https://gtexportal.org/api/v2/reference/gene"
    ref_genes = fetch_gtex_paginated(ref_gene_url, {
        "geneId": GENES_31,
        "gencodeVersion": "v26",
        "genomeBuild": "GRCh38/hg38",
    })
    symbol_to_gencode = {}
    for g in ref_genes:
        sym = g.get("geneSymbol")
        if sym in GENES_31 and sym not in symbol_to_gencode:
            symbol_to_gencode[sym] = g["gencodeId"]
    if len(symbol_to_gencode) != len(GENES_31):
        missing = sorted(set(GENES_31) - set(symbol_to_gencode.keys()))
        raise RuntimeError(f"Failed to resolve GTEx v8 GENCODE IDs for: {missing}")
    entries.append(write_json_cached(
        {"symbol_to_gencode": symbol_to_gencode, "data": ref_genes},
        out_dir / "reference_genes_31.json",
        ref_gene_url,
    ))

    # Fetch medianGeneExpression across all 54 tissues in clean batches of 8 genes
    mge_url = "https://gtexportal.org/api/v2/expression/medianGeneExpression"
    gencode_list = [symbol_to_gencode[s] for s in GENES_31]
    all_mge: list[dict[str, Any]] = []
    for i in range(0, len(gencode_list), 8):
        batch = gencode_list[i : i + 8]
        batch_data = fetch_gtex_paginated(mge_url, {
            "gencodeId": batch,
            "datasetId": "gtex_v8",
        })
        all_mge.extend(batch_data)
    entries.append(write_json_cached(
        {"data": all_mge},
        out_dir / "median_gene_expression_31genes.json",
        mge_url + "?datasetId=gtex_v8",
    ))
    return entries


def fetch_gse276143(force: bool) -> list[dict[str, Any]]:
    print("[2/8] Fetching GEO GSE276143 (6 replicates)...")
    out_dir = RAW_DIR / "gse276143"
    base = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE276nnn/GSE276143/suppl"
    tasks = [
        (f"{base}/GSE276143_T0_INCLUSION_TABLE_rep{rep}.tab.gz", out_dir / f"GSE276143_T0_INCLUSION_TABLE_rep{rep}.tab.gz")
        for rep in range(1, 7)
    ]
    entries = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        futs = [ex.submit(download_binary_cached, url, path, force) for url, path in tasks]
        for fut in concurrent.futures.as_completed(futs):
            entries.append(fut.result())
    entries.sort(key=lambda x: x["relpath"])
    return entries


def fetch_refseq_uniprot(force: bool) -> list[dict[str, Any]]:
    print("[3/8] Fetching NCBI RefSeq NC_000005.10 & UniProt...")
    out_dir = RAW_DIR / "refseq_uniprot"
    entries: list[dict[str, Any]] = []

    refseq_url = (
        "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
        "?db=nuccore&id=NC_000005.10&seq_start=173932440&seq_stop=173945150"
        "&strand=1&rettype=fasta&retmode=text"
    )
    entries.append(download_binary_cached(
        refseq_url,
        out_dir / "NC_000005.10_173932440_173945150.fasta",
        force=force,
        sleep_before=0.35,
    ))

    for acc in UNIPROT_ACCESSIONS:
        u = f"https://rest.uniprot.org/uniprotkb/{acc}.json"
        entries.append(download_binary_cached(
            u,
            out_dir / f"uniprot_{acc}.json",
            force=force,
            sleep_before=0.15,
        ))
    return entries


def fetch_chembl_v35(force: bool) -> list[dict[str, Any]]:
    print("[4/8] Fetching ChEMBL v35 experimental human Ki...")
    out_dir = RAW_DIR / "chembl_v35"
    entries: list[dict[str, Any]] = []

    status_path = out_dir / "chembl_status.json"
    entries.append(download_binary_cached(
        "https://www.ebi.ac.uk/chembl/api/data/status.json",
        status_path,
        force=force,
    ))

    targets_path = out_dir / "chembl_targets_7.json"
    if not force and targets_path.exists() and targets_path.stat().st_size > 0:
        entries.append({
            "relpath": targets_path.relative_to(RAW_DIR).as_posix(),
            "url": "https://www.ebi.ac.uk/chembl/api/data/target.json",
            "bytes": targets_path.stat().st_size,
            "sha256": sha256_file(targets_path),
            "cached": True,
        })
    else:
        t_url = "https://www.ebi.ac.uk/chembl/api/data/target.json?target_chembl_id__in=" + ",".join(CHEMBL_TARGETS.values())
        t_res = http_get_json(t_url)
        entries.append(write_json_cached(t_res, targets_path, t_url))

    target_csv = ",".join(CHEMBL_TARGETS.values())
    for drug_name, mol_id in CHEMBL_DRUGS.items():
        act_path = out_dir / f"chembl_ki_{drug_name}_{mol_id}.json"
        base_url = (
            f"https://www.ebi.ac.uk/chembl/api/data/activity.json"
            f"?molecule_chembl_id={mol_id}"
            f"&target_chembl_id__in={target_csv}"
            f"&standard_type=Ki&standard_units=nM&standard_relation=%3D&limit=1000"
        )
        if not force and act_path.exists() and act_path.stat().st_size > 0:
            entries.append({
                "relpath": act_path.relative_to(RAW_DIR).as_posix(),
                "url": base_url,
                "bytes": act_path.stat().st_size,
                "sha256": sha256_file(act_path),
                "cached": True,
            })
            continue
        all_acts = []
        url = base_url
        while url:
            res = http_get_json(url, sleep_before=0.1)
            all_acts.extend(res.get("activities", []))
            nxt = res.get("page_meta", {}).get("next")
            url = ("https://www.ebi.ac.uk" + nxt) if nxt else None
        entries.append(write_json_cached(
            {"drug_name": drug_name, "molecule_chembl_id": mol_id, "activities": all_acts},
            act_path,
            base_url,
        ))
    return entries


def fetch_string_v12(force: bool) -> list[dict[str, Any]]:
    print("[5/8] Fetching STRING v12 27-node human network...")
    out_dir = RAW_DIR / "string_v12"
    entries: list[dict[str, Any]] = []

    entries.append(download_binary_cached(
        "https://string-db.org/api/json/version",
        out_dir / "string_version.json",
        force=force,
    ))

    ids_url = "https://string-db.org/api/json/get_string_ids?" + urllib.parse.urlencode({
        "identifiers": "\r".join(STRING_NODES_27),
        "species": 9606,
        "limit": 1,
    })
    entries.append(download_binary_cached(
        ids_url,
        out_dir / "string_v12_resolve_27nodes.json",
        force=force,
    ))

    net_url = "https://string-db.org/api/json/network?" + urllib.parse.urlencode({
        "identifiers": "\r".join(STRING_NODES_27),
        "species": 9606,
        "required_score": 400,
    })
    entries.append(download_binary_cached(
        net_url,
        out_dir / "string_v12_network_27nodes.json",
        force=force,
    ))
    return entries


def fetch_gse138082(force: bool) -> list[dict[str, Any]]:
    print("[6/8] Fetching GEO GSE138082...")
    out_dir = RAW_DIR / "gse138082"
    entries = [
        download_binary_cached(
            "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE138nnn/GSE138082/matrix/GSE138082_series_matrix.txt.gz",
            out_dir / "GSE138082_series_matrix.txt.gz",
            force=force,
        ),
        download_binary_cached(
            "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE138nnn/GSE138082/suppl/GSE138082_Subfields_Counts.txt.gz",
            out_dir / "GSE138082_Subfields_Counts.txt.gz",
            force=force,
        ),
    ]
    return entries


def fetch_gse174407(force: bool) -> list[dict[str, Any]]:
    print("[7/8] Fetching GEO GSE174407 (116 NeuN+_RNA files + HGNC mapping)...")
    out_dir = RAW_DIR / "gse174407"
    rna_dir = out_dir / "rna_counts"
    hgnc_dir = RAW_DIR / "hgnc"
    entries: list[dict[str, Any]] = []

    entries.append(download_binary_cached(
        "https://storage.googleapis.com/public-download-files/hgnc/tsv/tsv/hgnc_complete_set.txt",
        hgnc_dir / "hgnc_complete_set.txt",
        force=force,
    ))
    entries.append(download_binary_cached(
        "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE174nnn/GSE174407/matrix/GSE174407_series_matrix.txt.gz",
        out_dir / "GSE174407_series_matrix.txt.gz",
        force=force,
    ))
    entries.append(download_binary_cached(
        "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE174nnn/GSE174407/suppl/filelist.txt",
        out_dir / "filelist.txt",
        force=force,
    ))

    # Extract exact 116 NeuN+_RNA URLs from cached series_matrix.txt.gz
    import gzip as gz
    sm_text = gz.decompress((out_dir / "GSE174407_series_matrix.txt.gz").read_bytes()).decode("utf-8", errors="replace")
    suppl_urls: list[str] = []
    for line in sm_text.splitlines():
        if line.startswith("!Sample_supplementary_file"):
            for cell in line.split("\t")[1:]:
                u = cell.strip().strip('"')
                if "NeuN+_RNA" in u and u.endswith(".txt.gz"):
                    if u.startswith("ftp://"):
                        u = "https://" + u[len("ftp://"):]
                    suppl_urls.append(u)
    suppl_urls = sorted(set(suppl_urls))
    if len(suppl_urls) != 116:
        raise RuntimeError(f"Expected 116 NeuN+_RNA URLs in GSE174407, found {len(suppl_urls)}")

    tasks = [(u, rna_dir / Path(urllib.parse.urlparse(u).path).name) for u in suppl_urls]
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        futs = [ex.submit(download_binary_cached, url, path, force) for url, path in tasks]
        for fut in concurrent.futures.as_completed(futs):
            entries.append(fut.result())
    entries.sort(key=lambda x: x["relpath"])
    return entries


def fetch_cross_species(force: bool) -> list[dict[str, Any]]:
    print("[8/8] Fetching GSE163161, GSE315204, GSE67755 (+GPL11533)...")
    tasks = [
        (
            "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE163nnn/GSE163161/matrix/GSE163161_series_matrix.txt.gz",
            RAW_DIR / "gse163161" / "GSE163161_series_matrix.txt.gz",
        ),
        (
            "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE163nnn/GSE163161/suppl/GSE163161_Processed_data.csv.gz",
            RAW_DIR / "gse163161" / "GSE163161_Processed_data.csv.gz",
        ),
        (
            "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE315nnn/GSE315204/matrix/GSE315204_series_matrix.txt.gz",
            RAW_DIR / "gse315204" / "GSE315204_series_matrix.txt.gz",
        ),
        (
            "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE315nnn/GSE315204/suppl/GSE315204_rawcounts.csv.gz",
            RAW_DIR / "gse315204" / "GSE315204_rawcounts.csv.gz",
        ),
        (
            "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE67nnn/GSE67755/matrix/GSE67755-GPL11533_series_matrix.txt.gz",
            RAW_DIR / "gse67755" / "GSE67755-GPL11533_series_matrix.txt.gz",
        ),
        (
            "https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL11nnn/GPL11533/annot/GPL11533.annot.gz",
            RAW_DIR / "gse67755" / "GPL11533.annot.gz",
        ),
    ]
    entries = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        futs = [ex.submit(download_binary_cached, url, path, force) for url, path in tasks]
        for fut in concurrent.futures.as_completed(futs):
            entries.append(fut.result())
    entries.sort(key=lambda x: x["relpath"])
    return entries


def validate_manifest() -> int:
    if not MANIFEST_PATH.exists():
        raise FileNotFoundError(f"Manifest not found: {MANIFEST_PATH}")
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    files = manifest.get("files", [])
    if not files:
        raise RuntimeError("Manifest contains zero files")
    verified = 0
    for rec in files:
        fpath = RAW_DIR / rec["relpath"]
        if not fpath.exists():
            raise FileNotFoundError(f"Missing raw file: {fpath}")
        actual_bytes = fpath.stat().st_size
        if actual_bytes == 0 or actual_bytes != rec["bytes"]:
            raise RuntimeError(f"Byte mismatch for {rec['relpath']}: expected {rec['bytes']}, got {actual_bytes}")
        actual_sha = sha256_file(fpath)
        if actual_sha != rec["sha256"]:
            raise RuntimeError(f"SHA256 mismatch for {rec['relpath']}: expected {rec['sha256']}, got {actual_sha}")
        verified += 1
    print(f"[SKIP-DOWNLOAD VERIFIED] All {verified} raw files match SHA256 manifest ({MANIFEST_PATH}).")
    return verified


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch and verify public multi-omics datasets.")
    parser.add_argument(
        "--skip-download",
        action="store_true",
        help="Skip all network calls and verify local raw files against sha256_manifest.json.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Re-download all files even if cached locally.",
    )
    args = parser.parse_args()

    RAW_DIR.mkdir(parents=True, exist_ok=True)
    if args.skip_download:
        validate_manifest()
        return 0

    all_entries: list[dict[str, Any]] = []
    all_entries.extend(fetch_gtex_v8(args.force))
    all_entries.extend(fetch_gse276143(args.force))
    all_entries.extend(fetch_refseq_uniprot(args.force))
    all_entries.extend(fetch_chembl_v35(args.force))
    all_entries.extend(fetch_string_v12(args.force))
    all_entries.extend(fetch_gse138082(args.force))
    all_entries.extend(fetch_gse174407(args.force))
    all_entries.extend(fetch_cross_species(args.force))

    all_entries.sort(key=lambda x: x["relpath"])
    manifest = {
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "total_files": len(all_entries),
        "total_bytes": sum(e["bytes"] for e in all_entries),
        "files": all_entries,
    }
    MANIFEST_PATH.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"[DONE] Cached {manifest['total_files']} files ({manifest['total_bytes'] / (1024**2):.2f} MB) -> {MANIFEST_PATH}")
    validate_manifest()
    return 0


if __name__ == "__main__":
    sys.exit(main())
