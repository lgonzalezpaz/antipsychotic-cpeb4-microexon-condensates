#!/usr/bin/env python3
"""Verify and audit the primary literature bibliography via NCBI PubMed E-utilities and CrossRef API.

Queries NCBI PubMed (`esearch`, `esummary`, `efetch` XML) and CrossRef (`works/<doi>`)
with polite rate-limiting (`time.sleep(0.35)`), verifies HTTP 200 status for all
entries, resolves CrossRef DOIs/article identifiers where omitted from PubMed XML,
audits abstract-to-claim alignment programmatically, and exports:
  - data/verified_references.json
  - results/tables/verified_references_audit.csv
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUT_JSON = PROJECT_ROOT / "data" / "verified_references.json"
OUT_CSV = PROJECT_ROOT / "results" / "tables" / "verified_references_audit.csv"

USER_AGENT = "AntipsychoticCPEB4LitVerifier/1.0 (mailto:bioinformatics@example.org)"
RATE_LIMIT_SEC = 0.35

# Curated 55-reference bibliography covering all 5 mechanistic and dataset domains
CURATED_REFERENCES: list[dict[str, Any]] = [
    # Domain 1: CPEB4 microexon 4, ASD, SCZ, phase separation, SSO therapy & modeling
    {
        "key": "parras_2018",
        "domain": "1_CPEB4_Microexon_Condensates",
        "pmid": "30111840",
        "supported_claims": (
            "CPEB4 binds transcripts of most high-confidence ASD risk genes; idiopathic ASD brains show "
            "decreased inclusion of CPEB4 neuron-specific microexon 4, leading to mRNA deadenylation, "
            "reduced risk-gene protein expression, and ASD-like phenotypes in mice."
        ),
        "required_term_groups": [["cpeb4"], ["microexon"], ["autism", "asd"], ["poly(a)", "deadenylation"]],
    },
    {
        "key": "olla_2023",
        "domain": "1_CPEB4_Microexon_Condensates",
        "pmid": "36958377",
        "supported_claims": (
            "CPEB4 microexon 4 inclusion is reduced in schizophrenia (SCZ) brains and correlates with "
            "reduced protein levels of CPEB4-target SCZ genes specifically in antipsychotic-free probands; "
            "mild CPEB4Delta4 overexpression in mice lowers target SCZ proteins and produces SCZ-like behaviors."
        ),
        "required_term_groups": [["cpeb4"], ["schizophrenia", "scz"], ["microexon", "exon 4"], ["antipsychotic"]],
    },
    {
        "key": "garcia_cabau_2025",
        "domain": "1_CPEB4_Microexon_Condensates",
        "pmid": "39633052",
        "supported_claims": (
            "Neuronal CPEB4 forms condensates that dissolve upon depolarization to switch from translational "
            "repression to activation; heterotypic interactions between microexon 4 and a histidine cluster "
            "compete with homotypic histidine interactions to prevent irreversible aggregation."
        ),
        "required_term_groups": [["cpeb4"], ["microexon"], ["condensates", "aggregation"], ["histidine"], ["depolarization"]],
    },
    {
        "key": "martinez_pizarro_2025",
        "domain": "1_CPEB4_Microexon_Condensates",
        "pmid": "41267683",
        "supported_claims": (
            "Splice-switching oligonucleotides (SSOs) targeting the downstream 3' splice site of exon 5 "
            "dose-dependently increase CPEB4 microexon 4 inclusion and rescue AUTS2/DYRK1A protein levels, "
            "whereas intronic SSOs blocking hnRNPC reduce microexon 4 inclusion."
        ),
        "required_term_groups": [["cpeb4"], ["microexon"], ["oligonucleotides", "ssos"], ["hnrnpc"], ["auts2"]],
    },
    {
        "key": "guillen_boixet_2016",
        "domain": "1_CPEB4_Microexon_Condensates",
        "pmid": "27802129",
        "supported_claims": (
            "Unphosphorylated CPEB4 phase separates into inactive liquid-like droplets via its N-terminal "
            "intrinsically disordered region, whereas ERK2/Cdk1-mediated hyperphosphorylation keeps CPEB4 "
            "in an active monomeric state."
        ),
        "required_term_groups": [["cpeb4"], ["erk2", "cdk1"], ["phosphorylation", "hyperphosphorylation"], ["droplets", "phase separates"]],
    },
    {
        "key": "duran_arque_2022",
        "domain": "1_CPEB4_Microexon_Condensates",
        "pmid": "36096799",
        "supported_claims": (
            "Comparative analysis of vertebrate CPEB1-4 defines CPEB2-4 as a subfamily regulated by "
            "multiple proline-directed phosphorylations controlling liquid-liquid phase separation and "
            "CCR4-NOT recruitment."
        ),
        "required_term_groups": [["cpeb4", "cpeb2-4", "cpeb"], ["phase separation"], ["phosphorylations", "phosphorylation"], ["ccr4-not"]],
    },
    {
        "key": "huang_2023",
        "domain": "1_CPEB4_Microexon_Condensates",
        "pmid": "37131078",
        "supported_claims": (
            "Authoritative synthesis by Huang, Mendez, Fernandez, and Richter establishing vertebrate CPEB1-4 "
            "translational control via cytoplasmic polyadenylation in synaptic plasticity and brain disorders."
        ),
        "required_term_groups": [["cpeb"], ["polyadenylation"], ["synaptic plasticity"], ["translation"]],
    },
    {
        "key": "alvarado_2026",
        "domain": "1_CPEB4_Microexon_Condensates",
        "pmid": "42476190",
        "supported_claims": (
            "Cross-scale physical framework showing CPEB4 microexon 4 has weaker cis-regulatory support than "
            "microexon 3 under transcriptional kinetic pressure, while macromolecular crowding favors Delta4 "
            "homotypic self-association."
        ),
        "required_term_groups": [["cpeb4"], ["microexon 4", "me4"], ["kinetic"], ["crowding"]],
    },
    {
        "key": "gonzalez_paz_2026",
        "domain": "1_CPEB4_Microexon_Condensates",
        "pmid": "41581680",
        "supported_claims": (
            "Weighted functional impact and coarse-grained molecular dynamics framework modeling cell-type "
            "vulnerability, diffusion, and condensate/aggregate stability of CPEB3 and CPEB4 in ASD."
        ),
        "required_term_groups": [["cpeb4"], ["cpeb3"], ["condensates", "aggregates"], ["autism", "asd"]],
    },
    # Domain 2: Neuronal microexons, SRRM4-SRSF11-RNPS1, RBFOX1, PTBP1/2, hnRNPC, depolarization
    {
        "key": "irimia_2014",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "25525873",
        "supported_claims": (
            "Defines the conserved 3-15 nt neuronal microexon program regulated by nSR100/SRRM4 that "
            "remodels protein interaction domains in neurogenesis and is frequently misregulated in ASD brains."
        ),
        "required_term_groups": [["microexons"], ["nsr100", "srrm4"], ["autism", "autistic"], ["interaction domains"]],
    },
    {
        "key": "calarco_2009",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "19737518",
        "supported_claims": (
            "Identifies neural-specific SR-related protein nSR100 (SRRM4) as a vertebrate-restricted "
            "master regulator of nervous system alternative splicing and neuronal differentiation."
        ),
        "required_term_groups": [["nsr100"], ["alternative splicing"], ["neural", "nervous system"]],
    },
    {
        "key": "raj_2014",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "25219497",
        "supported_claims": (
            "nSR100/SRRM4 binds specialized intronic enhancers between polypyrimidine tracts and 3' splice "
            "sites, recruiting early spliceosome factors to overcome PTBP1-mediated exon silencing."
        ),
        "required_term_groups": [["nsr100", "srrm4"], ["ptbp1"], ["enhancers"], ["spliceosome"]],
    },
    {
        "key": "quesnel_vallieres_2016",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "27984743",
        "supported_claims": (
            "Elevated neuronal activity/depolarization triggers rapid nSR100/SRRM4 loss and microexon "
            "skipping overlapping ASD brains; nSR100-deficient mice show autistic-like synaptic and behavioral phenotypes."
        ),
        "required_term_groups": [["nsr100", "srrm4"], ["microexons", "microexon"], ["neuronal activity"], ["autism", "autistic"]],
    },
    {
        "key": "gonatopoulos_2018",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "30388412",
        "supported_claims": (
            "Genome-wide CRISPR screen identifies SRSF11 and RNPS1 as co-activators partnering with SRRM4 "
            "and a bipartite intronic enhancer to drive spliceosome assembly at neuronal microexons."
        ),
        "required_term_groups": [["srsf11"], ["rnps1"], ["srrm4"], ["microexons"]],
    },
    {
        "key": "gonatopoulos_2020",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "32535349",
        "supported_claims": (
            "Review synthesizing microexon regulatory repertoires, roles in synaptic translation and "
            "neuronal activity, and causal links to ASD and cognitive impairment."
        ),
        "required_term_groups": [["microexons"], ["autism"], ["synaptic"], ["neuronal activity"]],
    },
    {
        "key": "bonnal_2025",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "40775527",
        "supported_claims": (
            "Massively parallel splicing assays of 28,535 variants (GSE276143) show microexon dose "
            "sensitivity to SRRM3/4 depends on core splice-site architecture, length constraints, and "
            "early spliceosomal recruitment efficiency."
        ),
        "required_term_groups": [["microexons", "microexon"], ["srrm3/4", "srrm4"], ["spliceosome", "spliceosomal"], ["sensitivity"]],
    },
    {
        "key": "weyn_vanhentenryck_2014",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "24613350",
        "supported_claims": (
            "Brain HITS-CLIP defines 1,059 direct Rbfox1/2/3 splicing targets via UGCAUG motifs, including "
            "ASD-risk genes, and correlates Rbfox downregulation with ASD splicing alterations."
        ),
        "required_term_groups": [["rbfox"], ["ugcaug"], ["splicing"], ["autism"]],
    },
    {
        "key": "lee_2016",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "26687839",
        "supported_claims": (
            "Nuclear Rbfox1 controls intronic splicing while cytoplasmic Rbfox1 binds 3' UTRs to enhance "
            "mRNA stability and translation of cortical development and ASD-related transcripts."
        ),
        "required_term_groups": [["rbfox1"], ["splicing"], ["translation", "stability"], ["autism"]],
    },
    {
        "key": "vuong_2016",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "27094079",
        "supported_claims": (
            "Reviews mouse genetic evidence establishing specialized RNA-binding protein splicing programs "
            "in both neuronal development and mature synaptic function."
        ),
        "required_term_groups": [["alternative splicing"], ["rna-binding proteins"], ["neuronal", "brain"]],
    },
    {
        "key": "zarnack_2013",
        "domain": "2_Microexon_Splicing_Network",
        "pmid": "23374342",
        "supported_claims": (
            "Quantitative iCLIP demonstrates direct competition between hnRNP C and U2AF65 at poly-U/Alu "
            "tracts to suppress aberrant cryptic exon inclusion."
        ),
        "required_term_groups": [["hnrnp c"], ["u2af65"], ["alu"], ["exonization"]],
    },
    # Domain 3: Kinetic coupling of chromatin, HDAC2, and RNA Pol II elongation to splicing
    {
        "key": "de_la_mata_2003",
        "domain": "3_Chromatin_HDAC2_PolII_Kinetic_Coupling",
        "pmid": "14536091",
        "supported_claims": (
            "Slow RNA Pol II elongation mutant C4 alters alternative exon inclusion in human cells and "
            "Drosophila embryos, providing direct in vivo proof of transcriptional elongation control of splicing."
        ),
        "required_term_groups": [["polymerase ii"], ["elongation"], ["alternative splicing"]],
    },
    {
        "key": "schor_2009",
        "domain": "3_Chromatin_HDAC2_PolII_Kinetic_Coupling",
        "pmid": "19251664",
        "supported_claims": (
            "Neuronal depolarization induces intragenic H3K9 hyperacetylation and chromatin relaxation to "
            "accelerate Pol II elongation and skip NCAM exon 18, mimicked by HDAC inhibition (TSA) and "
            "reversed upon depolarization withdrawal."
        ),
        "required_term_groups": [["depolarization"], ["ncam"], ["elongation"], ["acetylation", "hyper-acetylation"], ["histone deacetylase"]],
    },
    {
        "key": "fong_2014",
        "domain": "3_Chromatin_HDAC2_PolII_Kinetic_Coupling",
        "pmid": "25452276",
        "supported_claims": (
            "Slow and fast RNA Pol II elongation mutants reveal Type I slow-included weak exons and "
            "demonstrate that an optimal Pol II elongation rate governs co-transcriptional splicing."
        ),
        "required_term_groups": [["elongation"], ["polymerase ii"], ["splicing"], ["optimal"]],
    },
    {
        "key": "kornblihtt_2013",
        "domain": "3_Chromatin_HDAC2_PolII_Kinetic_Coupling",
        "pmid": "23385723",
        "supported_claims": (
            "Authoritative review of co-transcriptional kinetic and recruitment coupling linking cell signaling, "
            "chromatin marks, and RNA Pol II elongation to alternative splicing."
        ),
        "required_term_groups": [["alternative splicing"], ["chromatin"], ["transcription"]],
    },
    {
        "key": "kurita_2012",
        "domain": "3_Chromatin_HDAC2_PolII_Kinetic_Coupling",
        "pmid": "22864611",
        "supported_claims": (
            "Chronic atypical antipsychotics upregulate HDAC2 via 5-HT2A receptor antagonism in mouse and "
            "human frontal cortex, reducing promoter histone acetylation and interacting with HDAC inhibitors."
        ),
        "required_term_groups": [["hdac2"], ["antipsychotic", "antipsychotics"], ["5-ht"], ["acetylation"]],
    },
    {
        "key": "zhu_2024",
        "domain": "3_Chromatin_HDAC2_PolII_Kinetic_Coupling",
        "pmid": "38648100",
        "supported_claims": (
            "ChIP-seq (H3K27ac, H3K4me3) and RNA-seq of human SCZ frontal cortex (n=58; GSE174407) "
            "distinguish disease epigenomic alterations reversed by antipsychotics from drug-induced reorganization."
        ),
        "required_term_groups": [["antipsychotic"], ["frontal cortex"], ["schizophrenia"], ["h3k27ac", "epigenomic"]],
    },
    # Domain 4: Antipsychotic pharmacology, GPCRs, PKA/DARPP-32/PP1, AKT/GSK3B, CaMKII, autophagy, turnover, condensates
    {
        "key": "kapur_2000",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "10739409",
        "supported_claims": (
            "PET imaging in first-episode schizophrenia defines striatal D2 occupancy thresholds (>65% clinical "
            "response, >72% prolactin elevation, >78% EPS) and proposes the 'target and trigger' hypothesis."
        ),
        "required_term_groups": [["occupancy"], ["65%"], ["d(2)", "d2"], ["target and trigger"]],
    },
    {
        "key": "meltzer_1989",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "2571717",
        "supported_claims": (
            "Classification of 37 typical and atypical antipsychotics demonstrating that lower D2 pKi and "
            "higher 5-HT2/D2 affinity ratios distinguish atypical from typical agents."
        ),
        "required_term_groups": [["atypical"], ["d-2", "d2"], ["5-ht2", "serotonin"], ["pki"]],
    },
    {
        "key": "greengard_2001",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "11691979",
        "supported_claims": (
            "Defines slow synaptic transmission mediated by GPCR second messengers, protein kinases, "
            "and protein phosphatases over hundreds of milliseconds to minutes."
        ),
        "required_term_groups": [["slow synaptic transmission"], ["second messengers"], ["protein kinases"], ["protein phosphatases"]],
    },
    {
        "key": "nishi_1997",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "9334390",
        "supported_claims": (
            "Demonstrates bidirectional D1/D2 control of DARPP-32 phosphorylation in striatal neurons and "
            "shows that the D2 antagonist raclopride increases DARPP-32 phosphorylation."
        ),
        "required_term_groups": [["darpp-32"], ["d2", "d2-like"], ["raclopride"], ["phosphorylation"]],
    },
    {
        "key": "svenningsson_2003",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "14631045",
        "supported_claims": (
            "Demonstrates DARPP-32 multi-site phosphorylation integrates dopaminergic, serotonergic, and "
            "glutamatergic signaling to inhibit PP1 and regulate GSK-3, CREB, and c-Fos."
        ),
        "required_term_groups": [["darpp-32"], ["protein phosphatase-1", "pp1"], ["gsk-3"], ["creb"]],
    },
    {
        "key": "beaulieu_2005",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "16051150",
        "supported_claims": (
            "Establishes that dopamine D2-class receptors regulate Akt via a cAMP-independent "
            "beta-arrestin 2/PP2A scaffolding complex."
        ),
        "required_term_groups": [["d2"], ["akt"], ["beta-arrestin 2"], ["pp2a"]],
    },
    {
        "key": "agid_2003",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "14662555",
        "supported_claims": (
            "Meta-analysis of 42 trials (7,450 patients) demonstrating antipsychotic response initiates in "
            "week 1 and accumulates across weeks 1-4."
        ),
        "required_term_groups": [["antipsychotic"], ["7450"], ["week 1"], ["4 weeks", "treatment weeks"]],
    },
    {
        "key": "hiemke_2018",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "28910830",
        "supported_claims": (
            "AGNP 2017 consensus guidelines defining clinical therapeutic drug monitoring (TDM) plasma "
            "reference concentration windows for antipsychotics and neuropsychiatric agents."
        ),
        "required_term_groups": [["therapeutic drug monitoring", "tdm"], ["arbeitsgemeinschaft", "agnp"], ["guidelines"]],
    },
    {
        "key": "colwill_1996",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "8798720",
        "supported_claims": (
            "SRPK1 and Clk/Sty protein kinases phosphorylate SR splicing factors at distinct Ser-Arg vs "
            "Ser-Pro/Lys motifs to regulate alternative splice-site selection."
        ),
        "required_term_groups": [["srpk1"], ["clk/sty"], ["sr proteins", "splicing factors"], ["phosphorylate"]],
    },
    {
        "key": "zhou_2012",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "22727668",
        "supported_claims": (
            "Akt activation induces SRPK autophosphorylation, Hsp70-to-Hsp90 complex switching, SRPK nuclear "
            "translocation, and SR protein phosphorylation to reprogram alternative splicing."
        ),
        "required_term_groups": [["akt"], ["srpk"], ["alternative splicing"], ["phosphorylation"]],
    },
    {
        "key": "shi_2011",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "21367856",
        "supported_claims": (
            "Cyclic AMP-dependent protein kinase (PKA-Calpha) phosphorylates splicing factor SRSF1 and "
            "promotes alternative exon inclusion in cultured cells and rat brain."
        ),
        "required_term_groups": [["pka"], ["srsf1"], ["alternative splicing"], ["brain"]],
    },
    {
        "key": "rushlow_2009",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "19289156",
        "supported_claims": (
            "Repeated haloperidol, clozapine, risperidone, and D2/D3 antagonism (raclopride) dynamically "
            "modulate CaMKIIalpha, CaMKIV, CaMKKalpha/beta, and calcineurin in rat striatum."
        ),
        "required_term_groups": [["haloperidol"], ["clozapine"], ["camkiialpha", "camk"], ["calcineurin"]],
    },
    {
        "key": "kim_2018_autophagy",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "29079139",
        "supported_claims": (
            "Clozapine induces autophagy in rat frontal cortex via AMPK-Thr172, ULK1-Ser317, and "
            "Beclin1-Ser93 phosphorylation, increasing LC3-II and autophagosome formation."
        ),
        "required_term_groups": [["clozapine"], ["autophagy"], ["ampk"], ["ulk1"], ["frontal cortex"]],
    },
    {
        "key": "hao_2017",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "27711049",
        "supported_claims": (
            "Clozapine modulates glucosylceramide, increases ATG8/LC3 autophagy markers, and promotes "
            "clearance of misfolded protein aggregates (alpha-synuclein, polyQ, mutant alpha1-antitrypsin)."
        ),
        "required_term_groups": [["clozapine"], ["aggregated proteins", "aggregates"], ["lc3", "atg8"], ["autophagy"]],
    },
    {
        "key": "dorrbaum_2018",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "29914620",
        "supported_claims": (
            "Dynamic SILAC proteomics determines half-lives of >5,100 proteins in primary neurons and glia "
            "(<1 to >20 days), demonstrating slow cell-type-dependent neuronal proteome turnover."
        ),
        "required_term_groups": [["silac"], ["half-lives"], ["neurons"], ["turnover"]],
    },
    {
        "key": "mathieson_2018",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "29449567",
        "supported_claims": (
            "Systematic dynamic SILAC profiling measures protein turnover half-lives (10 to >1,000 h) "
            "across primary non-dividing cell types including mouse embryonic neurons."
        ),
        "required_term_groups": [["protein turnover"], ["half-lives"], ["neurons"], ["silac"]],
    },
    {
        "key": "shin_2017",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "28935776",
        "supported_claims": (
            "Reviews thermodynamic and kinetic principles of intracellular liquid-liquid phase separation "
            "and how condensate metastability can drive pathological protein aggregation."
        ),
        "required_term_groups": [["liquid-liquid phase separation"], ["droplets"], ["aggregation"]],
    },
    {
        "key": "alberti_2021",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "33510441",
        "supported_claims": (
            "Reviews how cellular stress, aging, and declining protein quality control drive aberrant "
            "liquid-to-solid condensate conversion and protein aggregation disease."
        ),
        "required_term_groups": [["biomolecular condensates"], ["liquid-liquid phase separation"], ["aggregation"], ["protein quality control"]],
    },
    {
        "key": "patel_2015",
        "domain": "4_Antipsychotic_Pharmacology_Signaling_Proteostasis",
        "pmid": "26317470",
        "supported_claims": (
            "Demonstrates time-dependent liquid-to-solid phase transition ('aging') of LCD RNA-binding "
            "protein FUS droplets into aggregated states accelerated by disease mutations."
        ),
        "required_term_groups": [["fus"], ["liquid-to-solid", "aggregated state"], ["phase"], ["droplets", "compartments"]],
    },
    # Domain 5: Public datasets & bioinformatics resources analyzed
    {
        "key": "gtex_2020",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "32913098",
        "supported_claims": (
            "GTEx v8 atlas analyzing 15,201 RNA-seq samples across 49 human tissues from 838 donors for "
            "tissue-specific gene expression and splicing regulation."
        ),
        "required_term_groups": [["gtex"], ["15,201"], ["838"], ["splicing"]],
    },
    {
        "key": "perez_2021",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "32152472",
        "supported_claims": (
            "Hippocampal subfield (DG, CA3, CA1) RNA-seq in schizophrenia probands stratified by ON- vs "
            "OFF-antipsychotic medication status (GSE138082)."
        ),
        "required_term_groups": [["hippocampal"], ["schizophrenia"], ["antipsychotic"], ["on- and off-antipsychotic", "medication"]],
    },
    {
        "key": "das_2021",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "33497908",
        "supported_claims": (
            "Transcriptome analysis of human iPSC-derived excitatory cortical neurons treated with "
            "therapeutic clozapine (GSE163161) identifying cholesterol biosynthesis upregulation."
        ),
        "required_term_groups": [["clozapine"], ["ipscs", "induced pluripotent stem cells"], ["excitatory"], ["cholesterol"]],
    },
    {
        "key": "kim_2018_gwas",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "28555076",
        "supported_claims": (
            "RNA-seq of mouse brain following chronic haloperidol treatment (GSE67755) demonstrating "
            "significant enrichment of schizophrenia GWAS risk genes."
        ),
        "required_term_groups": [["haloperidol"], ["schizophrenia"], ["gwas"], ["rna sequencing"]],
    },
    {
        "key": "barrett_2013",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "23193258",
        "supported_claims": (
            "NCBI Gene Expression Omnibus (GEO) database specification supporting archived functional "
            "genomics datasets analyzed herein (including GSE315204, released 2026-11-16 without a "
            "PubMed-indexed primary article)."
        ),
        "required_term_groups": [["gene expression omnibus", "geo"], ["repository"], ["sequence"]],
    },
    {
        "key": "zdrazil_2024",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "37933841",
        "supported_claims": (
            "ChEMBL database resource providing curated small-molecule drug bioactivity measurements "
            "(Ki/pKi affinities and action-type annotations)."
        ),
        "required_term_groups": [["chembl"], ["bioactivity"], ["drug"]],
    },
    {
        "key": "szklarczyk_2023",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "36370105",
        "supported_claims": (
            "STRING v12.0 resource integrating physical protein-protein interactions, functional "
            "associations, and co-expression networks."
        ),
        "required_term_groups": [["string"], ["12.0"], ["protein-protein"]],
    },
    {
        "key": "uniprot_2025",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "39552041",
        "supported_claims": (
            "UniProtKB 2025 release providing manually curated protein sequences, domains, and "
            "isoform annotations."
        ),
        "required_term_groups": [["uniprotkb"], ["protein sequences"], ["curate", "curation"]],
    },
    {
        "key": "gandal_2018",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "30545856",
        "supported_claims": (
            "PsychENCODE integrative analysis across 1,695 ASD, schizophrenia, and bipolar brains showing "
            "isoform-level and splicing dysregulation capture the largest disease effects."
        ),
        "required_term_groups": [["1695"], ["isoform"], ["splicing"], ["schizophrenia"], ["asd"]],
    },
    {
        "key": "fromer_2016",
        "domain": "5_Public_Datasets_Bioinformatics_Resources",
        "pmid": "27668389",
        "supported_claims": (
            "CommonMind Consortium DLPFC RNA-seq (258 schizophrenia, 279 control brains) linking "
            "schizophrenia polygenic risk to expression and co-expression modules."
        ),
        "required_term_groups": [["commonmind"], ["258"], ["279"], ["schizophrenia"]],
    },
]


def http_get_bytes(url: str, max_retries: int = 5) -> tuple[int, bytes]:
    """Perform an HTTP GET request with polite retry on transient 429/5xx errors."""
    for attempt in range(max_retries):
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=25) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as err:
            if err.code in (429, 500, 502, 503, 504) and attempt < max_retries - 1:
                time.sleep(1.5 * (attempt + 1))
                continue
            raise
    raise RuntimeError(f"Failed to fetch {url}")


def clean_text(text: str | None) -> str:
    """Normalize internal whitespace and strip surrounding spaces."""
    if not text:
        return ""
    return re.sub(r"\s+", " ", text).strip()


def normalize_words(text: str) -> set[str]:
    """Extract lowercase alphanumeric tokens for cross-source title comparison."""
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def jaccard_similarity(a: str, b: str) -> float:
    """Compute token-level Jaccard similarity between two titles."""
    wa, wb = normalize_words(a), normalize_words(b)
    if not wa or not wb:
        return 0.0
    return len(wa & wb) / len(wa | wb)


def overlap_similarity(a: str, b: str) -> float:
    """Compute token-level Szymkiewicz-Simpson overlap (handles CrossRef omitted subtitles)."""
    wa, wb = normalize_words(a), normalize_words(b)
    if not wa or not wb:
        return 0.0
    return len(wa & wb) / min(len(wa), len(wb))


def verify_pubmed_esearch_and_esummary(pmids: list[str]) -> tuple[dict[str, int], dict[str, int]]:
    """Verify PMID existence via NCBI esearch and esummary."""
    esummary_status: dict[str, int] = {}
    esearch_status: dict[str, int] = {}

    for i in range(0, len(pmids), 30):
        chunk = ",".join(pmids[i : i + 30])
        url_sum = (
            f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
            f"?db=pubmed&id={chunk}&retmode=json"
        )
        status, raw = http_get_bytes(url_sum)
        data = json.loads(raw.decode("utf-8"))
        uids = set(data.get("result", {}).get("uids", []))
        for pmid in pmids[i : i + 30]:
            esummary_status[pmid] = status if pmid in uids else 404
        time.sleep(RATE_LIMIT_SEC)

    for pmid in pmids:
        url_es = (
            f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
            f"?db=pubmed&term={pmid}[PMID]&retmode=json"
        )
        status, raw = http_get_bytes(url_es)
        idlist = json.loads(raw.decode("utf-8")).get("esearchresult", {}).get("idlist", [])
        esearch_status[pmid] = status if pmid in idlist else 404
        time.sleep(RATE_LIMIT_SEC)

    return esearch_status, esummary_status


def fetch_pubmed_xml_records(pmids: list[str]) -> tuple[dict[str, dict[str, Any]], dict[str, int]]:
    """Batch-fetch full PubMed XML records via efetch and parse bibliographic fields."""
    records: dict[str, dict[str, Any]] = {}
    efetch_status: dict[str, int] = {}

    for i in range(0, len(pmids), 30):
        chunk = ",".join(pmids[i : i + 30])
        url = (
            f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
            f"?db=pubmed&id={chunk}&retmode=xml"
        )
        status, raw = http_get_bytes(url)
        root = ET.fromstring(raw)
        for art in root.findall(".//PubmedArticle"):
            pmid = clean_text(art.findtext(".//MedlineCitation/PMID"))
            if not pmid:
                continue
            efetch_status[pmid] = status

            title_el = art.find(".//ArticleTitle")
            title = clean_text("".join(title_el.itertext())) if title_el is not None else ""
            journal_iso = clean_text(
                art.findtext(".//Journal/ISOAbbreviation")
                or art.findtext(".//MedlineJournalInfo/MedlineTA")
                or art.findtext(".//Journal/Title")
            )
            year = clean_text(
                art.findtext(".//JournalIssue/PubDate/Year")
                or art.findtext(".//JournalIssue/PubDate/MedlineDate")
            )[:4]
            volume = clean_text(art.findtext(".//JournalIssue/Volume"))
            issue = clean_text(art.findtext(".//JournalIssue/Issue"))
            pages = clean_text(art.findtext(".//Pagination/MedlinePgn"))

            eloc_pii = ""
            for el in art.findall(".//Article/ELocationID"):
                if el.attrib.get("EIdType") == "pii" and el.attrib.get("ValidYN", "Y") == "Y":
                    eloc_pii = clean_text(el.text)

            authors_list: list[str] = []
            for author in art.findall(".//AuthorList/Author"):
                last = clean_text(author.findtext("LastName"))
                initials = clean_text(author.findtext("Initials"))
                collective = clean_text(author.findtext("CollectiveName"))
                if last:
                    authors_list.append(f"{last} {initials}".strip())
                elif collective:
                    authors_list.append(collective)

            doi, pmcid = "", ""
            for aid in art.findall(".//PubmedData/ArticleIdList/ArticleId"):
                id_type = aid.attrib.get("IdType")
                if id_type == "doi":
                    doi = clean_text(aid.text)
                elif id_type == "pmc":
                    pmcid = clean_text(aid.text)

            abs_parts = [clean_text("".join(ab.itertext())) for ab in art.findall(".//Abstract/AbstractText")]
            abstract_full = " ".join(p for p in abs_parts if p)

            records[pmid] = {
                "pmid": pmid,
                "pmcid": pmcid,
                "doi": doi,
                "authors_list": authors_list,
                "title": title,
                "journal_iso": journal_iso,
                "year": year,
                "volume": volume,
                "issue": issue,
                "pages": pages,
                "eloc_pii": eloc_pii,
                "abstract_full": abstract_full,
            }
        time.sleep(RATE_LIMIT_SEC)

    return records, efetch_status


def resolve_crossref_doi_by_title(title: str, first_author: str) -> str:
    """Resolve missing DOI from CrossRef by exact title and author search."""
    last_name = first_author.split()[0] if first_author else ""
    url = (
        f"https://api.crossref.org/works?rows=3"
        f"&query.title={urllib.parse.quote(title)}"
        f"&query.author={urllib.parse.quote(last_name)}"
    )
    status, raw = http_get_bytes(url)
    if status != 200:
        return ""
    items = json.loads(raw.decode("utf-8")).get("message", {}).get("items", [])
    for item in items:
        cr_titles = item.get("title", [])
        if cr_titles and jaccard_similarity(title, cr_titles[0]) >= 0.75:
            return clean_text(item.get("DOI"))
    return ""


def query_crossref_work(doi: str, pubmed_title: str) -> tuple[int, dict[str, Any]]:
    """Query CrossRef API works/<doi> and compute title consistency."""
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi, safe='/')}"
    status, raw = http_get_bytes(url)
    msg = json.loads(raw.decode("utf-8")).get("message", {})
    cr_parts = list(msg.get("title", [])) + list(msg.get("subtitle", []))
    cr_title = clean_text(" ".join(cr_parts))
    jaccard = jaccard_similarity(pubmed_title, cr_title)
    overlap = overlap_similarity(pubmed_title, cr_title)
    cr_page = clean_text(msg.get("page") or msg.get("article-number"))
    return status, {
        "cr_title": cr_title,
        "title_match_score": round(max(jaccard, overlap), 4),
        "title_jaccard": round(jaccard, 4),
        "title_overlap": round(overlap, 4),
        "cr_page": cr_page,
    }


def format_vancouver_authors(authors_list: list[str]) -> str:
    """Format authors in Vancouver style (up to 6 authors + ', et al.')."""
    if len(authors_list) > 6:
        return ", ".join(authors_list[:6]) + ", et al."
    return ", ".join(authors_list)


def format_vancouver_citation(rec: dict[str, Any]) -> str:
    """Construct complete Vancouver-style citation string without double punctuation."""
    authors_clean = rec["vancouver_authors"].rstrip(".")
    title_clean = rec["title"].rstrip(".")
    loc = rec["year"]
    if rec["volume"]:
        loc += f";{rec['volume']}"
        if rec["issue"]:
            loc += f"({rec['issue']})"
    if rec["pages"]:
        loc += f":{rec['pages']}"
    doi_part = f" doi:{rec['doi']}." if rec["doi"] else ""
    return f"{authors_clean}. {title_clean}. {rec['journal_iso']}. {loc}.{doi_part}"


def audit_claim_alignment(title: str, abstract: str, term_groups: list[list[str]]) -> tuple[bool, list[list[str]]]:
    """Verify non-empty abstract and ensure every required concept group is present."""
    haystack = f"{title} {abstract}".lower()
    if not abstract.strip():
        return False, term_groups
    missing: list[list[str]] = []
    for group in term_groups:
        if not any(term.lower() in haystack for term in group):
            missing.append(group)
    return len(missing) == 0, missing


def check_gse315204_geo_status() -> dict[str, Any]:
    """Verify live NCBI GDS status for GSE315204 to confirm publication linkage."""
    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=gds&id=200315204&retmode=json"
    status, raw = http_get_bytes(url)
    doc = json.loads(raw.decode("utf-8")).get("result", {}).get("200315204", {})
    return {
        "gds_http_status": status,
        "accession": doc.get("accession"),
        "title": doc.get("title"),
        "pdat": doc.get("pdat"),
        "n_samples": doc.get("n_samples"),
        "pubmedids": doc.get("pubmedids", []),
    }


def main() -> None:
    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)

    pmids = [entry["pmid"] for entry in CURATED_REFERENCES]
    assert len(pmids) == len(set(pmids)), "Duplicate PMIDs detected in curated manifest!"

    print(f"Verifying {len(pmids)} curated references against NCBI PubMed E-utilities and CrossRef API...")
    esearch_status, esummary_status = verify_pubmed_esearch_and_esummary(pmids)
    pubmed_records, efetch_status = fetch_pubmed_xml_records(pmids)

    verified_records: list[dict[str, Any]] = []
    audit_rows: list[dict[str, Any]] = []
    failures: list[str] = []

    for entry in CURATED_REFERENCES:
        pmid = entry["pmid"]
        rec = pubmed_records.get(pmid)
        if rec is None:
            failures.append(f"{entry['key']} (PMID {pmid}): Missing from PubMed efetch XML")
            continue

        doi = rec["doi"]
        if not doi:
            doi = resolve_crossref_doi_by_title(rec["title"], rec["authors_list"][0] if rec["authors_list"] else "")
            time.sleep(RATE_LIMIT_SEC)

        cr_status, cr_info = (0, {"cr_title": "", "title_match_score": 0.0, "title_jaccard": 0.0, "title_overlap": 0.0, "cr_page": ""})
        if doi:
            cr_status, cr_info = query_crossref_work(doi, rec["title"])
            time.sleep(RATE_LIMIT_SEC)

        pages = rec["pages"] or cr_info["cr_page"] or rec["eloc_pii"]
        vancouver_authors = format_vancouver_authors(rec["authors_list"])
        abstract_full = rec["abstract_full"]
        abstract_excerpt = abstract_full if len(abstract_full) <= 500 else abstract_full[:497].rstrip() + "..."

        claim_passed, missing_groups = audit_claim_alignment(rec["title"], abstract_full, entry["required_term_groups"])

        record_obj: dict[str, Any] = {
            "key": entry["key"],
            "pmid": pmid,
            "pmcid": rec["pmcid"],
            "doi": doi,
            "authors_list": rec["authors_list"],
            "vancouver_authors": vancouver_authors,
            "title": rec["title"],
            "journal_iso": rec["journal_iso"],
            "year": rec["year"],
            "volume": rec["volume"],
            "issue": rec["issue"],
            "pages": pages,
            "vancouver_citation": "",
            "abstract_excerpt": abstract_excerpt,
            "supported_claims": entry["supported_claims"],
            "domain": entry["domain"],
            "pubmed_esearch_http_status": esearch_status.get(pmid, 0),
            "pubmed_esummary_http_status": esummary_status.get(pmid, 0),
            "pubmed_efetch_http_status": efetch_status.get(pmid, 0),
            "crossref_http_status": cr_status,
            "title_match_score": cr_info["title_match_score"],
            "claim_audit_passed": claim_passed,
        }
        record_obj["vancouver_citation"] = format_vancouver_citation(record_obj)
        verified_records.append(record_obj)

        http_ok = (
            record_obj["pubmed_esearch_http_status"] == 200
            and record_obj["pubmed_esummary_http_status"] == 200
            and record_obj["pubmed_efetch_http_status"] == 200
            and record_obj["crossref_http_status"] == 200
        )
        title_ok = cr_info["title_match_score"] >= 0.85

        if not (http_ok and title_ok and claim_passed):
            msg = (
                f"AUDIT FAILURE [{entry['key']} | PMID {pmid}]: http_ok={http_ok}, "
                f"title_match={cr_info['title_match_score']}, claim_passed={claim_passed}, "
                f"missing_groups={missing_groups}"
            )
            failures.append(msg)
            print(msg)
        else:
            print(f"  PASS [{entry['key']}] PMID={pmid} DOI={doi} (title_sim={cr_info['title_match_score']:.2f})")

        audit_rows.append(
            {
                "key": record_obj["key"],
                "domain": record_obj["domain"],
                "pmid": pmid,
                "pmcid": record_obj["pmcid"],
                "doi": doi,
                "vancouver_authors": vancouver_authors,
                "title": record_obj["title"],
                "journal_iso": record_obj["journal_iso"],
                "year": record_obj["year"],
                "volume": record_obj["volume"],
                "issue": record_obj["issue"],
                "pages": pages,
                "pubmed_esearch_http_status": record_obj["pubmed_esearch_http_status"],
                "pubmed_esummary_http_status": record_obj["pubmed_esummary_http_status"],
                "pubmed_efetch_http_status": record_obj["pubmed_efetch_http_status"],
                "crossref_http_status": cr_status,
                "title_match_score": cr_info["title_match_score"],
                "claim_audit_passed": claim_passed,
                "supported_claims": record_obj["supported_claims"],
                "vancouver_citation": record_obj["vancouver_citation"],
            }
        )

    gse_status = check_gse315204_geo_status()
    print(
        f"\nGEO GSE315204 check: HTTP={gse_status['gds_http_status']}, pdat={gse_status['pdat']}, "
        f"n_samples={gse_status['n_samples']}, linked_pubmedids={gse_status['pubmedids']}"
    )

    with OUT_JSON.open("w", encoding="utf-8") as f:
        json.dump(verified_records, f, indent=2, ensure_ascii=False)

    df_audit = pd.DataFrame(audit_rows)
    df_audit.to_csv(OUT_CSV, index=False, encoding="utf-8")

    print(f"\nExported {len(verified_records)} verified references to {OUT_JSON}")
    print(f"Exported audit table to {OUT_CSV}")

    if failures:
        raise SystemExit(f"Verification failed for {len(failures)} references:\n" + "\n".join(failures))
    print("ALL REFERENCES PASSED 100% HTTP 200, CROSSREF TITLE, AND CLAIM-ABSTRACT ALIGNMENT CHECKS.")


if __name__ == "__main__":
    main()
