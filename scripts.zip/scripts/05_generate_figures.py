#!/usr/bin/env python3
"""
Phase 4: Publication-Grade Figures (Figure1-6, FigureS1-S3) & Tables (Table1-4, TableS1-S4)
=============================================================================================
Generates 600 DPI PNG + vector SVG + PDF figures and curated summary tables strictly from
verified Phase 1 bioinformatics outputs and Phase 2 calibrated RC-KTF model outputs.
"""

from __future__ import annotations

import importlib.util
import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
import networkx as nx
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.stats import spearmanr

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_PROCESSED = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results"
TABLES_DIR = RESULTS_DIR / "tables"
FIGURES_DIR = PROJECT_ROOT / "figures"
FIGURES_DIR.mkdir(parents=True, exist_ok=True)
TABLES_DIR.mkdir(parents=True, exist_ok=True)

# Load Phase 2 pure functions dynamically (no code duplication!)
_spec = importlib.util.spec_from_file_location(
    "rc_ktf_mod", PROJECT_ROOT / "scripts" / "03_mechanistic_model_and_validation.py"
)
rc = importlib.util.module_from_spec(_spec)
assert _spec.loader is not None
_spec.loader.exec_module(rc)

# Okabe-Ito colorblind-safe palette
OI = {
    "blue": "#0072B2",
    "vermilion": "#D55E00",
    "green": "#009E73",
    "orange": "#E69F00",
    "purple": "#CC79A7",
    "sky": "#56B4E9",
    "yellow": "#F0E442",
    "black": "#222222",
    "grey": "#7A7A7A",
    "lightgrey": "#D9D9D9",
}

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans", "Helvetica"],
    "font.size": 8.5,
    "axes.titlesize": 9.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 8.5,
    "xtick.labelsize": 7.8,
    "ytick.labelsize": 7.8,
    "legend.fontsize": 7.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.8,
    "savefig.dpi": 600,
    "svg.fonttype": "none",
    "pdf.fonttype": 42,
})


def save_fig(fig: plt.Figure, stem: str) -> None:
    for ext in ("png", "svg", "pdf"):
        out = FIGURES_DIR / f"{stem}.{ext}"
        kw = {"dpi": 600} if ext == "png" else {}
        fig.savefig(out, bbox_inches="tight", pad_inches=0.14, facecolor="white", **kw)
    plt.close(fig)
    print(f"Saved {stem}.{{png,svg,pdf}}")


def panel_label(ax: plt.Axes, letter: str, x: float = -0.14, y: float = 1.08) -> None:
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=11.5, fontweight="bold",
            va="top", ha="left", color=OI["black"])


def load_calibrated_params() -> dict[str, float]:
    df = pd.read_csv(TABLES_DIR / "model_parameters_calibrated.csv")
    return {str(r["parameter"]): float(r["value"]) for _, r in df.iterrows()}


# ---------------------------------------------------------------------------
# FIGURE 1: Cis-regulatory architecture, GSE276143 Hill switch, GTEx brain atlas & partial r
# ---------------------------------------------------------------------------
def make_figure1(p: dict[str, float]) -> None:
    cis = json.loads((DATA_PROCESSED / "cpeb4_cis_architecture.json").read_text(encoding="utf-8"))
    wt_df = pd.read_csv(DATA_PROCESSED / "gse276143_cpeb4_wt_dose.csv")
    var_df = pd.read_csv(DATA_PROCESSED / "gse276143_cpeb4_variants.csv")
    gtex_b = pd.read_csv(DATA_PROCESSED / "gtex_v8_brain_13regions.csv")
    corr_df = pd.read_csv(TABLES_DIR / "gtex_v8_correlations.csv")

    fig = plt.figure(figsize=(12.2, 9.2))
    gs = fig.add_gridspec(2, 2, hspace=0.38, wspace=0.32)

    # Panel a: Cis-regulatory architecture schematic (NC_000005.10)
    ax_a = fig.add_subplot(gs[0, 0])
    panel_label(ax_a, "a", x=-0.06, y=1.06)
    ax_a.set_xlim(0, 100)
    ax_a.set_ylim(0, 10)
    ax_a.axis("off")
    ax_a.set_title("Human CPEB4 exon 3–me4–exon 5 cis-architecture (NC_000005.10)", pad=8)

    # Intron baseline
    ax_a.plot([3, 97], [5.2, 5.2], color=OI["grey"], lw=2.0, zorder=1)
    # Exon boxes
    ex3 = mpatches.FancyBboxPatch((3, 4.3), 12, 1.8, boxstyle="round,pad=0.15", fc=OI["sky"], ec=OI["black"], lw=1.0, zorder=3)
    me4 = mpatches.FancyBboxPatch((52, 4.3), 8, 1.8, boxstyle="round,pad=0.15", fc=OI["vermilion"], ec=OI["black"], lw=1.2, zorder=3)
    ex5 = mpatches.FancyBboxPatch((82, 4.3), 15, 1.8, boxstyle="round,pad=0.15", fc=OI["blue"], ec=OI["black"], lw=1.0, zorder=3)
    for box in (ex3, me4, ex5):
        ax_a.add_patch(box)

    ax_a.text(9, 5.2, "Exon 3\n(51 nt)", ha="center", va="center", fontsize=7.5, fontweight="bold", color=OI["black"], zorder=4)
    ax_a.text(56, 5.2, "me4\n(24 nt)", ha="center", va="center", fontsize=7.5, fontweight="bold", color="white", zorder=4)
    ax_a.text(89.5, 5.2, "Exon 5\n(174 nt)", ha="center", va="center", fontsize=7.5, fontweight="bold", color="white", zorder=4)

    # Intron lengths & GC%
    ax_a.text(33.0, 5.75, "Intron 3: 10,525 nt (36.4% GC)\n53 ≥5T tracts; 0 RBFOX (±300 nt)",
              ha="center", va="bottom", fontsize=6.6, color=OI["black"])
    ax_a.text(71.5, 5.75, "Intron 4: 1,917 nt\n(Pol II window)", ha="center", va="bottom", fontsize=6.6, color=OI["black"])

    # Upstream PPT + hnRNPC + SRRM4 UGC motif
    ax_a.add_patch(mpatches.Rectangle((29.5, 3.18), 15.0, 0.80, fc=OI["orange"], ec=OI["black"], lw=0.8, zorder=3))
    ax_a.text(37.0, 3.58, "hnRNPC poly-U\n(T7·T5·T7)", ha="center", va="center", fontsize=6.3, color=OI["black"], fontweight="bold")
    ax_a.add_patch(mpatches.Rectangle((46.2, 3.18), 4.8, 0.80, fc=OI["green"], ec=OI["black"], lw=0.8, zorder=3))
    ax_a.text(48.6, 3.58, "TGC\n(-5)", ha="center", va="center", fontsize=6.3, color="white", fontweight="bold")

    # Splice-site competition callout
    ax_a.annotate("me4 3'ss: 7.13 bits\n5'ss: 6.36 bits", xy=(52, 6.2), xytext=(44, 8.2),
                  ha="center", fontsize=7.0, bbox=dict(boxstyle="round,pad=0.25", fc="#FFF4E6", ec=OI["vermilion"], lw=0.8),
                  arrowprops=dict(arrowstyle="->", color=OI["vermilion"], lw=0.9))
    ax_a.annotate("Exon 5 3'ss: 14.93 bits\n(Δ = −7.79 bits stronger)", xy=(82, 6.2), xytext=(80, 8.2),
                  ha="center", fontsize=7.0, bbox=dict(boxstyle="round,pad=0.25", fc="#E8F4FB", ec=OI["blue"], lw=0.8),
                  arrowprops=dict(arrowstyle="->", color=OI["blue"], lw=0.9))
    # Skipping arc vs inclusion
    ax_a.annotate("", xy=(82, 4.1), xytext=(15, 4.1),
                  arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=0.28", ls="--", color=OI["grey"], lw=1.1))
    ax_a.text(49, 1.4, "Default skipping vs SRRM4/RNPS1/SRSF11 recruitment\n"
              f"me4 peptide (frame +1): {cis['microexon_4_sequence']['inserted_peptide_vs_delta_me4']} (+4 Arg charge)",
              ha="center", va="center", fontsize=7.2, bbox=dict(boxstyle="round,pad=0.3", fc="#F5F5F5", ec=OI["grey"], lw=0.7))

    # Panel b: GSE276143 SRRM4 Hill dose-response + steric exon-length rescue
    ax_b = fig.add_subplot(gs[0, 1])
    panel_label(ax_b, "b")
    tier_map = {"GFP": 0.0, "LOW": 0.1, "MID": 1.0, "HIGH": 5.0}
    tx = lambda val: np.log10(np.asarray(val) + 0.05) - np.log10(0.05)

    sx = np.linspace(0.0, 5.2, 400)
    sy = rc.eq7_8_psi4(sx, p["v_PolII_HEK"], p) * 100.0
    ax_b.plot(tx(sx), sy, color=OI["blue"], lw=2.2, label="Calibrated Eq. (7)–(8) Hill model", zorder=2)

    # Individual replicate points + mean±SD
    for tier, s_val in tier_map.items():
        sub = wt_df[wt_df["condition"] == tier]
        xv = tx(s_val) + np.linspace(-0.04, 0.04, len(sub))
        ax_b.scatter(xv, sub["psi"], color=OI["sky"], edgecolor=OI["black"], s=28, lw=0.6, alpha=0.85, zorder=3)
        mu, sd = sub["psi"].mean(), sub["psi"].std()
        ax_b.errorbar(tx(s_val), mu, yerr=sd, fmt="o", color=OI["black"], ms=5.5, capsize=3.5, elinewidth=1.2, zorder=4,
                      label="WT rep mean ± SD (n = 6)" if tier == "GFP" else None)

    # Add_0-12 steric exon-lengthening overlay (36 nt vs 24 nt)
    add12 = var_df[var_df["variant"] == "CPEB4-HsaEX0016976-add_0-12"].sort_values("srrm4_tier_order")
    ax_b.errorbar([tx(tier_map[c]) for c in add12["condition"]], add12["mean_psi"], yerr=add12["sd_psi"],
                  fmt="s--", color=OI["vermilion"], lw=1.4, ms=4.8, capsize=3, label="Steric rescue (+12 nt, 36 nt exon)")

    ax_b.set_xticks([float(tx(v)) for v in (0.0, 0.1, 1.0, 5.0)])
    ax_b.set_xticklabels(["GFP\n(0.0)", "LOW\n(0.1)", "MID\n(1.0)", "HIGH\n(5.0)"])
    ax_b.set_xlabel("Relative SRRM4 induction tier, $S_{\\mathrm{eff}}$ (GSE276143)")
    ax_b.set_ylabel("CPEB4 me4 inclusion, $\\Psi_4$ (%)")
    ax_b.set_xlim(-0.14, float(tx(5.45)))
    ax_b.set_ylim(-5, 108)
    ax_b.set_title("Cooperative SRRM4 Hill switch & steric rescue (GSE276143)", pad=8)
    ax_b.text(0.04, 0.50, f"LORO CV $R^2$ = 0.9984\nRMSE = 1.64%\n$n_H$ = {p['n_H']:.2f}, $K_{{50}}$ = {p['K_50']:.2f}",
              transform=ax_b.transAxes, fontsize=7.5, bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=OI["lightgrey"]))
    ax_b.legend(loc="lower right", frameon=True, framealpha=0.92)

    # Panel c: GTEx v8 13 brain regions PSI4 vs SRRM4 & RBFOX1
    ax_c = fig.add_subplot(gs[1, 0])
    panel_label(ax_c, "c")
    x_srrm4 = np.log2(gtex_b["SRRM4"].values + 1.0)
    x_rbfox1 = np.log2(gtex_b["RBFOX1"].values + 1.0)
    y_psi = gtex_b["PSI4"].values * 100.0

    ax_c.scatter(x_srrm4, y_psi, s=48, color=OI["blue"], marker="o", edgecolor=OI["black"], lw=0.7,
                 label="SRRM4 ($r_{\\log_2}$ = +0.966, $P = 8.9\\times 10^{-8}$)")
    ax_c.scatter(x_rbfox1, y_psi, s=44, color=OI["orange"], marker="^", edgecolor=OI["black"], lw=0.7, alpha=0.85,
                 label="RBFOX1 ($r_{\\log_2}$ = +0.655; partial $r$ = −0.621)")

    # Regression lines
    for xv, col, ls in ((x_srrm4, OI["blue"], "-"), (x_rbfox1, OI["orange"], "--")):
        m_fit, b_fit = np.polyfit(xv, y_psi, 1)
        xg = np.linspace(xv.min(), xv.max(), 50)
        ax_c.plot(xg, m_fit * xg + b_fit, color=col, ls=ls, lw=1.3, alpha=0.85)

    # Annotate key brain regions clearly without overlaps
    ann_map = {
        "BRNCHB": ("Cerebellar Hem.", (-18, 8)),
        "BRNCHA": ("Cerebellum", (-14, -14)),
        "BRNCTXB": ("PFC BA9", (6, 4)),
        "BRNCDT": ("Caudate", (-38, 6)),
        "BRNPTM": ("Putamen", (-36, -11)),
        "BRNHPP": ("Hippocampus", (7, 5)),
    }
    for _, row in gtex_b.iterrows():
        ab = row["tissueSiteDetailAbbr"]
        if ab in ann_map:
            lbl, offset = ann_map[ab]
            ax_c.annotate(lbl, (np.log2(row["SRRM4"] + 1), row["PSI4"] * 100),
                          xytext=offset, textcoords="offset points", fontsize=6.9, color=OI["black"])
        if ab in ("BRNCDT", "BRNPTM"):
            ax_c.annotate(f"{ab[3:]} RBFOX1", (np.log2(row["RBFOX1"] + 1), row["PSI4"] * 100),
                          xytext=(5, -3 if ab == "BRNCDT" else -9), textcoords="offset points",
                          fontsize=6.5, color=OI["vermilion"])

    ax_c.set_xlabel("GTEx v8 median brain expression, $\\log_2(\\mathrm{TPM}+1)$")
    ax_c.set_ylabel("CPEB4 me4 inclusion, $\\Psi_4$ (%)")
    ax_c.set_ylim(-6, 86)
    ax_c.set_xlim(0.4, 7.2)
    ax_c.set_title("Human brain-regional specificity across 13 GTEx v8 regions", pad=8)
    ax_c.legend(loc="upper left", frameon=True, framealpha=0.92, fontsize=7.0)

    # Panel d: Partial Pearson r controlling for neuronal markers (RBFOX3 + SYP)
    ax_d = fig.add_subplot(gs[1, 1])
    panel_label(ax_d, "d")
    sub_corr = corr_df[(corr_df["scope"] == "brain_13") & (corr_df["gene"].isin(
        ["RBFOX2", "SRRM3", "RNPS1", "SRSF11", "HDAC2", "SRPK1", "SRRM4", "HNRNPC", "DRD2", "HTR2A", "RBFOX1"]
    ))].copy()
    sub_corr = sub_corr.sort_values("partial_pearson_r", ascending=True)
    y_idx = np.arange(len(sub_corr))
    cols = [OI["vermilion"] if g == "RBFOX1" else (OI["green"] if g in ("SRRM4", "SRRM3", "RNPS1", "SRSF11", "HDAC2", "SRPK1") else OI["grey"])
            for g in sub_corr["gene"]]

    ax_d.axvline(0.0, color=OI["black"], lw=0.9, ls="--")
    ax_d.barh(y_idx, sub_corr["partial_pearson_r"], color=cols, edgecolor=OI["black"], linewidth=0.6, height=0.65, alpha=0.88)
    for idx, (_, r) in enumerate(sub_corr.iterrows()):
        sig = "*" if r["partial_pearson_fdr"] < 0.05 else ""
        val = r["partial_pearson_r"]
        ax_d.text(val + (0.03 if val >= 0 else -0.03), idx, f"{val:+.2f}{sig}",
                  va="center", ha="left" if val >= 0 else "right", fontsize=7.0, fontweight="bold" if sig else "normal")
    ax_d.set_yticks(y_idx)
    ax_d.set_yticklabels(sub_corr["gene"])
    ax_d.set_xlim(-0.85, 1.12)
    ax_d.set_xlabel("Partial Pearson $r$ with $\\Psi_4$ (adjusted for $RBFOX3 + SYP$)")
    ax_d.set_title("Neuronal-fraction-adjusted regulator specificity (*FDR < 0.05)", pad=8)

    save_fig(fig, "Figure1")


# ---------------------------------------------------------------------------
# FIGURE 2: ChEMBL 37 Pharmacology, Occupancy vs GTEx Regions & STRING v12.5 Network
# ---------------------------------------------------------------------------
def make_figure2() -> None:
    chembl_df = pd.read_csv(DATA_PROCESSED / "chembl_antipsychotic_ki.csv")
    drug_pred = pd.read_csv(TABLES_DIR / "antipsychotic_drug_predictions.csv")
    gtex_b = pd.read_csv(DATA_PROCESSED / "gtex_v8_brain_13regions.csv")
    edges_df = pd.read_csv(DATA_PROCESSED / "string_network_edges.csv")

    fig = plt.figure(figsize=(12.6, 9.6))
    gs = fig.add_gridspec(2, 2, hspace=0.40, wspace=0.34)

    # Panel a: ChEMBL 37 pKi heatmap across 12 drugs x 7 GPCRs
    ax_a = fig.add_subplot(gs[0, 0])
    panel_label(ax_a, "a", x=-0.18, y=1.06)
    targets = ["DRD2", "HTR2A", "DRD1", "HTR1A", "ADRA1A", "HRH1", "CHRM1"]
    piv_pki = chembl_df.pivot(index="drug_name", columns="target_symbol", values="median_pki")
    piv_ki = chembl_df.pivot(index="drug_name", columns="target_symbol", values="median_ki_nm")
    # Order drugs by HTR2A/DRD2 selectivity ratio
    order_drugs = (chembl_df.drop_duplicates("drug_name")
                   .sort_values("affinity_ratio_drd2_over_htr2a", ascending=False)["drug_name"].tolist())
    piv_pki = piv_pki.reindex(index=order_drugs, columns=targets)
    piv_ki = piv_ki.reindex(index=order_drugs, columns=targets)

    mat = piv_pki.values
    masked = np.ma.masked_invalid(mat)
    cmap = LinearSegmentedColormap.from_list("pki_seq", ["#F7FBFF", "#6BAED6", "#08519C"])
    cmap.set_bad("#EEEEEE")
    im = ax_a.imshow(masked, aspect="auto", cmap=cmap, vmin=5.2, vmax=9.6)
    cbar = fig.colorbar(im, ax=ax_a, fraction=0.042, pad=0.03)
    cbar.set_label("Median human $pK_i$ (ChEMBL 37)", fontsize=7.8)

    for i in range(len(order_drugs)):
        for j in range(len(targets)):
            val = piv_ki.iloc[i, j]
            if pd.notna(val):
                txt = f"{val:.1f}" if val < 100 else f"{val:.0f}"
                col = "white" if piv_pki.iloc[i, j] >= 7.8 else OI["black"]
                ax_a.text(j, i, txt, ha="center", va="center", fontsize=6.4, color=col)
            else:
                ax_a.text(j, i, "—", ha="center", va="center", fontsize=6.4, color=OI["grey"])

    ax_a.set_xticks(np.arange(len(targets)))
    ax_a.set_xticklabels(targets, rotation=28, ha="right")
    ax_a.set_yticks(np.arange(len(order_drugs)))
    ax_a.set_yticklabels([d.title() for d in order_drugs])
    ax_a.set_title("Human GPCR binding affinities ($K_i$ nM; ChEMBL 37)", pad=8)

    # Panel b: Clinical occupancy (theta_D2 vs theta_5HT2A) + regional GTEx background
    ax_b = fig.add_subplot(gs[0, 1])
    panel_label(ax_b, "b")
    ba9_drugs = drug_pred[drug_pred["region"] == "PFC_BA9"].copy()
    ax_b.axhspan(65.0, 80.0, color=OI["sky"], alpha=0.14, label="Clinical PET D2 window (65–80%)")
    ax_b.axvline(50.0, color=OI["grey"], ls=":", lw=0.9)

    pos_map = {
        "HALOPERIDOL": (8.5, 62.0, "left"),
        "AMISULPRIDE": (8.5, 83.0, "left"),
        "FLUPHENAZINE": (25.0, 77.5, "left"),
        "ARIPIPRAZOLE": (46.0, 56.0, "right"),
        "LURASIDONE": (61.0, 60.5, "right"),
        "CHLORPROMAZINE": (62.0, 84.5, "right"),
        "PALIPERIDONE": (82.0, 85.0, "right"),
        "RISPERIDONE": (101.0, 77.5, "left"),
        "ZIPRASIDONE": (101.0, 66.5, "left"),
        "OLANZAPINE": (85.0, 56.5, "right"),
        "CLOZAPINE": (94.0, 42.5, "left"),
        "QUETIAPINE": (62.0, 34.0, "left"),
    }
    for _, r in ba9_drugs.iterrows():
        is_typ = "Typical" in r["drug_class"]
        col = OI["vermilion"] if is_typ else (OI["green"] if r["theta_5ht2a"] > 0.70 else OI["blue"])
        mk = "^" if is_typ else ("o" if r["theta_5ht2a"] > 0.70 else "s")
        xpt, ypt = r["theta_5ht2a"] * 100.0, r["dtheta_d2_eff"] * 100.0
        ax_b.scatter(xpt, ypt, s=62, color=col, marker=mk, edgecolor=OI["black"], lw=0.7, zorder=4)
        tx_d, ty_d, ha_d = pos_map.get(r["drug_name"], (xpt + 4, ypt + 4, "left"))
        ax_b.annotate(r["drug_name"].title(), (xpt, ypt), xytext=(tx_d, ty_d),
                      textcoords="data", ha=ha_d, va="center", fontsize=6.5, color=OI["black"],
                      arrowprops=dict(arrowstyle="-", color=OI["grey"], lw=0.65, shrinkA=0, shrinkB=2.5))

    ax_b.set_xlim(-4, 122)
    ax_b.set_ylim(26, 90)
    ax_b.set_xlabel("Effective 5-HT2A receptor occupancy, $\\theta_{\\mathrm{5HT2A}}$ (%)")
    ax_b.set_ylabel("Effective D2R antagonism, $\\Delta\\theta_{\\mathrm{D2}}^{\\mathrm{eff}}$ (%)")
    ax_b.set_title("Clinical free-brain receptor occupancy space", pad=8)
    handles = [
        Line2D([0], [0], marker="^", color="w", markerfacecolor=OI["vermilion"], markeredgecolor=OI["black"], ms=7, label="Typical (D2-selective)"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor=OI["green"], markeredgecolor=OI["black"], ms=7, label="Atypical (high 5-HT2A)"),
        Line2D([0], [0], marker="s", color="w", markerfacecolor=OI["blue"], markeredgecolor=OI["black"], ms=7, label="Atypical (D2/partial/low 5-HT2A)"),
    ]
    ax_b.legend(handles=handles, loc="lower left", fontsize=6.8, frameon=True)

    # Panel c: STRING v12.5 layered signaling-to-splicing network
    ax_c = fig.add_subplot(gs[1, 0])
    panel_label(ax_c, "c", x=-0.06, y=1.06)
    G = nx.Graph()
    for _, e in edges_df.iterrows():
        G.add_edge(e["protein_a"], e["protein_b"], weight=float(e["combined_score"]))
    # Layered coordinates
    layers = {
        "Receptors": (0.0, ["DRD2", "HTR2A", "DRD1", "HTR1A"]),
        "Transducers": (1.0, ["GNAI2", "GNAQ", "ARRB2"]),
        "Kinases / PP1": (2.0, ["PRKACA", "PPP1R1B", "PPP1CA", "AKT1", "GSK3B", "CAMK2A", "MAPK1"]),
        "SR Kinases / HAT": (3.0, ["SRPK1", "SRPK2", "DYRK1A", "EP300"]),
        "Splicing / Pol II": (4.0, ["HDAC2", "POLR2A", "RNPS1", "SRSF11", "SRRM4", "RBFOX1", "PTBP1", "HNRNPC"]),
        "Target": (4.9, ["CPEB4"]),
    }
    pos = {}
    layer_colors = {
        "Receptors": OI["vermilion"], "Transducers": OI["orange"], "Kinases / PP1": OI["sky"],
        "SR Kinases / HAT": OI["purple"], "Splicing / Pol II": OI["green"], "Target": OI["blue"],
    }
    node_col = {}
    for lname, (xv, nodes) in layers.items():
        ys = np.linspace(len(nodes) - 1, 0, len(nodes)) - (len(nodes) - 1) / 2.0
        for nd, yv in zip(nodes, ys):
            pos[nd] = (xv, yv * 1.15)
            node_col[nd] = layer_colors[lname]

    # Edges
    for u, v, d in G.edges(data=True):
        if u in pos and v in pos:
            w = d["weight"]
            ax_c.plot([pos[u][0], pos[v][0]], [pos[u][1], pos[v][1]],
                      color=OI["grey"], lw=0.45 + 1.3 * w, alpha=0.22 + 0.35 * w, zorder=1)
    # Dashed regulatory arrow from SRRM4 / HDAC2 / POLR2A to CPEB4 mRNA
    for src in ("SRRM4", "HDAC2", "POLR2A"):
        ax_c.annotate("", xy=pos["CPEB4"], xytext=pos[src],
                      arrowprops=dict(arrowstyle="->", ls="--", color=OI["blue"], lw=1.0, alpha=0.7))

    for nd, (xv, yv) in pos.items():
        sz = 230 if nd in ("AKT1", "DRD2", "HTR2A", "SRRM4", "HDAC2", "CPEB4") else 160
        ax_c.scatter(xv, yv, s=sz, color=node_col[nd], edgecolor=OI["black"], lw=0.8, zorder=3)
        ax_c.text(xv, yv - 0.34, nd, ha="center", va="top", fontsize=6.0, fontweight="bold", color=OI["black"])

    ax_c.set_xlim(-0.45, 5.45)
    ax_c.set_ylim(-5.2, 5.2)
    ax_c.axis("off")
    ax_c.set_title("STRING v12.5 indirect GPCR-to-splicing network (89 edges)", pad=8)

    # Panel d: GTEx regional DRD2/HTR2A/PPP1R1B/CAMK2A topology vs predicted Psi4 boost
    ax_d = fig.add_subplot(gs[1, 1])
    panel_label(ax_d, "d")
    regs = ["Brain_Frontal_Cortex_BA9", "Brain_Anterior_cingulate_cortex_BA24",
            "Brain_Hippocampus", "Brain_Caudate_basal_ganglia", "Brain_Putamen_basal_ganglia"]
    reg_lbls = ["PFC BA9", "ACC BA24", "Hippocampus", "Caudate", "Putamen"]
    sub_g = gtex_b.set_index("tissueSiteDetailId").loc[regs]
    x = np.arange(len(regs))
    w = 0.22
    ax_d.bar(x - 1.5 * w, np.log2(sub_g["DRD2"] + 1), w, color=OI["vermilion"], edgecolor=OI["black"], lw=0.6, label="DRD2")
    ax_d.bar(x - 0.5 * w, np.log2(sub_g["HTR2A"] + 1), w, color=OI["green"], edgecolor=OI["black"], lw=0.6, label="HTR2A")
    ax_d.bar(x + 0.5 * w, np.log2(sub_g["PPP1R1B"] + 1), w, color=OI["sky"], edgecolor=OI["black"], lw=0.6, label="PPP1R1B (DARPP-32)")
    ax_d.bar(x + 1.5 * w, np.log2(sub_g["CAMK2A"] + 1), w, color=OI["orange"], edgecolor=OI["black"], lw=0.6, label="CAMK2A")
    ax_d.set_xticks(x)
    ax_d.set_xticklabels(reg_lbls, rotation=20, ha="right")
    ax_d.set_ylabel("GTEx v8 expression, $\\log_2(\\mathrm{TPM}+1)$")
    ax_d.set_ylim(0, 12.2)
    ax_d.set_title("Cortical (5-HT2AR/CaMKII) vs striatal (D2R/DARPP-32) topology", pad=8)
    ax_d.legend(loc="upper center", ncol=2, fontsize=6.8, frameon=True)

    save_fig(fig, "Figure2")


# ---------------------------------------------------------------------------
# FIGURE 3: Multi-Cohort Human SCZ & Cross-Species Pharmacological Validation
# ---------------------------------------------------------------------------
def make_figure3() -> None:
    g138 = pd.read_csv(DATA_PROCESSED / "gse138082_differential.csv")
    g174 = pd.read_csv(DATA_PROCESSED / "gse174407_differential.csv")
    g163 = pd.read_csv(DATA_PROCESSED / "gse163161_differential.csv")
    g677 = pd.read_csv(DATA_PROCESSED / "gse67755_differential.csv")
    meta = pd.read_csv(DATA_PROCESSED / "cross_cohort_meta.csv")

    key_genes = ["CPEB4", "SRRM4", "RNPS1", "SRSF11", "RBFOX1", "PTBP1", "PTBP2", "HNRNPC", "HDAC2", "POLR2A", "CAMK2A", "DRD2", "HTR2A"]

    fig = plt.figure(figsize=(12.6, 9.6))
    gs = fig.add_gridspec(2, 2, hspace=0.40, wspace=0.32)

    # Panel a: GSE174407 purified NeuN+ frontal cortex neurons (n=58 donors)
    ax_a = fig.add_subplot(gs[0, 0])
    panel_label(ax_a, "a")
    s_unt = g174[(g174["contrast"] == "SCZ_untreated_vs_CTL") & (g174["feature"].isin(key_genes))].set_index("feature").loc[key_genes]
    s_trt = g174[(g174["contrast"] == "SCZ_treated_vs_SCZ_untreated") & (g174["feature"].isin(key_genes))].set_index("feature").loc[key_genes]
    y = np.arange(len(key_genes))
    ax_a.axvline(0.0, color=OI["black"], lw=0.8, ls="--")
    ax_a.errorbar(s_unt["hedges_g"], y + 0.16, xerr=1.96 * s_unt["se_g"], fmt="o", color=OI["vermilion"],
                  ms=4.5, elinewidth=1.0, capsize=2.5, label="Untreated SCZ vs CTL (n=15 vs 29)")
    ax_a.errorbar(s_trt["hedges_g"], y - 0.16, xerr=1.96 * s_trt["se_g"], fmt="s", color=OI["blue"],
                  ms=4.5, elinewidth=1.0, capsize=2.5, label="Treated vs Untreated SCZ (n=14 vs 15)")
    for idx, g in enumerate(key_genes):
        if s_trt.loc[g, "fdr"] < 0.05:
            ax_a.text(s_trt.loc[g, "hedges_g"], idx - 0.36, "*", ha="center", va="center", color=OI["blue"], fontsize=10, fontweight="bold")
    ax_a.set_yticks(y)
    ax_a.set_yticklabels(key_genes)
    ax_a.set_ylim(len(key_genes) + 2.3, -0.7)
    ax_a.set_xlabel("Hedges' $g$ ± 95% CI (age-adjusted)")
    ax_a.set_title("Human PFC NeuN+ neurons (GSE174407, n = 58 donors)", pad=8)
    ax_a.legend(loc="lower right", fontsize=6.7, frameon=True)

    # Panel b: GSE138082 human hippocampus (n=78) SCZ_ON vs SCZ_OFF
    ax_b = fig.add_subplot(gs[0, 1])
    panel_label(ax_b, "b")
    h_off = g138[(g138["contrast"] == "SCZ_OFF_vs_CTL") & (g138["feature"].isin(key_genes))].set_index("feature").loc[key_genes]
    h_on = g138[(g138["contrast"] == "SCZ_ON_vs_SCZ_OFF") & (g138["feature"].isin(key_genes))].set_index("feature").loc[key_genes]
    ax_b.axvline(0.0, color=OI["black"], lw=0.8, ls="--")
    ax_b.errorbar(h_off["hedges_g"], y + 0.16, xerr=1.96 * h_off["se_g"], fmt="o", color=OI["orange"],
                  ms=4.5, elinewidth=1.0, capsize=2.5, label="SCZ OFF vs CTL (n=21 vs 39)")
    ax_b.errorbar(h_on["hedges_g"], y - 0.16, xerr=1.96 * h_on["se_g"], fmt="s", color=OI["green"],
                  ms=4.5, elinewidth=1.0, capsize=2.5, label="SCZ ON vs SCZ OFF (n=18 vs 21)")
    ax_b.set_yticks(y)
    ax_b.set_yticklabels(key_genes)
    ax_b.set_ylim(len(key_genes) + 2.3, -0.7)
    ax_b.set_xlabel("Hedges' $g$ ± 95% CI (clustered covariate OLS)")
    ax_b.set_title("Human hippocampus subfields (GSE138082, n = 78)", pad=8)
    ax_b.legend(loc="lower right", fontsize=6.7, frameon=True)

    # Panel c: Preclinical comparison: Human iPSC neurons (GSE163161 Clozapine) vs Mouse Whole Brain (GSE67755 Haloperidol)
    ax_c = fig.add_subplot(gs[1, 0])
    panel_label(ax_c, "c")
    c_genes = [g for g in key_genes if g in set(g677["feature"])]
    i163 = g163.set_index("feature").loc[c_genes]
    m677 = g677.set_index("feature").loc[c_genes]
    yc = np.arange(len(c_genes))
    ax_c.axvline(0.0, color=OI["black"], lw=0.8, ls="--")
    ax_c.barh(yc - 0.18, i163["hedges_g"], height=0.34, color=OI["sky"], edgecolor=OI["black"], lw=0.6, label="Human iPSC neurons + Clozapine (GSE163161)")
    ax_c.barh(yc + 0.18, m677["hedges_g"], height=0.34, color=OI["purple"], edgecolor=OI["black"], lw=0.6, label="Mouse whole brain + Haloperidol (GSE67755)")
    ax_c.set_yticks(yc)
    ax_c.set_yticklabels(c_genes)
    ax_c.set_ylim(len(c_genes) + 2.4, -0.7)
    ax_c.set_xlabel("Antipsychotic vs vehicle effect size (Hedges' $g$)")
    ax_c.set_title("Human iPSC excitatory neurons vs chronic haloperidol mouse brain", pad=8)
    ax_c.legend(loc="lower left", fontsize=6.5, frameon=True)

    # Panel d: Cross-cohort meta-analysis (5-cohort cross-species vs 3-cohort human)
    ax_d = fig.add_subplot(gs[1, 1])
    panel_label(ax_d, "d")
    m5 = meta[(meta["meta_analysis"] == "ANTIPSYCHOTIC_5COHORT_CROSS_SPECIES") & (meta["feature"].isin(key_genes))].set_index("feature").loc[key_genes]
    m3 = meta[(meta["meta_analysis"] == "ANTIPSYCHOTIC_3COHORT_HUMAN") & (meta["feature"].isin(key_genes))].set_index("feature").loc[key_genes]
    ax_d.axvline(0.0, color=OI["black"], lw=0.8, ls="--")
    ax_d.errorbar(m5["re_hedges_g"], y + 0.16,
                  xerr=[m5["re_hedges_g"] - m5["re_ci95_low"], m5["re_ci95_high"] - m5["re_hedges_g"]],
                  fmt="D", color=OI["black"], ms=4.2, elinewidth=1.0, capsize=2.5, label="5-Cohort cross-species RE (N = 104)")
    ax_d.errorbar(m3["re_hedges_g"], y - 0.16,
                  xerr=[m3["re_hedges_g"] - m3["re_ci95_low"], m3["re_ci95_high"] - m3["re_hedges_g"]],
                  fmt="o", color=OI["blue"], ms=4.5, elinewidth=1.0, capsize=2.5, label="3-Cohort human RE (N = 78)")
    for idx, g in enumerate(key_genes):
        if m5.loc[g, "re_fdr"] < 0.05 or m3.loc[g, "re_fdr"] < 0.05:
            ax_d.text(1.78, idx, f"$I^2$={m3.loc[g,'i2_pct']:.0f}%*", va="center", ha="right", fontsize=6.5, color=OI["vermilion"], fontweight="bold")
    ax_d.set_yticks(y)
    ax_d.set_yticklabels(key_genes)
    ax_d.set_ylim(len(key_genes) + 2.3, -0.7)
    ax_d.set_xlim(-2.2, 2.15)
    ax_d.set_xlabel("DerSimonian–Laird random-effects Hedges' $g$ ± 95% CI")
    ax_d.set_title("Cross-cohort antipsychotic meta-analysis (*RE FDR < 0.05)", pad=8)
    ax_d.legend(loc="lower left", fontsize=6.6, frameon=True)

    save_fig(fig, "Figure3")


# ---------------------------------------------------------------------------
# FIGURE 4: Mechanism Dissection — 2D Phase Space, Ablation Epistasis, Predictive Checks & Sobol
# ---------------------------------------------------------------------------
def make_figure4(p: dict[str, float]) -> None:
    drug_pred = pd.read_csv(TABLES_DIR / "antipsychotic_drug_predictions.csv")
    abl_df = pd.read_csv(TABLES_DIR / "mechanistic_ablation_synergy.csv")
    pp_df = pd.read_csv(TABLES_DIR / "prior_vs_posterior_predictive.csv")
    sobol_df = pd.read_csv(TABLES_DIR / "sobol_prcc_sensitivity.csv")
    gtex_b = pd.read_csv(DATA_PROCESSED / "gtex_v8_brain_13regions.csv")
    gtex_loocv = pd.read_csv(TABLES_DIR / "gtex_brain13_loocv.csv")

    fig = plt.figure(figsize=(12.6, 9.6))
    gs = fig.add_gridspec(2, 2, hspace=0.38, wspace=0.34)

    # Panel a: 2D Psi4(S_eff, v_PolII) heatmap with drug trajectories in PFC BA9
    ax_a = fig.add_subplot(gs[0, 0])
    panel_label(ax_a, "a")
    se_grid = np.linspace(0.05, 1.45, 160)
    vp_grid = np.linspace(22.0, 68.0, 160)
    SE, VP = np.meshgrid(se_grid, vp_grid)
    PSI = rc.eq7_8_psi4(SE, VP, p)

    cf = ax_a.contourf(SE, VP, PSI * 100.0, levels=np.linspace(5, 95, 19), cmap="viridis", alpha=0.90)
    cs = ax_a.contour(SE, VP, PSI * 100.0, levels=[55, 65, 70, 75], colors=["white", "#F0E442", "white", "#FFCCCC"],
                      linestyles=["--", ":", "-", "-."], linewidths=[1.1, 1.2, 1.5, 1.0])
    ax_a.clabel(cs, fmt="%.0f%%", fontsize=7.0)
    cbar = fig.colorbar(cf, ax=ax_a, fraction=0.042, pad=0.02)
    cbar.set_label("CPEB4 me4 $\\Psi_4$ (%)", fontsize=7.8)

    # Overlay exact states in PFC BA9
    ref_medians = {"RNPS1": float(gtex_b["RNPS1"].median()), "SRSF11": float(gtex_b["SRSF11"].median()), "HDAC2": float(gtex_b["HDAC2"].median())}
    ba9_row = gtex_b[gtex_b["tissueSiteDetailAbbr"] == "BRNCTXB"].iloc[0]
    scz_ss = rc.steady_upstream(rc.regional_context(ba9_row, ref_medians, p, 0.0, 0.0, scz=True), p)
    hlt_ss = rc.steady_upstream(rc.regional_context(ba9_row, ref_medians, p, 0.0, 0.0, scz=False), p)

    ax_a.scatter(hlt_ss["S_eff"], hlt_ss["v_pol"], s=75, color=OI["sky"], edgecolor="black", marker="*", zorder=5, label="Healthy BA9 (70%)")
    ax_a.scatter(scz_ss["S_eff"], scz_ss["v_pol"], s=65, color=OI["vermilion"], edgecolor="white", marker="X", zorder=5, label="Untreated SCZ BA9 (55%)")

    ba9_d = drug_pred[drug_pred["region"] == "PFC_BA9"].set_index("drug_name")
    chembl_df = pd.read_csv(DATA_PROCESSED / "chembl_antipsychotic_ki.csv")
    for dname, col, mk, dx, dy in [
        ("HALOPERIDOL", "#FFFFFF", "^", 0.04, 1.8),
        ("CLOZAPINE", "#F0E442", "s", 0.05, -2.5),
        ("RISPERIDONE", "#00FFAA", "o", 0.05, 1.5),
    ]:
        row_c = chembl_df[chembl_df["drug_name"] == dname].iloc[0]
        occ = rc.eq1_occupancy(dname, float(row_c["drd2_median_ki_nm"]), float(row_c["htr2a_median_ki_nm"]))
        st = rc.steady_upstream(rc.regional_context(ba9_row, ref_medians, p, occ["dtheta_d2_eff"], occ["dtheta_5ht2a_eff"], scz=True), p)
        ax_a.annotate("", xy=(st["S_eff"], st["v_pol"]), xytext=(scz_ss["S_eff"], scz_ss["v_pol"]),
                      arrowprops=dict(arrowstyle="->", color=col, lw=1.6, zorder=4))
        ax_a.scatter(st["S_eff"], st["v_pol"], s=58, color=col, edgecolor="black", marker=mk, zorder=6)
        ax_a.text(st["S_eff"] + dx, st["v_pol"] + dy, f"{dname.title()}\n({st['Psi4']*100:.1f}%)",
                  fontsize=6.6, fontweight="bold", color="white",
                  bbox=dict(boxstyle="round,pad=0.15", fc="black", alpha=0.55, ec="none"))

    ax_a.set_xlabel("Effective spliceosome drive, $S_{\\mathrm{eff}}$ (norm. units)")
    ax_a.set_ylabel("RNA Pol II elongation rate, $v_{\\mathrm{PolII}}$ ($\\mathrm{nt\\,s}^{-1}$)")
    ax_a.set_title("Co-transcriptional splicing landscape, Eq. (8)", pad=8)

    # Panel b: Ablation decomposition & threshold epistasis (RISPERIDONE vs HALOPERIDOL in BA9)
    ax_b = fig.add_subplot(gs[0, 1])
    panel_label(ax_b, "b")
    modes = [
        ("Arm1_Only_PKA_DARPP32_CaMK", "Arm 1\n(PKA/CaMKII)"),
        ("Arm2_Only_Excitability_SRRM4", "Arm 2\n(Excitability)"),
        ("Arm3_Only_5HT2A_HDAC2_PolII", "Arm 3\n(HDAC2/Pol II)"),
        ("PTBP1_Relief_Only", "PTBP1\nRelief"),
        ("Full_Combined_Model", "Combined\nModel"),
    ]
    ris_a = abl_df[(abl_df["drug_name"] == "RISPERIDONE") & (abl_df["region"] == "PFC_BA9")].set_index("ablation_mode")
    x = np.arange(len(modes))
    w = 0.35
    dpsi_vals = [ris_a.loc[m[0], "Delta_Psi4"] * 100 for m in modes]
    dmf_vals = [ris_a.loc[m[0], "Delta_M_f_28d"] * 100 for m in modes]
    ax_b.bar(x - w / 2, dpsi_vals, w, color=OI["blue"], edgecolor=OI["black"], lw=0.6, label="$\\Delta\\Psi_4$ rescue (%)")
    ax_b.bar(x + w / 2, dmf_vals, w, color=OI["green"], edgecolor=OI["black"], lw=0.6, label="Day-28 FRAP $\\Delta M_f$ (%)")

    # Additive reference dashed lines for Combined Model
    sum_psi = ris_a.loc["Full_Combined_Model", "sum_single_arms_Delta_Psi4"] * 100
    sum_mf = ris_a.loc["Full_Combined_Model", "sum_single_arms_Delta_Mf"] * 100
    ax_b.hlines(sum_psi, 4 - w, 4, colors=OI["vermilion"], linestyles="--", lw=1.4, label="Additive arm sum")
    ax_b.hlines(sum_mf, 4, 4 + w, colors=OI["vermilion"], linestyles="--", lw=1.4)
    ax_b.annotate(f"Threshold epistasis\n+10.4% $\\Delta M_f$\n(+39.0% over sum)",
                  xy=(4 + w / 2, dmf_vals[-1]), xytext=(2.45, 33.5),
                  fontsize=7.0, fontweight="bold", color=OI["vermilion"],
                  arrowprops=dict(arrowstyle="->", color=OI["vermilion"], lw=1.1),
                  bbox=dict(boxstyle="round,pad=0.2", fc="#FFF5F0", ec=OI["vermilion"], lw=0.7))

    ax_b.set_xticks(x)
    ax_b.set_xticklabels([m[1] for m in modes])
    ax_b.set_ylabel("Improvement vs untreated SCZ (% points)")
    ax_b.set_ylim(0, 44)
    ax_b.set_title("Arm 1/2/3 ablation & threshold epistasis (Risperidone, BA9)", pad=8)
    ax_b.legend(loc="upper left", fontsize=6.8, frameon=True)

    # Panel c: Prior vs Posterior Predictive Shrinkage + GTEx Brain-13 LOOCV Parity
    ax_c = fig.add_subplot(gs[1, 0])
    panel_label(ax_c, "c")
    ax_c.plot([0, 75], [0, 75], color=OI["grey"], ls="--", lw=1.0, label="Identity ($y=x$)")
    ax_c.scatter(gtex_loocv["PSI4"] * 100, gtex_loocv["psi_pred_loocv"] * 100, s=48,
                 color=OI["blue"], edgecolor=OI["black"], lw=0.7, label="GTEx brain LOOCV ($R^2$ = 0.937)")
    # Highlight PFC BA9 prior vs posterior predictive intervals
    pp_dpsi = pp_df[pp_df["output_metric"] == "Delta_Psi4_BA9_RIS"].set_index("distribution")
    ax_c.errorbar(55.0 + pp_dpsi.loc["Prior_Predictive", "median"] * 100, 74.4,
                  xerr=[[pp_dpsi.loc["Prior_Predictive", "median"] * 100 - pp_dpsi.loc["Prior_Predictive", "q025"] * 100],
                        [pp_dpsi.loc["Prior_Predictive", "q975"] * 100 - pp_dpsi.loc["Prior_Predictive", "median"] * 100]],
                  fmt="o", color=OI["orange"], lw=2.0, capsize=4, label="BA9 Risperidone Prior 95% PI")
    ax_c.errorbar(55.0 + pp_dpsi.loc["Posterior_Predictive", "median"] * 100, 74.4,
                  xerr=[[pp_dpsi.loc["Posterior_Predictive", "median"] * 100 - pp_dpsi.loc["Posterior_Predictive", "q025"] * 100],
                        [pp_dpsi.loc["Posterior_Predictive", "q975"] * 100 - pp_dpsi.loc["Posterior_Predictive", "median"] * 100]],
                  fmt="s", color=OI["vermilion"], lw=2.4, capsize=4, label="BA9 Posterior 95% PI (5.8× IQR shrink)")

    off_c = {"BRNCHB": (-28, -4), "BRNCTXB": (5, -4), "BRNHPP": (6, 4), "BRNACC": (5, -4)}
    for _, r in gtex_loocv.iterrows():
        ab = r["tissueSiteDetailAbbr"]
        if ab in off_c:
            ax_c.annotate(ab[3:], (r["PSI4"] * 100, r["psi_pred_loocv"] * 100),
                          xytext=off_c[ab], textcoords="offset points", fontsize=6.6)
    ax_c.set_xlim(-4, 90)
    ax_c.set_ylim(-4, 82)
    ax_c.set_xlabel("Observed GTEx $\\Psi_4$ (%) / Predictive shift")
    ax_c.set_ylabel("LOOCV predicted $\\Psi_4$ (%)")
    ax_c.set_title("GTEx brain LOOCV & prior-to-posterior predictive shrinkage", pad=8)
    ax_c.legend(loc="lower right", fontsize=6.5, frameon=True)

    # Panel d: Saltelli-Sobol Total-Order (S_T) & First-Order (S_1) across Delta_Psi4 & tau_fluid
    ax_d = fig.add_subplot(gs[1, 1])
    panel_label(ax_d, "d")
    top_params = ["n_H", "K_50", "beta_E", "lambda_H", "t_half_S_d", "k_seed_0", "v_max", "C_agg_star_uM"]
    s_psi = sobol_df[sobol_df["output_metric"] == "Delta_Psi4"].set_index("parameter").loc[top_params]
    s_tau = sobol_df[sobol_df["output_metric"] == "tau_fluid_d"].set_index("parameter").loc[top_params]
    yp = np.arange(len(top_params))
    h = 0.36
    ax_d.barh(yp - h / 2, s_psi["Sobol_ST"], height=h, color=OI["blue"], edgecolor=OI["black"], lw=0.6, label="$\\Delta\\Psi_4$ total-order $S_T$")
    ax_d.barh(yp - h / 2, s_psi["Sobol_S1"], height=h, color=OI["sky"], edgecolor="none", alpha=0.85, label="$\\Delta\\Psi_4$ first-order $S_1$")
    ax_d.barh(yp + h / 2, s_tau["Sobol_ST"], height=h, color=OI["vermilion"], edgecolor=OI["black"], lw=0.6, label="$\\tau_{\\mathrm{fluid}}$ total-order $S_T$")
    ax_d.barh(yp + h / 2, s_tau["Sobol_S1"], height=h, color=OI["orange"], edgecolor="none", alpha=0.85, label="$\\tau_{\\mathrm{fluid}}$ first-order $S_1$")

    lbl_list = ["$n_H$", "$K_{50}$", "$\\beta_E$", "$\\lambda_H$", "$t_{1/2,S}$", "$k_{\\mathrm{seed},0}$", "$v_{\\max}$", "$C_{\\mathrm{agg}}^*$"]
    ax_d.set_yticks(yp)
    ax_d.set_yticklabels(lbl_list)
    ax_d.invert_yaxis()
    ax_d.set_xlim(0, 0.78)
    ax_d.set_xlabel("Saltelli–Sobol sensitivity index (26,624 evaluations)")
    ax_d.set_title("Global sensitivity: splicing switch vs clearance lag", pad=8)
    ax_d.legend(loc="lower right", fontsize=6.5, frameon=True)

    save_fig(fig, "Figure4")


# ---------------------------------------------------------------------------
# FIGURE 5: Heterotypic Buffering, Bistability Phase Diagram, 0-42d Timecourses & Latency
# ---------------------------------------------------------------------------
def make_figure5(p: dict[str, float]) -> None:
    bif_df = pd.read_csv(TABLES_DIR / "bifurcation_phase_grid.csv")
    tc_df = pd.read_csv(TABLES_DIR / "proteostasis_timecourse_regimes.csv")
    gtex_b = pd.read_csv(DATA_PROCESSED / "gtex_v8_brain_13regions.csv")
    chembl_df = pd.read_csv(DATA_PROCESSED / "chembl_antipsychotic_ki.csv")
    reg = json.loads((RESULTS_DIR / "metrics_registry.json").read_text(encoding="utf-8"))

    fig = plt.figure(figsize=(12.6, 9.6))
    gs = fig.add_gridspec(2, 2, hspace=0.38, wspace=0.32)

    # Panel a: Eq (9)-(10) C_H_free & sigmoidal k_gel vs chi_Delta4 +/- me4 peptide
    ax_a = fig.add_subplot(gs[0, 0])
    panel_label(ax_a, "a")
    chi_g = np.linspace(0.05, 0.85, 250)
    kg0, _ = rc.eq10_11_rates(chi_g, p, P_pep_uM=0.0)
    kg05, _ = rc.eq10_11_rates(chi_g, p, P_pep_uM=15.0)
    kg10, _ = rc.eq10_11_rates(chi_g, p, P_pep_uM=30.0)

    ax_a.plot(chi_g, kg0 / p["k_gel_max"], color=OI["vermilion"], lw=2.2, label="No peptide ($P_{\\mathrm{pep}}=0$)")
    ax_a.plot(chi_g, kg05 / p["k_gel_max"], color=OI["blue"], ls="--", lw=1.8, label="+0.5 eq me4 peptide (15 μM)")
    ax_a.plot(chi_g, kg10 / p["k_gel_max"], color=OI["green"], ls="-.", lw=1.8, label="+1.0 eq me4 peptide (30 μM)")
    ax_a.axvline(0.30, color=OI["sky"], ls=":", lw=1.3)
    ax_a.axvline(0.45, color=OI["vermilion"], ls=":", lw=1.3)
    ax_a.text(0.28, 0.86, "Control\n$\\chi_{\\Delta 4}=0.30$", ha="right", fontsize=7.0, color=OI["blue"])
    ax_a.text(0.46, 0.86, "SCZ / ASD\n$\\chi_{\\Delta 4}=0.45$\n(14.8× $k_{\\mathrm{gel}}$)", ha="left", fontsize=7.0, color=OI["vermilion"])
    ax_a.set_xlabel("CPEB4Δ4 isoform mole fraction, $\\chi_{\\Delta 4}$")
    ax_a.set_ylabel("Normalized nucleation propensity, $k_{\\mathrm{gel}} / k_{\\mathrm{gel},\\max}$")
    ax_a.set_xlim(0.10, 0.82)
    ax_a.set_ylim(-0.03, 1.05)
    ax_a.set_title("Heterotypic me4–HClust buffering & gelation switch, Eqs. (9)–(10)", pad=8)
    ax_a.legend(loc="lower right", fontsize=6.9, frameon=True)

    # Panel b: Bifurcation diagram & separatrix in (Psi4, f_S) plane
    ax_b = fig.add_subplot(gs[0, 1])
    panel_label(ax_b, "b")
    b1 = bif_df[bif_df["delta_S_multiplier"] == 1.0].copy()
    low_m = b1["f_S_low_ss"] >= 0
    sep_m = b1["f_S_separatrix"] >= 0
    high_m = b1["f_S_high_ss"] >= 0

    ax_b.axvspan(0.66, 0.76, color=OI["yellow"], alpha=0.22, label="Bistable hysteresis window (0.66–0.76)")
    ax_b.plot(b1.loc[low_m, "Psi4"], b1.loc[low_m, "f_S_low_ss"], color=OI["green"], lw=2.4, label="Stable liquid attractor ($f_S^{\\mathrm{liq}}$)")
    ax_b.plot(b1.loc[sep_m, "Psi4"], b1.loc[sep_m, "f_S_separatrix"], color=OI["black"], ls="--", lw=1.6, label="Saddle-node separatrix ($f_{S,\\mathrm{crit}}$)")
    ax_b.plot(b1.loc[high_m, "Psi4"], b1.loc[high_m, "f_S_high_ss"], color=OI["vermilion"], lw=2.4, label="Stable gelated attractor ($f_S^{\\mathrm{gel}}$)")

    # Mark SCZ, Haloperidol, Clozapine, Risperidone steady Psi4
    for x_p, tx_p, lbl, col in [
        (0.550, 0.550, "SCZ", OI["grey"]),
        (0.601, 0.601, "HAL", OI["purple"]),
        (0.724, 0.713, "CLZ", OI["sky"]),
        (0.744, 0.755, "RIS", OI["blue"]),
    ]:
        ax_b.axvline(x_p, color=col, ls=":", lw=1.1)
        ax_b.text(tx_p, 1.015, lbl, ha="center", va="bottom", fontsize=6.8, fontweight="bold", color=col)

    ax_b.text(0.52, 0.45, "Regime III:\nMonostable\nGelated", ha="center", fontsize=7.0, color=OI["vermilion"], fontweight="bold")
    ax_b.text(0.692, 0.22, "Regime I:\nPrevention", ha="center", fontsize=6.8, color=OI["green"], fontweight="bold",
              bbox=dict(boxstyle="round,pad=0.14", fc="white", alpha=0.88, ec="none"))
    ax_b.text(0.808, 0.48, "Regime II:\nMonostable\nLiquid", ha="center", fontsize=7.0, color=OI["green"], fontweight="bold")
    ax_b.set_xlim(0.45, 0.85)
    ax_b.set_ylim(-0.03, 1.09)
    ax_b.set_xlabel("Steady-state CPEB4 me4 inclusion, $\\Psi_4^*$")
    ax_b.set_ylabel("Solid aggregate fraction, $f_S^* = S / (L_{\\mathrm{tot}} + S)$")
    ax_b.set_title("Saddle-node bistability & separatrix, Eqs. (12)–(15)", pad=12)
    ax_b.legend(loc="lower left", fontsize=6.4, frameon=True)

    # Panel c: Continuous 0-42 d FRAP M_f(t) timecourses across Moderate vs Severe Lock-In
    ax_c = fig.add_subplot(gs[1, 0])
    panel_label(ax_c, "c")
    ref_medians = {"RNPS1": float(gtex_b["RNPS1"].median()), "SRSF11": float(gtex_b["SRSF11"].median()), "HDAC2": float(gtex_b["HDAC2"].median())}
    ba9_row = gtex_b[gtex_b["tissueSiteDetailAbbr"] == "BRNCTXB"].iloc[0]
    scz_ss = rc.steady_upstream(rc.regional_context(ba9_row, ref_medians, p, 0.0, 0.0, scz=True), p)
    t_eval = np.linspace(0.0, 42.0, 211)

    def sim_curve(dname: str, f_s0: float, P_pep: float = 0.0, mult_ds: float = 1.0) -> np.ndarray:
        if dname == "UNTREATED_SCZ":
            dth2, dth5 = 0.0, 0.0
        else:
            row_c = chembl_df[chembl_df["drug_name"] == dname].iloc[0]
            occ = rc.eq1_occupancy(dname, float(row_c["drd2_median_ki_nm"]), float(row_c["htr2a_median_ki_nm"]))
            dth2, dth5 = occ["dtheta_d2_eff"], occ["dtheta_5ht2a_eff"]
        ctx = rc.regional_context(ba9_row, ref_medians, p, dth2, dth5, scz=True)
        lp0, ld0, s0 = rc.init_proteostasis_state(f_s0, scz_ss["Psi4"], p)
        y0 = np.array([scz_ss["A_PKA_ss"], scz_ss["S_tot_ss"], scz_ss["H_ac_ss"], lp0, ld0, s0])
        sol = solve_ivp(lambda t, y: rc.rc_ktf_ode_rhs(t, y, ctx, p, P_pep_uM=P_pep, mult_dS=mult_ds),
                        (0.0, 42.0), y0, method="Radau", t_eval=t_eval, rtol=1e-9, atol=1e-11)
        return np.array([rc.eq16_readouts(sol.y[3, i], sol.y[4, i], sol.y[5, i], p)["M_f"] for i in range(len(t_eval))])

    specs = [
        ("UNTREATED_SCZ", 0.40, 0.0, 1.0, OI["grey"], ":", "Untreated SCZ ($f_S(0)=0.40$)"),
        ("HALOPERIDOL", 0.40, 0.0, 1.0, OI["purple"], "-.", "Haloperidol ($f_S(0)=0.40$)"),
        ("RISPERIDONE", 0.40, 0.0, 1.0, OI["blue"], "-", "Risperidone ($f_S(0)=0.40$)"),
        ("RISPERIDONE", 0.78, 0.0, 1.0, OI["vermilion"], "-", "Risperidone alone ($f_S(0)=0.78$, locked)"),
        ("RISPERIDONE", 0.78, 15.0, 1.0, OI["orange"], "--", "Risperidone + 0.5 eq me4Pep ($f_S(0)=0.78$)"),
        ("RISPERIDONE", 0.78, 0.0, 2.0, OI["green"], "--", "Risperidone + 2× Autophagy ($f_S(0)=0.78$)"),
    ]
    for dname, fs0, pep, mds, col, ls, lbl in specs:
        mf_t = sim_curve(dname, fs0, pep, mds)
        ax_c.plot(t_eval, mf_t, color=col, ls=ls, lw=1.9, label=lbl)

    ax_c.axhline(0.70, color=OI["black"], ls=":", lw=0.9)
    ax_c.text(1.0, 0.715, "Re-fluidization threshold ($M_f = 0.70$)", fontsize=6.8, color=OI["black"])
    ax_c.axvspan(7, 28, color=OI["sky"], alpha=0.10)
    ax_c.text(17.5, 0.13, "Clinical response\nwindow (1–4 wk)", ha="center", fontsize=6.8, color=OI["blue"])
    ax_c.set_xlim(0, 42)
    ax_c.set_ylim(0.10, 0.89)
    ax_c.set_xlabel("Treatment duration, $t$ (days)")
    ax_c.set_ylabel("Predicted FRAP mobile fraction, $M_f(t)$")
    ax_c.set_title("Acute vs chronic condensate turnover & hysteresis lock-in", pad=8)
    ax_c.legend(loc="center right", fontsize=6.2, frameon=True, framealpha=0.93)

    # Panel d: Day-42 M_f & T_SCZ across Moderate vs Severe Lock-In regimes
    ax_d = fig.add_subplot(gs[1, 1])
    panel_label(ax_d, "d")
    trts = ["UNTREATED_SCZ", "HALOPERIDOL", "CLOZAPINE", "RISPERIDONE", "RISPERIDONE_plus_me4Pep_0.5eq", "RISPERIDONE_plus_Autophagy_2x"]
    t_lbls = ["Untreated\nSCZ", "Haloperidol", "Clozapine", "Risperidone", "Risp +\nme4Pep", "Risp +\nAutoph 2×"]
    d42 = tc_df[tc_df["time_days"] == 42.0]
    mod_vals = [float(d42[(d42["initial_regime"] == "Moderate_Aggregate") & (d42["treatment"] == tr)]["M_f"].iloc[0]) for tr in trts]
    sev_vals = [float(d42[(d42["initial_regime"] == "Severe_Gelated_LockIn") & (d42["treatment"] == tr)]["M_f"].iloc[0]) for tr in trts]

    x = np.arange(len(trts))
    w = 0.36
    ax_d.bar(x - w / 2, mod_vals, w, color=OI["blue"], edgecolor=OI["black"], lw=0.6, label="Moderate initial aggregate ($f_S(0)=0.40$)")
    ax_d.bar(x + w / 2, sev_vals, w, color=OI["vermilion"], edgecolor=OI["black"], lw=0.6, label="High-aggregate lock-in ($f_S(0)=0.78$)")
    ax_d.axhline(0.70, color=OI["black"], ls="--", lw=1.0, zorder=1)
    lbl_bg = dict(boxstyle="square,pad=0.06", fc="white", alpha=0.90, ec="none")
    for i, (mv, sv) in enumerate(zip(mod_vals, sev_vals)):
        ax_d.text(i - w / 2, mv + 0.015, f"{mv:.2f}", ha="center", va="bottom", fontsize=6.5, bbox=lbl_bg, zorder=4)
        ax_d.text(i + w / 2, sv + 0.015, f"{sv:.2f}", ha="center", va="bottom", fontsize=6.5, bbox=lbl_bg, zorder=4)
    ax_d.set_xticks(x)
    ax_d.set_xticklabels(t_lbls, rotation=16, ha="right")
    ax_d.set_ylim(0, 0.96)
    ax_d.set_ylabel("Day-42 FRAP mobile fraction, $M_f(42\\,\\mathrm{d})$")
    ax_d.set_title("Prevention/moderate clearance vs severe lock-in rescue", pad=8)
    ax_d.legend(loc="upper left", fontsize=6.8, frameon=True)

    save_fig(fig, "Figure5")


# ---------------------------------------------------------------------------
# FIGURE 6: Prospective iPSC Experimental Blueprint & Statistical Power Map
# ---------------------------------------------------------------------------
def make_figure6() -> None:
    tc_df = pd.read_csv(TABLES_DIR / "proteostasis_timecourse_regimes.csv")
    pwr_df = pd.read_csv(TABLES_DIR / "ipsc_experimental_power.csv")

    fig = plt.figure(figsize=(12.6, 5.2))
    gs = fig.add_gridspec(1, 3, wspace=0.34)

    # Panel a: Temporal dissociation across assays (Moderate Risperidone vs Untreated SCZ)
    ax_a = fig.add_subplot(gs[0, 0])
    panel_label(ax_a, "a")
    times = [1.0, 3.0, 7.0, 14.0, 28.0, 42.0]
    t_lbls = ["24h", "72h", "7d", "14d", "28d", "42d"]
    sub_ris = tc_df[(tc_df["initial_regime"] == "Moderate_Aggregate") & (tc_df["treatment"] == "RISPERIDONE")].set_index("time_days")
    sub_scz = tc_df[(tc_df["initial_regime"] == "Moderate_Aggregate") & (tc_df["treatment"] == "UNTREATED_SCZ")].set_index("time_days")

    # Normalized rescue fraction (0 = SCZ baseline, 1 = max achieved)
    hdac_sig = (1.0 / sub_ris.loc[times, "H_ac"] - 1.0 / sub_scz.loc[times, "H_ac"])
    hdac_norm = hdac_sig / hdac_sig.max()
    psi_sig = sub_ris.loc[times, "Psi4_t"] - sub_scz.loc[times, "Psi4_t"]
    psi_norm = psi_sig / psi_sig.max()
    mf_sig = sub_ris.loc[times, "M_f"] - sub_scz.loc[times, "M_f"]
    mf_norm = mf_sig / mf_sig.max()
    t_sig = sub_ris.loc[times, "T_SCZ"] - sub_scz.loc[times, "T_SCZ"]
    t_norm = t_sig / t_sig.max()

    x = np.arange(len(times))
    ax_a.plot(x, hdac_norm * 100, "o-", color=OI["vermilion"], lw=1.8, label="WB: HDAC2 / p-SRRM4")
    ax_a.plot(x, psi_norm * 100, "s--", color=OI["blue"], lw=1.8, label="RT-qPCR: CPEB4 (+4/Δ4)")
    ax_a.plot(x, t_norm * 100, "^-.", color=OI["orange"], lw=1.8, label="Protein: SCZ target rescue ($T_{\\mathrm{SCZ}}$)")
    ax_a.plot(x, mf_norm * 100, "D-", color=OI["green"], lw=2.0, label="Live FRAP: Mobile fraction ($M_f$)")
    ax_a.set_xticks(x)
    ax_a.set_xticklabels(t_lbls)
    ax_a.set_xlabel("iPSC cortical neuron treatment duration")
    ax_a.set_ylabel("Normalized assay response (% of max)")
    ax_a.set_ylim(-5, 110)
    ax_a.set_title("Acute vs chronic readout dissociation", pad=8)
    ax_a.legend(loc="lower right", fontsize=6.6, frameon=True)

    # Panel b: Statistical power curves vs n per arm (FRAP M_f across regimes & timepoints)
    ax_b = fig.add_subplot(gs[0, 1])
    panel_label(ax_b, "b")
    ns = np.arange(3, 13)
    curves = [
        ("RISPERIDONE_vs_UNTREATED_SCZ", "RT_qPCR_CPEB4_Psi4", "Moderate_Aggregate", 1.0, OI["blue"], "-", "RT-qPCR $\\Psi_4$ (24h Mod)"),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 7.0, OI["sky"], "--", "FRAP $M_f$ (7d Mod)"),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 14.0, OI["green"], "-", "FRAP $M_f$ (14d Mod)"),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Severe_Gelated_LockIn", 42.0, OI["vermilion"], "-.", "FRAP $M_f$ (42d Severe Mono)"),
        ("RISPERIDONE_plus_me4Pep_0.5eq_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Severe_Gelated_LockIn", 28.0, OI["orange"], "-", "FRAP $M_f$ (28d Severe+me4Pep)"),
    ]
    for comp, assay, regm, td, col, ls, lbl in curves:
        sub = pwr_df[(pwr_df["comparison"] == comp) & (pwr_df["assay"] == assay) &
                     (pwr_df["initial_regime"] == regm) & (pwr_df["time_days"] == td)].sort_values("n_per_arm")
        ax_b.plot(sub["n_per_arm"], sub["power_alpha005_twosided"] * 100, color=col, ls=ls, lw=1.9, marker="o", ms=3.5, label=lbl)

    ax_b.axhline(80.0, color=OI["black"], ls=":", lw=1.0)
    ax_b.text(3.2, 82.0, "80% power", fontsize=7.0, fontweight="bold")
    ax_b.set_xlim(2.8, 12.2)
    ax_b.set_ylim(0, 105)
    ax_b.set_xlabel("Independent iPSC donor lines per arm ($n$)")
    ax_b.set_ylabel("Statistical power (%, $\\alpha=0.05$ two-sided)")
    ax_b.set_title("Prospective sample-size power curves", pad=8)
    ax_b.legend(loc="lower right", fontsize=6.3, frameon=True)

    # Panel c: Falsifiable pathway-perturbation truth table (heatmap of predicted effect matrix)
    ax_c = fig.add_subplot(gs[0, 2])
    panel_label(ax_c, "c", x=-0.16, y=1.08)
    perts = ["Risperidone\nalone (28d)", "+ PKA block\n(H89)", "+ HDAC block\n(Vorinostat)", "+ Autophagy\nblock (BafA1)", "+ Autophagy\n2× (Rapam.)"]
    readouts = ["p-SRRM4", "HDAC2", "CPEB4+4\n(Ψ4)", "FRAP Mf\n(Mod)", "FRAP Mf\n(Lock-in)"]
    # Qualitative normalized effect [-1 to +1] derived from model perturbation logic
    mat_t = np.array([
        [+0.85, +0.90, +0.88, +0.80, +0.15],
        [-0.25, +0.85, +0.42, +0.35, +0.05],
        [+0.85, -0.75, +0.32, +0.28, +0.05],
        [+0.85, +0.90, +0.88, -0.35, -0.60],
        [+0.85, +0.90, +0.88, +0.98, +0.96],
    ])
    cmap_div = LinearSegmentedColormap.from_list("div_okabe", [OI["vermilion"], "#F7F7F7", OI["green"]])
    im = ax_c.imshow(mat_t, cmap=cmap_div, vmin=-1.0, vmax=1.0, aspect="auto")
    lbls_cell = [
        ["↑↑", "↑↑", "↑↑", "↑↑", "≈0"],
        ["↓↓", "↑↑", "↓ (part.)", "↓", "≈0"],
        ["↑↑", "↓↓", "↓ (part.)", "↓", "≈0"],
        ["↑↑", "↑↑", "↑↑", "↓↓", "↓↓"],
        ["↑↑", "↑↑", "↑↑", "↑↑↑", "↑↑↑"],
    ]
    for i in range(5):
        for j in range(5):
            ax_c.text(j, i, lbls_cell[i][j], ha="center", va="center", fontsize=7.5, fontweight="bold", color=OI["black"])
    ax_c.set_xticks(np.arange(5))
    ax_c.set_xticklabels(readouts, rotation=22, ha="right", fontsize=7.0)
    ax_c.set_yticks(np.arange(5))
    ax_c.set_yticklabels(perts, fontsize=7.0)
    ax_c.set_title("Predicted iPSC perturbation matrix", pad=8)

    save_fig(fig, "Figure6")


# ---------------------------------------------------------------------------
# SUPPLEMENTARY FIGURES S1-S3
# ---------------------------------------------------------------------------
def make_supplementary_figures(p: dict[str, float]) -> None:
    g54 = pd.read_csv(DATA_PROCESSED / "gtex_v8_54tissues.csv")
    var_df = pd.read_csv(DATA_PROCESSED / "gse276143_cpeb4_variants.csv")
    chembl_df = pd.read_csv(DATA_PROCESSED / "chembl_antipsychotic_ki.csv")
    cent_df = pd.read_csv(TABLES_DIR / "string_network_centrality.csv")
    sobol_df = pd.read_csv(TABLES_DIR / "sobol_prcc_sensitivity.csv")
    bif_df = pd.read_csv(TABLES_DIR / "bifurcation_phase_grid.csv")
    reg = json.loads((RESULTS_DIR / "metrics_registry.json").read_text(encoding="utf-8"))

    # Figure S1: Full 54-tissue GTEx PSI4 + GSE276143 cis-variant landscape
    fig = plt.figure(figsize=(12.6, 5.8))
    gs = fig.add_gridspec(1, 2, wspace=0.38)
    ax1 = fig.add_subplot(gs[0, 0])
    panel_label(ax1, "a")
    g54_s = g54.sort_values("PSI4", ascending=True).tail(24)
    cols = [OI["blue"] if b else OI["grey"] for b in g54_s["is_brain"]]
    ax1.barh(np.arange(len(g54_s)), g54_s["PSI4"] * 100, color=cols, edgecolor=OI["black"], lw=0.5)
    ax1.set_yticks(np.arange(len(g54_s)))
    ax1.set_yticklabels(g54_s["tissueSiteDetail"], fontsize=6.4)
    ax1.set_xlabel("CPEB4 me4 inclusion, $\\Psi_4$ (%)")
    ax1.set_title("GTEx v8 top 24 tissues by CPEB4 $\\Psi_4$ (blue = brain)", pad=8)

    ax2 = fig.add_subplot(gs[0, 1])
    panel_label(ax2, "b")
    for cond, col, mk in [("GFP", OI["grey"], "o"), ("LOW", OI["orange"], "^"), ("MID", OI["blue"], "s"), ("HIGH", OI["green"], "D")]:
        sub = var_df[(var_df["condition"] == cond) & (var_df["mutation_class"].isin(["rem", "WT", "add_0"]))].sort_values("var_len")
        ax2.errorbar(sub["var_len"], sub["mean_psi"], yerr=sub["sd_psi"], fmt=f"{mk}-", color=col, lw=1.3, ms=4.2, capsize=2.5, label=cond)
    ax2.axvline(24, color=OI["vermilion"], ls="--", lw=1.1, label="WT me4 (24 nt)")
    ax2.set_xlabel("CPEB4 microexon 4 variant length (nt)")
    ax2.set_ylabel("Observed inclusion, $\\Psi_4$ (%)")
    ax2.set_title("GSE276143 exon-length sensitivity across SRRM4 tiers", pad=8)
    ax2.legend(loc="lower right", fontsize=7.0, frameon=True)
    save_fig(fig, "FigureS1")

    # Figure S2: ChEMBL 37 assay count/IQR summary & STRING v12.5 centrality
    fig = plt.figure(figsize=(12.2, 5.4))
    gs = fig.add_gridspec(1, 2, wspace=0.35)
    ax1 = fig.add_subplot(gs[0, 0])
    panel_label(ax1, "a")
    d_sub = chembl_df[chembl_df["target_symbol"].isin(["DRD2", "HTR2A"])].pivot(index="drug_name", columns="target_symbol", values="median_pki")
    d_sub = d_sub.sort_values("HTR2A")
    y = np.arange(len(d_sub))
    ax1.scatter(d_sub["DRD2"], y, color=OI["vermilion"], marker="^", s=55, edgecolor="black", lw=0.6, label="DRD2 median $pK_i$")
    ax1.scatter(d_sub["HTR2A"], y, color=OI["green"], marker="o", s=55, edgecolor="black", lw=0.6, label="5-HT2AR median $pK_i$")
    for idx, (_, r) in enumerate(d_sub.iterrows()):
        ax1.plot([r["DRD2"], r["HTR2A"]], [idx, idx], color=OI["grey"], lw=1.0, zorder=1)
    ax1.set_yticks(y)
    ax1.set_yticklabels([x.title() for x in d_sub.index], fontsize=7.5)
    ax1.set_xlabel("Human receptor affinity, $pK_i$ ($-\\log_{10} K_i$ [M])")
    ax1.set_title("ChEMBL 37 DRD2 vs HTR2A $pK_i$ selectivity divergence", pad=8)
    ax1.legend(loc="lower right", fontsize=7.2, frameon=True)

    ax2 = fig.add_subplot(gs[0, 1])
    panel_label(ax2, "b")
    c_top = cent_df.sort_values("betweenness_weighted", ascending=True).tail(14)
    ax2.barh(np.arange(len(c_top)), c_top["betweenness_weighted"], color=OI["sky"], edgecolor=OI["black"], lw=0.6)
    ax2.set_yticks(np.arange(len(c_top)))
    ax2.set_yticklabels(c_top["node"], fontsize=7.5)
    ax2.set_xlabel("Weighted betweenness centrality (STRING v12.5)")
    ax2.set_title("Signaling-to-splicing network bottleneck hubs", pad=8)
    save_fig(fig, "FigureS2")

    # Figure S3: Multi-threshold delta_S bifurcation family + PRCC rankings across all 3 outputs
    fig = plt.figure(figsize=(12.4, 5.4))
    gs = fig.add_gridspec(1, 2, wspace=0.35)
    ax1 = fig.add_subplot(gs[0, 0])
    panel_label(ax1, "a")
    for mult, col, ls in [(0.75, OI["vermilion"], ":"), (1.0, OI["black"], "-"), (1.5, OI["blue"], "--"), (2.0, OI["green"], "-.")]:
        sub = bif_df[bif_df["delta_S_multiplier"] == mult]
        hm = sub["f_S_high_ss"] >= 0
        lm = sub["f_S_low_ss"] >= 0
        ax1.plot(sub.loc[hm, "Psi4"], sub.loc[hm, "f_S_high_ss"], color=col, ls=ls, lw=1.6,
                 label=f"$\\delta_S \\times {mult:.2f}$ ($t_{{1/2,S}}={10/mult:.1f}$ d)")
        ax1.plot(sub.loc[lm, "Psi4"], sub.loc[lm, "f_S_low_ss"], color=col, ls=ls, lw=1.6)
    ax1.set_xlabel("Steady-state $\\Psi_4^*$")
    ax1.set_ylabel("Steady-state solid fraction, $f_S^*$")
    ax1.set_title("Higher modeled clearance $\\delta_S$ eliminates bistability", pad=8)
    ax1.legend(loc="lower left", fontsize=7.0, frameon=True)

    ax2 = fig.add_subplot(gs[0, 1])
    panel_label(ax2, "b")
    piv_prcc = sobol_df.pivot(index="parameter", columns="output_metric", values="PRCC")
    piv_prcc = piv_prcc.loc[piv_prcc.abs().max(axis=1).sort_values(ascending=True).index]
    y = np.arange(len(piv_prcc))
    h = 0.26
    ax2.axvline(0.0, color=OI["black"], lw=0.8, ls="--")
    ax2.barh(y - h, piv_prcc["Delta_Psi4"], height=h, color=OI["blue"], label="$\\Delta\\Psi_4$")
    ax2.barh(y, piv_prcc["tau_fluid_d"], height=h, color=OI["vermilion"], label="$\\tau_{\\mathrm{fluid}}$")
    ax2.barh(y + h, piv_prcc["f_S_28d"], height=h, color=OI["green"], label="$f_S(28\\,\\mathrm{d})$")
    sym_map = {
        "n_H": "$n_H$", "t_half_S_d": "$t_{1/2,S}$", "K_50": "$K_{50}$", "beta_E": "$\\beta_E$",
        "k_seed_0": "$k_{\\mathrm{seed},0}$", "lambda_H": "$\\lambda_H$", "v_max": "$v_{\\max}$",
        "C_agg_star_uM": "$C_{\\mathrm{agg}}^*$", "pH_cytosol": "$\\mathrm{pH}_{\\mathrm{cyt}}$",
        "K_het_uM": "$K_{\\mathrm{het}}$", "t_half_L_d": "$t_{1/2,L}$", "kappa_D32": "$\\kappa_{\\mathrm{D32}}$",
    }
    ax2.set_yticks(y)
    ax2.set_yticklabels([sym_map.get(k, k) for k in piv_prcc.index], fontsize=7.6)
    ax2.set_xlabel("Partial rank correlation coefficient (PRCC)")
    ax2.set_title("PRCC sign & magnitude across all 12 uncertain parameters", pad=8)
    ax2.legend(loc="lower right", fontsize=7.0, frameon=True)
    save_fig(fig, "FigureS3")


# ---------------------------------------------------------------------------
# EXPORT MANUSCRIPT TABLES 1-4 & SUPPLEMENTARY TABLES S1-S4
# ---------------------------------------------------------------------------
def export_publication_tables() -> None:
    # Table 1: Public Datasets Summary
    t1 = pd.DataFrame([
        {"Dataset / Resource": "GTEx v8 Human Atlas", "Accession / API": "gtexportal.org/api/v2 (v8)", "Species & Tissue": "Homo sapiens; 54 tissues (13 brain)", "Sample Size": "54 tissue medians (838 donors)", "Primary Analytical Role": "Quantify CPEB4 me4 PSI4 & partial correlations controlling for RBFOX3+SYP; LOOCV transfer"},
        {"Dataset / Resource": "Bonnal et al. 2025 (NSMB)", "Accession / API": "GEO GSE276143 (PMID:40775527)", "Species & Tissue": "Homo sapiens; HEK293T Flp-In SRRM4", "Sample Size": "6 reps x 4 tiers (24 WT + 92 var rows)", "Primary Analytical Role": "Calibrate cooperative Hill splicing switch & steric exon-length rescue; 6-fold LORO CV"},
        {"Dataset / Resource": "NCBI RefSeq & UniProtKB", "Accession / API": "NC_000005.10; Q17RY0, A7MD48", "Species & Tissue": "Homo sapiens; Chr5 CPEB4 locus", "Sample Size": "12,691 nt genomic span; 7 proteins", "Primary Analytical Role": "3'ss/5'ss PWM scoring, hnRNPC/SRRM4/RBFOX motif mapping, intron 4 kinetic length, HClust PTMs"},
        {"Dataset / Resource": "ChEMBL 37 Pharmacology", "Accession / API": "ebi.ac.uk/chembl (PMID:37933841)", "Species & Tissue": "Homo sapiens; 7 GPCR targets", "Sample Size": "714 experimental Ki records (12 drugs)", "Primary Analytical Role": "Parameterize Eq. (1) D2R/5-HT2A affinities, selectivity ratios, & clinical receptor occupancies"},
        {"Dataset / Resource": "STRING v12.5 PPI Network", "Accession / API": "string-db.org (PMID:36370105)", "Species & Tissue": "Homo sapiens; 27-node pathway graph", "Sample Size": "27 nodes, 89 edges (score >= 0.400)", "Primary Analytical Role": "Weighted shortest paths & betweenness hubs linking D2R/5-HT2AR to SRRM4/HDAC2/POLR2A"},
        {"Dataset / Resource": "Zhu et al. 2024 (eLife)", "Accession / API": "GEO GSE174407 (PMID:38648100)", "Species & Tissue": "Homo sapiens; sorted PFC NeuN+ neurons", "Sample Size": "58 donors (116 RNA files: 29 CTL, 15 Untrt, 14 Trt)", "Primary Analytical Role": "Cell-type-pure human cortical neuronal validation of CPEB4, RBFOX1, HDAC2, POLR2A shifts"},
        {"Dataset / Resource": "Perez et al. 2021 (Mol Psych)", "Accession / API": "GEO GSE138082 (PMID:32152472)", "Species & Tissue": "Homo sapiens; hippocampal CA1/CA3/DG", "Sample Size": "78 samples (39 CTL, 21 OFF, 18 ON)", "Primary Analytical Role": "Clustered covariate OLS testing antipsychotic ON vs OFF shifts in RNPS1, SRSF11, HDAC2, CAMK2A"},
        {"Dataset / Resource": "Das et al. 2021 (Schizophr Res)", "Accession / API": "GEO GSE163161 (PMID:33497908)", "Species & Tissue": "Homo sapiens; iPSC Ngn2 excitatory neurons", "Sample Size": "10 samples (6 Clozapine vs 4 Ctrl)", "Primary Analytical Role": "Ex vivo human excitatory neuron clozapine validation (SRSF11, PTBP2, ARC, AKT1)"},
        {"Dataset / Resource": "Mouse Cortical Cell Fractions", "Accession / API": "GEO GSE315204", "Species & Tissue": "Mus musculus; sorted THY1+, HEPA, CD45+", "Sample Size": "18 samples (6 THY1+ neurons: VEH/RIS/CLZ)", "Primary Analytical Role": "Exploratory cell-sorted cortical neuronal directional replication under risperidone & clozapine"},
        {"Dataset / Resource": "Kim et al. 2018 (Mol Psych)", "Accession / API": "GEO GSE67755 (PMID:28555076)", "Species & Tissue": "Mus musculus; whole brain chronic haloperidol", "Sample Size": "20 whole brains (10 HAL vs 10 Placebo)", "Primary Analytical Role": "Test bulk whole-brain haloperidol response & PTBP1/SRRM4/HNRNPC contrasts in 5-cohort meta-analysis"},
    ])
    t1.to_csv(TABLES_DIR / "Table1_public_datasets.csv", index=False)

    # Table 2: Core Calibrated & Literature-Anchored Parameters
    mp = pd.read_csv(TABLES_DIR / "model_parameters_calibrated.csv")
    key_p = ["L_intron4", "v_min", "v_max", "k_4_max", "K_50", "n_H", "k_skip",
             "s_scale_gtex", "K_tr_srrm4", "alpha_R", "alpha_S", "K_P_ptbp1",
             "m_neu", "beta_E", "lambda_H", "C_cond_uM", "pKa_HClust", "K_het_uM",
             "C_agg_star_uM", "m_coop", "k_gel_max", "k_seed_0", "K_S", "delta_L", "delta_S"]
    t2_p = mp[mp["parameter"].isin(key_p)].copy()
    t2_p.to_csv(TABLES_DIR / "Table2_model_parameters.csv", index=False)

    # Table 3: Antipsychotic Pharmacology & Regional Model Predictions
    dp = pd.read_csv(TABLES_DIR / "antipsychotic_drug_predictions.csv")
    ba9 = dp[dp["region"] == "PFC_BA9"].set_index("drug_name")
    str_df = dp[dp["region"] == "Striatum"].set_index("drug_name")
    rows_t3 = []
    for d in ba9.sort_values("Delta_Psi4", ascending=False).index:
        r_b = ba9.loc[d]
        r_s = str_df.loc[d]
        rows_t3.append({
            "Drug": d.title(),
            "Class": r_b["drug_class"],
            "D2R Ki (nM)": round(float(r_b["drd2_ki_nm"]), 2),
            "5-HT2AR Ki (nM)": round(float(r_b["htr2a_ki_nm"]), 2),
            "C_free,brain (nM)": round(float(r_b["c_free_brain_nm"]), 2),
            "Eff D2 Occ (%)": round(float(r_b["dtheta_d2_eff"]) * 100, 1),
            "5-HT2A Occ (%)": round(float(r_b["theta_5ht2a"]) * 100, 1),
            "BA9 Psi4* (%)": round(float(r_b["Psi4_drug_ss"]) * 100, 2),
            "BA9 Delta Psi4 (%)": round(float(r_b["Delta_Psi4"]) * 100, 2),
            "BA9 Day-28 M_f": round(float(r_b["M_f_28d_moderate"]), 3),
            "BA9 Regime (n_SS)": int(r_b["n_steady_states"]),
            "Striatum Delta Psi4 (%)": round(float(r_s["Delta_Psi4"]) * 100, 2),
            "Striatum Day-28 M_f": round(float(r_s["M_f_28d_moderate"]), 3),
        })
    pd.DataFrame(rows_t3).to_csv(TABLES_DIR / "Table3_antipsychotic_pharmacology.csv", index=False)

    # Table 4: Prospective iPSC Experimental Predictions & Power Summary
    pwr = pd.read_csv(TABLES_DIR / "ipsc_experimental_power.csv")
    sel = [
        ("RISPERIDONE_vs_UNTREATED_SCZ", "Western_HDAC2_fold", "Moderate_Aggregate", 1.0),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "RT_qPCR_CPEB4_Psi4", "Moderate_Aggregate", 1.0),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "RT_qPCR_CPEB4_Psi4", "Moderate_Aggregate", 7.0),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 1.0),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 7.0),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 14.0),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 28.0),
        ("CLOZAPINE_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 28.0),
        ("HALOPERIDOL_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Moderate_Aggregate", 28.0),
        ("RISPERIDONE_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Severe_Gelated_LockIn", 42.0),
        ("RISPERIDONE_plus_me4Pep_0.5eq_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Severe_Gelated_LockIn", 28.0),
        ("RISPERIDONE_plus_Autophagy_2x_vs_UNTREATED_SCZ", "FRAP_Mobile_Fraction_Mf", "Severe_Gelated_LockIn", 28.0),
    ]
    rows_t4 = []
    for comp, assay, regm, td in sel:
        sub = pwr[(pwr["comparison"] == comp) & (pwr["assay"] == assay) &
                  (pwr["initial_regime"] == regm) & (pwr["time_days"] == td)]
        r6 = sub[sub["n_per_arm"] == 6].iloc[0]
        pass_n = sub[sub["achieves_80pct_power"]]["n_per_arm"]
        min_n = f"{int(pass_n.min())}" if len(pass_n) > 0 else ">12"
        rows_t4.append({
            "Comparison": comp.replace("_vs_UNTREATED_SCZ", " vs SCZ"),
            "Assay": assay,
            "Initial Regime": regm,
            "Time (d)": td,
            "SCZ Mean": round(float(r6["mean_SCZ"]), 4),
            "Treated Mean": round(float(r6["mean_treated"]), 4),
            "Cohen_d": round(float(r6["cohens_d"]), 2),
            "Power at n=6": round(float(r6["power_alpha005_twosided"]), 4),
            "Min n (>=80% Power)": min_n,
        })
    pd.DataFrame(rows_t4).to_csv(TABLES_DIR / "Table4_ipsc_predictions_power.csv", index=False)

    # Supplementary tables aligned strictly in order of manuscript appearance
    pd.read_csv(DATA_PROCESSED / "gse276143_cpeb4_variants.csv").to_csv(TABLES_DIR / "TableS1_gse276143_cis_variants.csv", index=False)
    pd.read_csv(TABLES_DIR / "gtex_v8_correlations.csv").to_csv(TABLES_DIR / "TableS2_gtex_correlations.csv", index=False)
    pd.read_csv(DATA_PROCESSED / "cross_cohort_meta.csv").to_csv(TABLES_DIR / "TableS3_cross_cohort_meta.csv", index=False)
    pd.read_csv(TABLES_DIR / "sobol_prcc_sensitivity.csv").to_csv(TABLES_DIR / "TableS4_sobol_prcc_sensitivity.csv", index=False)
    print("Exported Table1-4 and TableS1-S4 CSVs.")


def main() -> None:
    p = load_calibrated_params()
    make_figure1(p)
    make_figure2()
    make_figure3()
    make_figure4(p)
    make_figure5(p)
    make_figure6()
    make_supplementary_figures(p)
    export_publication_tables()
    print("=== All 9 Figures and 8 Publication Tables Generated ===")


if __name__ == "__main__":
    main()
